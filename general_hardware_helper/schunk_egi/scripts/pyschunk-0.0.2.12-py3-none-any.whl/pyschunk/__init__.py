# -*- coding: latin-1 -*-
from pyschunk.release import PROJECT_RELEASE as VERSION


# @UnresolvedImport
