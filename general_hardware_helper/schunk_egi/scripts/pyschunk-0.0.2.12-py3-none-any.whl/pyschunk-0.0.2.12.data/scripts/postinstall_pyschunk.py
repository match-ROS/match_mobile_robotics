#######################################################################
## \file
#  \section pyschunk_postinstall_pyschunk_py_general General file information
#
#    \author   Dirk Osswald
#    \date     2014-08-28
#
#  \brief
#    Windows installer postinstall script for python setuptools setup.py script.
#    Installs shortcuts to the actual scripts into
#    Start->Programs->SCHUNK->pyschunk...
#    Must be explicitly stated with the --install-script option to setup.py
#    when the bdist_wininst is created.
#
#    (see https://docs.python.org/2/distutils/builtdist.html )
#
#  \section pyschunk_postinstall_pyschunk_py_copyright Copyright
#
#  - Copyright (c) 2014 SCHUNK GmbH & Co. KG
#
#  <HR>
#  \internal
#
#    \subsection pyschunk_postinstall_pyschunk_py_details SVN related, detailed file specific information:
#      $LastChangedBy$
#      $LastChangedDate$
#      \par SVN file revision:
#        $Id$
#
#  \subsection pyschunk_postinstall_pyschunk_py_changelog Changelog of this file:
#      \include postinstall_pyschunk.py.log
#
#######################################################################

import time

######################################################################
# simple logging mechanism for debugging the postinstall script.
# (needed since this is called from the windows installer and cannot
#  simply print to stdout)

# for debugging the postinstall script set do_debug to True. The debugging messages
# are written to a log file on the target system.
#do_debug=False
do_debug=True

log = None
def Log(msg):
    if (log):
        log.write(msg)
    # print message as well, this will show up in the windows installer window
    print (msg)

if (do_debug):
    try:
        log=open( 'c:\\postinstall-pyschunk.log', 'a' )
        Log( '\nLogging started %s\n' % repr(time.localtime()) )
    except:
        # failed to create log file, maybe path is wrong.
        pass
#
######################################################################


##########################################################################
# import needed modules:

import os,sys

#
##########################################################################



######################################################################
# define necessary functions

# inspired by

def Install():
    Log( 'Start of Install()\n' )
    try:
        # this will fail on win98
        d = get_special_folder_path('CSIDL_COMMON_PROGRAMS')  # @UndefinedVariable
        os.chdir(d)

    except:
        d = get_special_folder_path('CSIDL_PROGRAMS')  # @UndefinedVariable
        os.chdir(d)

    # Create program shortcuts ...
    sd1 = d + '\\SCHUNK'
    sd2 = sd1 + '\\pyschunk'

    if not os.path.isdir(sd1):
        os.mkdir( sd1 )
        directory_created( sd1 )  # @UndefinedVariable
        Log( 'Created directory for SCHUNK products in start menue\n' )
    if not os.path.isdir(sd2):
        os.mkdir( sd2 )
        directory_created( sd2 )  # @UndefinedVariable
        Log( 'Created directory for pyschunk stuff in start menue\n' )


    f = sd2 + '\\microterm.lnk'
    # setup.py / setuptools created an exe wrapper for the microterm.py script,
    # so no need to call python, just call the exe wrapper
    e = '"' + sys.prefix + '\\Scripts\\microterm.exe"'
    if not os.path.isfile(f):
        create_shortcut(e,                                       # target @UndefinedVariable
                        'RS232/USB micro terminal',              # description (bubble help)
                        f,                                       # filename
                        "",                                      # arguments
                        sys.prefix + '\\Lib\\site-packages'      # workdir
                        )
        file_created(f)  # @UndefinedVariable
        Log( 'Created shortcut to microterm in start menue\n' )

    f = sd2 + '\\plot.lnk'
    # setup.py / setuptools created an exe wrapper for the plot.py script,
    # so no need to call python, just call the exe wrapper
    e = '"' + sys.prefix + '\\Scripts\\plot.exe"'
    if not os.path.isfile(f):
        create_shortcut(e,                                       # target @UndefinedVariable
                        '2D data plotter for gpd files (requires gnuplot and an X-server!)',              # description (bubble help)
                        f,                                       # filename
                        "",                                      # arguments
                        sys.prefix + '\\Lib\\site-packages'      # workdir
                        )
        file_created(f)  # @UndefinedVariable
        Log( 'Created shortcut to plot in start menue\n' )


    PROJECT_NAME = 'pyschunk'
    f = sd2 + '\\uninstall-%s.lnk' % PROJECT_NAME
    if not os.path.isfile(f):
        create_shortcut( sys.prefix + '\\Remove' + PROJECT_NAME + ".exe",          # target @UndefinedVariable
                        'Uninstall the ' + PROJECT_NAME + ' package from your PC.\n'
                        +"This link works on WindowsXP only, sorry.\n"
                        +"On Windows7 and newer use 'Control Panel->Programs->Programs and Funtions' to uninstall.",       # description (bubble help)
                        f,                                                         # filename
                        '-u "%s\\%s-wininst.log"' % (sys.prefix, PROJECT_NAME) ,   # arguments
                        sys.prefix                                                 # workdir
                        )
        file_created(f)  # @UndefinedVariable
        Log(  'Created shortcut to uninstall package in start menu\n' )

    Log( 'End of Install()\n')
#-----------------------------------------------------------------


def Remove():
    Log( 'Enter Remove().\n' )
    Log( 'End Remove().\n' )
    pass
#-----------------------------------------------------------------

#
##########################################################################


##########################################################################
# "main" function that calls the functions from above according to command
# line

args_ok = False
if len(sys.argv) > 1:
    for (arg,fct) in [('-install',Install), ('-remove', Remove) ]:
        if sys.argv[1] == arg:
            Log( 'Starting %s()\n' % (fct.__name__) )
            try:
                fct()
            except Exception as e:
                Log('caught exception %s while %s()\n' % (repr(e), fct.__name__)  )
                raise
            args_ok = True
            break

    if ( not args_ok ):
        Log( 'postinstall_pyschunk.py script was called with unknown option %s!\n' % (repr(sys.argv[1])) )
else:
    Log( 'postinstall_pyschunk.py script was called without arguments, dont know what to do!\n' % (repr(sys.argv[1])) )

Log('end\n\n')
#
##########################################################################
