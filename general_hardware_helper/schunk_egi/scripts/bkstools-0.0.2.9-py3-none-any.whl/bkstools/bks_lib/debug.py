# -*- coding: latin-1 -*-
'''
Created on 21.11.2018

@author: Dirk Osswald

@brief: basic Debugging and logging functions
'''

import sys

g_logmethod = None

def Print( msg, logmethod=None, file=sys.stdout ):
    '''Print msg using print statement. Additionally
    call logmethod( msg ) if logmethod is None then the module level g_logmethod will be tried.
    To disable logging while g_logmethod is set call with logmethod=0 or logmethod=False.
    '''
    print ( msg, file=file )
    if ( logmethod ):
        logmethod( msg )
    elif ( logmethod is None and g_logmethod ):
        g_logmethod( msg )

def Error( msg, logmethod=None, file=sys.stderr ):
    Print( msg, logmethod, file )

def Debug( msg, logmethod=None, file=sys.stderr ):
    Print( msg, logmethod, file )


def Var( *args ):
        '''
        Return a string with name and value of variables named in args. This will
        print NAME = VALUE pairs for all variables NAME in args. args
        is a list of strings where each string is the name of a
        variable in the context of the caller or args is a string with
        space separated names of variables in the context of the
        caller.

        v = 42
        s = "test"
        Var( "v", "s" )
        =>  "v = 42, s = test"
        Var( "v s" )
        =>  "v = 42, s = test"
        '''
        global_vars = sys._getframe(1).f_globals
        local_vars = sys._getframe(1).f_locals
        sep=u""
        s = u"%s: " % (sys._getframe(1).f_code.co_name)
        for arg in args:
            for a in arg.split():
                s += u"%s%s = %s" % (sep, a, repr(eval(a, global_vars, local_vars)))
                sep = u", "
        return s


class ApplicationError( Exception ):
    '''Class to represent application errors as exceptions.
    '''
    def __init__(self,args=None):
        Exception.__init__(self,args)

class InsufficientAccessRights( ApplicationError ):
    '''Class to represent an error for inusfficient access rights
    '''
    def __init__(self,args=None):
        ApplicationError.__init__(self,args)

class InsufficientReadRights( InsufficientAccessRights ):
    '''Class to represent an error for inusfficient read rights
    '''
    def __init__(self,args=None):
        InsufficientAccessRights.__init__(self,args)

class InsufficientWriteRights( InsufficientAccessRights ):
    '''Class to represent an error for inusfficient Write rights
    '''
    def __init__(self,args=None):
        InsufficientAccessRights.__init__(self,args)

class ControlledFromOtherChannel( InsufficientAccessRights ):
    '''Class to represent an error for ABP_ERR_CONTROLLED_FROM_OTHER_CHANNEL error
    '''
    def __init__(self,args=None):
        InsufficientAccessRights.__init__(self,args)

class ServiceNotAvailable( ApplicationError ):
    '''Class to represent an error for unimplemented services
    '''
    def __init__(self,args=None):
        ApplicationError.__init__(self,args)

class UnsupportedCommand( ApplicationError ):
    '''Class to represent an error for unsupported commands
    '''
    def __init__(self,args=None):
        ApplicationError.__init__(self,args)
