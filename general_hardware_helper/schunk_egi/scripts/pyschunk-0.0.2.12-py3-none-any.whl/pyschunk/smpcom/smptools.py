'''
Created on 12.04.2012

@author: Osswald2
'''

from pyschunk.tools.util import enum
import time
import math


eCommModeType = enum()
eCommModeType.COMM_MODE_AUTO                     = eCommModeType.Next()
eCommModeType.COMM_MODE_RS232                    = eCommModeType.Next()
eCommModeType.COMM_MODE_CAN                      = eCommModeType.Next()
eCommModeType.COMM_MODE_PROFI_BUS                = eCommModeType.Next()
eCommModeType.COMM_MODE_RS232_NO_IMPULSE_MESSAGE = eCommModeType.Next()
eCommModeType.COMM_MODE_CANOPEN                  = eCommModeType.Next()
eCommModeType.COMM_MODE_NONE                     = eCommModeType.Next()
eCommModeType.MAX_COMMMODE                       = eCommModeType.Next()


eUserType = enum()
eUserType.USER_GUEST    = eUserType.Next()
eUserType.USER_DIAG     = eUserType.Next()
eUserType.USER_PROFI    = eUserType.Next()
eUserType.USER_ADVANCED = eUserType.Next()
eUserType.USER_ROOT     = eUserType.Next()
eUserType.USER_WIZARD   = eUserType.Next()
eUserType.MAX_USER      = eUserType.Next()

def GetTimestamp( t=None ):
    '''Return a string describing time t as hours:minutes:seconds:milliseconds.
    If t is not given then the current time is used
    '''
    if ( t is None ):
        t = time.time()
    now = time.localtime( t )
    return "%02d:%02d:%02d%s" % (now.tm_hour,now.tm_min,now.tm_sec,("%.3f" % (math.modf(t)[0]))[1:])


class ApplicationError(Exception):
    def __init__(self, value):
        self.value = value
    def __str__(self):
        return repr(self.value)


