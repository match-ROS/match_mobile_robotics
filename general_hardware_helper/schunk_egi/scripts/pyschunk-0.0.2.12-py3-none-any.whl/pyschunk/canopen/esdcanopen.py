#**************************************************************************
#
#            Copyright (c) 2004 - 2007 by esd electronic system design gmbh
#
#  This software is copyrighted by and is the sole property of
#  esd gmbh.  All rights, title, ownership, or other interests
#  in the software remain the property of esd gmbh. This
#  software may only be used in accordance with the corresponding
#  license agreement.  Any unauthorized use, duplication, transmission,
#  distribution, or disclosure of this software is expressly forbidden.
#
#  This Copyright notice may not be removed or modified without prior
#  written consent of esd gmbh.
#
#  esd gmbh, reserves the right to modify this software without notice.
#
#  electronic system design gmbh          Tel. +49-511-37298-0
#  Vahrenwalder Str 207                   Fax. +49-511-37298-68
#  30165 Hannover                         http://www.esd-electronics.com
#  Germany                                sales@esd-electronics.com
#
#**************************************************************************
#
#     Module Name: canopen.py
#         Version: 1.00
#   Original Date: 28-Oct-2004
#          Author: Michael Schoppe
#        Language: python
# Compile Options:
# Compile defines:
#       Libraries:
#    Link Options:
#
#    Entry Points:
#
#**************************************************************************
# Description
#
#
#
# Edit Date/Ver   Edit Description
# ==============  ===================================================
# OT   27/07/07   Removed additional __init__ in SYNC class which caused
#                  problems for Python 2.5
# MS   28/10/05   Written
# MS   14/03/05   add pdo.write method in class PDO to send data in one PDO
#                  with different lengths
# MS   01/06/05   add sdo.scan method in class SDO to scan object dictionary



import time
import ntcan          #Importiere Wrapper fuer NTCAN.DLL
import threading

import pyschunk.tools.util

from . import otherutil  # @UnresolvedImport
from . import esdutil    # @UnresolvedImport
from pyschunk.smpcom import ApplicationError

# debugging stuff
from pyschunk.tools.dbg import tDBG
import struct

dbg = tDBG( False, "red", description="pyschunk.canopen.esdcanopen" )
#dbg = tDBG( True, "red", description="pyschunk.canopen.esdcanopen" )

# Default values for Tx and Rx Queue Size and Time Out
default_TxQS = 100
default_TxTO = 2000
default_RxQS = 100
default_RxTO = 2000


# COB-IDs
NMT_ID = 0x000             #    0 ->    0
SYNC_ID = 0x080             #  128 ->  128
EMERGENCY_ID = 0x080        #  128 ->  129 bis 255
TIMESTAMP_ID = 0x100        #  256 ->  256
PDO1TX_ID = 0x180         #  384 ->  385 bis 511
PDO1RX_ID = 0x200         #  512 ->  513 bis 639
PDO2TX_ID = 0x280         #  640 ->  641 bis 767
PDO2RX_ID = 0x300         #  768 ->  769 bis 895
PDO3TX_ID = 0x380         #  896 ->  897 bis 1023
PDO3RX_ID = 0x400         # 1024 -> 1025 bis 1151
PDO4TX_ID = 0x480         # 1152 -> 1153 bis 1279
PDO4RX_ID = 0x500         # 1280 -> 1281 bis 1407
PDOxRX_ID = { 1: PDO1RX_ID, 2: PDO2RX_ID, 3: PDO3RX_ID, 4: PDO4RX_ID }
PDOxTX_ID = { 1: PDO1TX_ID, 2: PDO2TX_ID, 3: PDO3TX_ID, 4: PDO4TX_ID }
SDOTX_ID = 0x580             # 1408 -> 1409 bis 1535
SDORX_ID = 0x600             # 1536 -> 1537 bis 1663
SDO2TX_ID = 0x680             # Since build 2665 of the firmware a second SDO server is available (for nodes with node numbers below 0x40)
SDO2RX_ID = 0x6c0             #
NODEGUARD_ID = 0x700        # 1792 -> 1793 bis 1919
LSS_M_ID = 0x7E5
LSS_S_ID = 0x7E4

def GetNodeNoTPDONoFromID( cob_id ):
    '''Return a (node_no,tpdo_no) tuple with the node number node_no and the
    tpdo number tpdo_no corresponding to \a cob_id
    '''
    node_no = cob_id & 0x7f
    tpdo_no = (cob_id & 0x700)>>8

    return (node_no,tpdo_no)

def GetByteFromBytes(b):
    return b
def GetByteFromString(byte_value):
    return ord(byte_value)
def GetByteFromListOrTuple(byte_value):
    return (byte_value & 0xff)

def PrintableChar( byte ):
    if ( 0x20 <= byte and byte < 0x7f ):
        return "%c" % byte
    return "."

# NMT -------------------------------------------------------------------------
NMT_STARTREMOTENODE = 0x01
NMT_STOPREMOTENODE =  0x02
NMT_ENTERPREOPERATIONAL = 0x80
NMT_RESETNODE = 0x81
NMT_RESETCOMMUNICATION = 0x82

NMTstate =\
{\
    NMT_STARTREMOTENODE : "Start Node",\
    NMT_STOPREMOTENODE : "Stop Node",\
    NMT_ENTERPREOPERATIONAL : "Enter Preoperational",\
    NMT_RESETNODE : "Reset Node",\
    NMT_RESETCOMMUNICATION : "Reset Communication"\
}\


# SYNC ------------------------------------------------------------------------




# EMERGENCY -------------------------------------------------------------------

EmergencyErrorCodes =\
{\
    0x0000 : "Error Reset or no Error",\
    0x0001 : "tbd",\
    0x0002 : "tbd"\
}\


# PDO -------------------------------------------------------------------------





# SDO -----------------------------------------------------------------------
# download
SDO_SEG_REQ_INIT_DOWNLOAD_nBYTE = 0x21
SDO_SEG_REQ_INIT_DOWNLOAD_xBYTE = 0x22
SDO_SEG_REQ_INIT_DOWNLOAD_1BYTE = 0x2F
SDO_SEG_REQ_INIT_DOWNLOAD_2BYTE = 0x2B
SDO_SEG_REQ_INIT_DOWNLOAD_3BYTE = 0x27
SDO_SEG_REQ_INIT_DOWNLOAD_4BYTE = 0x23
SDO_SEG_RES_INIT_DOWNLOAD = 0x60
# upload
SDO_SEG_REQ_INIT_UPLOAD = 0x40
SDO_SEG_RES_INIT_UPLOAD_nBYTE =  0x41
SDO_SEG_RES_INIT_UPLOAD_xBYTE =  0x42
SDO_SEG_RES_INIT_UPLOAD_1BYTE = 0x4F
SDO_SEG_RES_INIT_UPLOAD_2BYTE = 0x4B
SDO_SEG_RES_INIT_UPLOAD_3BYTE = 0x47
SDO_SEG_RES_INIT_UPLOAD_4BYTE = 0x43
SDO_SEG_REQ_UPLOAD0 = 0x60
SDO_SEG_REQ_UPLOAD1 = 0x70


SDO_SEG_ABORT_TRANSFER =0x80

# error codes

eSDOerror = pyschunk.tools.util.enum()
eSDOerror.SDO_ERROR_NO_ERROR                                                                                    = 0
eSDOerror.SDO_ERROR_TOGGLE_BIT_NOT_ALTERNATED                                                                   = 0X05030000
eSDOerror.SDO_ERROR_SDO_PROTOCOL_TIMED_OUT                                                                      = 0x05040000
eSDOerror.SDO_ERROR_CLIENT_SERVER_COMMAND_SPECIFIER_NOT_VALID_OR_UNKNOWN                                        = 0x05040001
eSDOerror.SDO_ERROR_INVALID_BLOCK_SIZE                                                                          = 0x05040002
eSDOerror.SDO_ERROR_INVALID_SEQUENCE_NUMBER                                                                     = 0x05040003
eSDOerror.SDO_ERROR_CRC_ERROR_                                                                                  = 0x05040004
eSDOerror.SDO_ERROR_OUT_OF_MEMORY                                                                               = 0x05040005
eSDOerror.SDO_ERROR_UNSUPPORTED_ACCESS_TO_AN_OBJECT                                                             = 0x06010000
eSDOerror.SDO_ERROR_ATTEMPT_TO_READ_A_WRITE_ONLY_OBJECT                                                         = 0x06010001
eSDOerror.SDO_ERROR_ATTEMPT_TO_WRITE_A_READ_ONLY_OBJECT                                                         = 0x06010002
eSDOerror.SDO_ERROR_OBJECT_DOES_NOT_EXIST_IN_THE_OBJECT_DICTIONARY                                              = 0x06020000
eSDOerror.SDO_ERROR_OBJECT_CANNOT_BE_MAPPED_TO_THE_PDO                                                          = 0x06040041
eSDOerror.SDO_ERROR_THE_NUMBER_AND_LENGTH_OF_THE_OBJECTS_TO_BE_MAPPED_WOULD_EXCEED_PDO_LENGTH                   = 0x06040042
eSDOerror.SDO_ERROR_GENERAL_PARAMETER_INCOMPATIBILITY_REASON                                                    = 0x06040043
eSDOerror.SDO_ERROR_GENERAL_INTERNAL_INCOMPATIBILITY_IN_THE_DEVICE                                              = 0x06040047
eSDOerror.SDO_ERROR_ACCESS_FAILED_DUE_TO_AN_HARDWARE_ERROR                                                      = 0x06060000
eSDOerror.SDO_ERROR_DATA_TYPE_DOES_NOT_MATCH_LENGTH_OF_SERVICE_PARAMETER_DOES_NOT_MATCH                         = 0x06070010
eSDOerror.SDO_ERROR_DATA_TYPE_DOES_NOT_MATCH_LENGTH_OF_SERVICE_PARAMETER_TOO_HIGH                               = 0x06070012
eSDOerror.SDO_ERROR_DATA_TYPE_DOES_NOT_MATCH_LENGTH_OF_SERVICE_PARAMETER_TOO_LOW                                = 0x06070013
eSDOerror.SDO_ERROR_SUBINDEX_DOES_NOT_EXIST                                                                     = 0x06090011
eSDOerror.SDO_ERROR_VALUE_RANGE_OF_PARAMETER_EXCEEDED                                                           = 0x06090030
eSDOerror.SDO_ERROR_VALUE_OF_PARAMETER_WRITTEN_TOO_HIGH                                                         = 0x06090031
eSDOerror.SDO_ERROR_VALUE_OF_PARAMETER_WRITTEN_TOO_LOW                                                          = 0x06090032
eSDOerror.SDO_ERROR_MAXIMUM_VALUE_IS_LESS_THAN_MINIMUM_VALUE                                                    = 0x06090036
eSDOerror.SDO_ERROR_GENERAL_ERROR                                                                               = 0x08000000
eSDOerror.SDO_ERROR_DATA_CANNOT_BE_TRANSFERRED_OR_STORED_TO_THE_APPLICATION                                     = 0x08000020
eSDOerror.SDO_ERROR_DATA_CANNOT_BE_TRANSFERRED_OR_STORED_TO_THE_APPLICATION_BECAUSE_OF_LOCAL_CONTROL            = 0x08000021
eSDOerror.SDO_ERROR_DATA_CANNOT_BE_TRANSFERRED_OR_STORED_TO_THE_APPLICATION_BECAUSE_OF_THE_PRESENT_DEVICE_STATE = 0x08000022
eSDOerror.SDO_ERROR_OBJECT_DICTIONARY_DYNAMIC_GENERATION_FAILS_OR_NO_OBJECT_DICTIONARY_IS_PRESENT               = 0x08000023
eSDOerror.SDO_ERROR_NO_DATA_AVAILABLE                                                                           = 0x08000024


# NODEGUARD -------------------------------------------------------------------
NODEGUARD_BOOTUP_STATE = 0
NODEGUARD_STOPPED_STATE = 4
NODEGUARD_OPERATIONAL_STATE = 5
NODEGUARD_PREOPERATIONAL_STATE = 127

NODEGUARDstate =\
{\
    NODEGUARD_BOOTUP_STATE : "Bootup-State",\
    NODEGUARD_STOPPED_STATE : "Stopped-State",\
    NODEGUARD_OPERATIONAL_STATE : "Operational-State",\
    NODEGUARD_PREOPERATIONAL_STATE : "PreOperational-State"\
}\



# Functions ------------------------------------------------------------------
# SYNC
def SYNCsend (cif):
    dbg << "SYNCsend\n"
    cmsg = ntcan.CMSG()
    cmsg.canWriteByte(cif, SYNC_ID,0)
    del cmsg


# dictionary mapping net number to cSYNC objects
_sync = dict()

NB_RECORDS = 50 # number of last sync periods to record for sync time adjustment

def SYNC( net,baudrate,TxQS=default_TxQS,TxTO=default_TxTO,time_s=1.0,cob_id=SYNC_ID,with_nb_syncs=None, rpdos=None, external_sync=False ):
    '''Function to return a new or already existing cSYNC object
    '''
    if ( net in _sync ):
        s = _sync[net]
        assert( baudrate == s.cif.baudrate )
        #assert( TxQS == s.cif.TxQS ) # parameter not available in cif?
        assert( TxTO == s.cif.tx_timeout )
        assert( time_s == s.time_s )
        assert( cob_id == s.cob_id)
        assert( with_nb_syncs == s.nb_syncs) #?
        assert( external_sync == s.external_sync)
        s.rpdos += rpdos
        dbg << "SYNC adding RPDOs %r to existing cSYNC object\n" % rpdos
        return s

    # create new cSYNC
    s = cSYNC( net, baudrate, TxQS, TxTO, time_s, cob_id, with_nb_syncs, rpdos, external_sync )
    _sync[net] = s
    return s

class cSYNC (threading.Thread):
    def __init__(self,net,baudrate,TxQS=default_TxQS,TxTO=default_TxTO,time_s=1.0,cob_id=SYNC_ID,with_nb_syncs=None, rpdos=[], external_sync=False, adjust=False ):
        '''CTor: creat an object to send SYNC messages
        \param with_nb_syncs - if not None then it should be a number.
                               Every SYNC messages will then carry 4 bytes
                               data with the increasing number of syncs sent so far.
        \param rpdos - list of PDO objects. If not None then before each
                       SYNC r.Download() is called for all r in \a rpdos
        \param external_sync - flag, if True then no SYNC is actually sent,
                               instead on every SYNC received the \a rpdos are
                               downloaded.
        \param adjust - flag, if True then sleep time adjustment is done right away.
                        But it is better to trigger sleep time adjustment with
                        TriggerAdjustSleepTime() later on when
                        the application has started up completely.
        '''
        threading.Thread.__init__(self, name="cSYNC" )
        #CIF( net, rx_queuesize, rx_timeout, tx_timeout, tx_queuesize, ? )
        self.cif = ntcan.CIF( net, 1, 2000, TxTO, TxQS )
        self.cif.baudrate = baudrate
        self.cmsg = ntcan.CMSG_T()
        self.isrun=True
        self.time_s = time_s
        self.time_sleep_s = time_s
        self.adjust = adjust

        self.cob_id=cob_id
        self.nb_syncs = with_nb_syncs
        self.rpdos = rpdos
        self.external_sync = external_sync
        self.nb_starters = 0

#    def __init__(self,net,baudrate,time_s=1.0,cob_id=SYNC_ID):
#        threading.Thread.__init__( self, name="cSYNC" )
#        self.cif = ntcan.CIF(net,1,2000)
#        self.cif.baudrate = baudrate
#        self.cmsg = ntcan.CMSG()
#        self.isrun=True
#        self.time_s = time_s
#        self.cob_id=cob_id

    def start(self):
        '''Overloaded version of start() so that it can be called multiple times. All but the first call will be ignored
        '''
        if ( self.nb_starters == 0 ):
            dbg << "cSYNC starting\n"
            threading.Thread.start(self)
        else:
            dbg << "cSYNC ignoring %d-th start\n" % (self.nb_starters+2)
        self.nb_starters += 1

    def Download(self):
        if ( self.rpdos ):
            for rpdo in self.rpdos:
                rpdo.Download()

    def RunExternalSync( self ):
        self.cif.canIdAdd( self.cob_id )
        t = self.cif.timestamp  # required for CAN-USB/2, see ntcan.CIF.canIdAdd() @UnusedVariable
        try:
            while self.isrun:
                self.cmsg.canRead(self.cif)
                self.Download()
        finally:
            self.cif.canIdDelete( self.cob_id )

    def RunInternalSync( self ):
        while self.isrun:
            self.Download()
            self.send()
            self.AdjustSleepTime()
            time.sleep(self.time_sleep_s)

    def TriggerAdjustSleepTime(self):
        self.time_sleep_s_min = max( 0.010, self.time_s - 0.010 )
        self.time_sleep_s_max = self.time_s + 0.100
        self.time_periods = [self.time_s] * NB_RECORDS
        self.time_periods_index = 0
        self.time_sleep_s = self.time_s
        self.adjust=True
        self.t0 = None

    def AdjustSleepTime(self):
        '''Adjust sleep time after measuring NB_RECORDS syncs
        '''
        if (not self.adjust):
            return

        t = time.time()
        if ( self.t0 is None ):
            self.t0 = t
            return

        #--- record duration since last call
        self.time_periods[self.time_periods_index] = t-self.t0
        self.t0 = t

        self.time_periods_index += 1
        if ( self.time_periods_index < NB_RECORDS ):
            # keep recording
            return

        #--- recording finished:
        # - stop adjusting
        # - adjust sleep time
        self.adjust = False

        p_sorted = list(self.time_periods)
        p_sum = 0.0
        for p in p_sorted[5:-5]:
            p_sum += p
        avg = p_sum / float(NB_RECORDS-10)
        self.time_sleep_s = otherutil.ToRange( self.time_s - (avg-self.time_s), self.time_sleep_s_min, self.time_sleep_s_max )
        dbg << "cSYNC.AdjustSleepTime(): Adjusting to %fs for %fs" % (self.time_sleep_s,self.time_s)

    def run (self):
        dbg << "SYNC start %fs\n"%self.time_s
        try:
            if ( self.external_sync ):
                self.RunExternalSync()
            else:
                self.RunInternalSync()
        except IOError as e:
            if ( "TX error" in str(e) ):
                print("Syncer thread: Could not write CAN bus. Giving up.")
                print("  Are the module(s) still connected and powered?")
        finally:
            self.isrun = False
        dbg << "SYNC stopped\n"

    def send (self):
        dbg << "SYNC send\n"
        if (self.nb_syncs is None):
            self.cmsg.canWriteByte(self.cif,self.cob_id,0)
        else:
            self.cmsg.canWriteLong(self.cif,self.cob_id,4,self.nb_syncs )
            self.nb_syncs += 1

    def suspend (self):
        '''Request to suspend the thread.
        The execution of run() will only be suspended when as many calls to
        resume() as calls to start() have been seen.
        I.E the last starter of the thread calls resume().
        '''
        self.nb_starters -= 1
        if ( self.nb_starters <= 0 ):
            dbg << "SYNC suspend\n"
            self.isrun=False
            del _sync[ self.cif.net ]
        else:
            dbg << "SYNC suspend ignored, still %d starters using it\n" % self.nb_starters

    #def resume (self):
    # will not work now that we have the _sync singleton
    #    dbg << "SYNC resume\n"
    #    self.isrun=True
    #    self.run()

class SYNCreceiver:
    def __init__(self,net,baudrate,RxQS=default_RxQS,RxTO=default_RxTO,TxQS=default_TxQS,TxTO=default_TxTO):
        #CIF( net, rx_queuesize, rx_timeout, tx_timeout, tx_queuesize, ? )
        self.cif = ntcan.CIF( net, RxQS, RxTO, TxTO, TxQS )
        self.cif.baudrate = baudrate
        self.cmsg = ntcan.CMSG_T()
        self.cif.canIdAdd(SYNC_ID)
        t = self.cif.timestamp  # required for CAN-USB/2, see ntcan.CIF.canIdAdd() @UnusedVariable

    def Read(self):
        self.cmsg.canRead(self.cif)


# NMT Services
# node = 1..127 , 0=all nodes!
def NMTstart (cif,node):
    dbg << "NMTstart node: %d \n" %node
    cmsg = ntcan.CMSG()
    cmsg.canWriteByte(cif, NMT_ID, 2, NMT_STARTREMOTENODE, node)
    del cmsg

def NMTstop (cif,node):
    dbg << "NMTstop node: %d \n" %node
    cmsg = ntcan.CMSG()
    cmsg.canWriteByte(cif, NMT_ID, 2, NMT_STOPREMOTENODE, node)
    del cmsg

def NMTpreop (cif,node):
    dbg << "NMTpreop node: %d \n" %node
    cmsg = ntcan.CMSG()
    cmsg.canWriteByte(cif, NMT_ID, 2, NMT_ENTERPREOPERATIONAL, node)
    del cmsg

def NMTreset (cif,node):
    dbg << "NMTreset node: %d \n" %node
    cmsg = ntcan.CMSG()
    cmsg.canWriteByte(cif, NMT_ID, 2, NMT_RESETNODE, node)
    del cmsg

def NMTresetcomm (cif,node):
    dbg << "NMTresetcomm node: %d \n"  %node
    cmsg = ntcan.CMSG()
    cmsg.canWriteByte(cif, NMT_ID, 2, NMT_RESETCOMMUNICATION, node)
    del cmsg

#
class NMT:
    def __init__(self,net,baudrate,TxQS=default_TxQS,TxTO=default_TxTO):
        #CIF( net, rx_queuesize, rx_timeout, tx_timeout, tx_queuesize, ? )
        self.cif = ntcan.CIF( net, 1, 2000, TxTO, TxQS )
        self.cif.baudrate=baudrate
        self.cmsg = ntcan.CMSG()
        #del cmsg
    def start (self,node):
        dbg << "NMTstart node: %d \n"  %node
        self.cmsg.canWriteByte(self.cif, NMT_ID, 2, NMT_STARTREMOTENODE, node)
    def stop (self,node):
        dbg << "NMTstop node: %d \n"  %node
        self.cmsg.canWriteByte(self.cif, NMT_ID, 2, NMT_STOPREMOTENODE, node)
    def preop (self,node):
        dbg << "NMTpreop node: %d \n"  %node
        self.cmsg.canWriteByte(self.cif, NMT_ID, 2, NMT_ENTERPREOPERATIONAL, node)
    def reset (self,node):
        dbg << "NMTreset node: %d \n"  %node
        self.cmsg.canWriteByte(self.cif, NMT_ID, 2, NMT_RESETNODE, node)
    def resetcomm (self,node):
        dbg << "NMTresetcomm node: %d \n"  %node
        self.cmsg.canWriteByte(self.cif, NMT_ID, 2, NMT_RESETCOMMUNICATION, node)



# NODEGUARD -------------------------------------------------------------------------
def NODEGUARDrequest (cif,node,state=0,result=True):
    cif.canIdAdd(NODEGUARD_ID+node)
    t = cif.timestamp  # required for CAN-USB/2, see docstring of ntcan.CIF.canIdAdd() @UnusedVariable
    cmsg = ntcan.CMSG_T()
    dbg << "Nodeguard RTR %d -> \n"  % node,
    try:
        #raise NotImplementedError( "Must provide expected dlen" ) # see http://de.wikipedia.org/wiki/Controller_Area_Network#Remote_Frame
        cmsg.canWriteByte(cif, NODEGUARD_ID+node, 0x10+1)     # 0x10=rtr  +1=len, see http://www.softing.com/home/en/industrial-automation/products/can-bus/more-can-open/node-life-guarding/protocol.php?navanchor=3010646
        try:
            cmsg.canRead(cif)
            state = cmsg.data.c[0] & 0x7F
            toggle = cmsg.data.c[0] >> 7
            # dbg << cmsg
            if cmsg.len == 1:
                dbg << NODEGUARDstate.get(state)
        except IOError as errno:
                dbg << "I/O error(%s): \n"  % (errno)
                result=False
                toggle=None
    finally:
        cif.canIdDelete(NODEGUARD_ID+node)
        del cmsg
    return result,state,toggle

class HeartbeatProducer (threading.Thread):
    def __init__(self,net,baudrate,node,time_s,state=NODEGUARD_BOOTUP_STATE,TxQS=1,TxTO=1000):
        threading.Thread.__init__(self, name="HeartbeatProducer" )
        self.net=net                    # logical CAN Network [0, 255]
        #self.RxQS=1                            # RxQueueSize [0, 10000]
        #self.RxTO=2000                    # RxTimeOut in Millisconds
        self.TxQS=TxQS                    # TxQueueSize [0, 10000]
        self.TxTO=TxTO                # TxTimeOut in Millseconds
        #self.cif = ntcan.CIF(self.net,self.RxQS,self.RxTO,self.TxTO,self.TxQS)
        self.node=node
        #CIF( net, rx_queuesize, rx_timeout, tx_timeout, tx_queuesize, ? )
        self.cif = ntcan.CIF( self.net, 1, 2000, self.TxTO, self.TxQS )
        self.cif.baudrate=baudrate
        self.cmsg = ntcan.CMSG()
        self.time_s = time_s
        self.state = state & 0x7f
    def run (self):
        self.cmsg.canWriteByte(self.cif, (NODEGUARD_ID+self.node),1,self.state)
        dbg << "Heartbeat node %d: 0x%0.2X (first frame)\n"  %(self.node,self.state)
        while 1:
            time.sleep(self.time_s)
            #self.state=(self.state+0x80)&0xFF # for heartbit the toggle bit must be 0 according to http://www.canopensolutions.com/english/about_canopen/guarding_heartbeat.shtml
            self.cmsg.canWriteByte(self.cif, (NODEGUARD_ID+self.node),1,self.state)
            dbg << "Heartbeat node %d: 0x%0.2X\n"  %(self.node,self.state)
    def changeState (self,state):
        lstate = self.state&0x80
        self.state = state&0x7F
        self.state = lstate|self.state
    def suspend (self):
        dbg << "HeartbeatProducer suspend"
        self.isrun=False
    def resume (self):
        dbg << "HeartbeatProducer resume"
        self.isrun=True
        self.run()


class HeartbeatConsumer (threading.Thread):
    def __init__(self,net,baudrate,node,time_s,RxQS=1000,RxTO=None,TxQS=1,TxTO=1000):
        threading.Thread.__init__(self, name="HeartbeatConsumer" )
        self.net=net                    # logical CAN Network [0, 255]
        self.RxQS=RxQS                  # RxQueueSize [0, 10000]
        self.RxTO=int(time_s*1000)      # RxTimeOut in Millisconds
        self.TxQS=TxQS                  # TxQueueSize [0, 10000]
        self.TxTO=TxTO                  # TxTimeOut in Millseconds
        #CIF( net, rx_queuesize, rx_timeout, tx_timeout, tx_queuesize, ? )
        self.cif = ntcan.CIF( self.net, self.RxQS, self.RxTO, self.TxTO, self.TxQS )
        self.cif.baudrate=baudrate
        self.cmsg = ntcan.CMSG()
        self.node=node
        self.time_s = time_s
        self.state = 0
        self.isrun=True
    def run (self):
        self.cif.canIdAdd(NODEGUARD_ID+self.node)
        t = self.cif.timestamp  # required for CAN-USB/2, see ntcan.CIF.canIdAdd() @UnusedVariable
        try:
            while self.isrun==True:
                try:
                    self.cmsg.canRead(self.cif)
                    self.state = self.cmsg.data.c[0]
                    dbg << "Heartbeat Consumer node: %d \n"  %self.node,
                    if self.cmsg.len == 1:
                        dbg << NODEGUARDstate.get(self.cmsg.data.c[0] & 0x7F)
                    else:
                        dbg << "Wrong cmsg.len: %d\n" %self.cmsg.len
                except IOError as errno:
                    dbg << "Heartbeat Consumer node: %d -> I/O error(%s)\n"  %(self.node,errno)
                    #dbg << "I/O error(%s, %d): \n"  % (errno,errno)
        finally:
            self.cif.canIdDelete(NODEGUARD_ID+self.node)
    def suspend (self):
        dbg << "HeartbeatConsumer suspend"
        self.isrun=False
    def resume (self):
        dbg << "HeartbeatConsumer resume"
        self.isrun=True
        self.run()



class NODEGUARD (threading.Thread):
    def __init__(self,net,baudrate,RxQS=default_RxQS,RxTO=default_RxTO,TxQS=default_TxQS,TxTO=default_TxTO,time_s=1.0):
        threading.Thread.__init__(self, name="NODEGUARD")
        #CIF( net, rx_queuesize, rx_timeout, tx_timeout, tx_queuesize, ? )
        self.cif = ntcan.CIF( net, RxQS, RxTO, TxTO, TxQS )
        self.cif.baudrate=baudrate
        self.cmsg = ntcan.CMSG()
        self.isrun=True
        self.time_s = time_s
    def run (self,node):
        dbg << "NODEGUARD start %fs\n" %self.time_s
        while self.isrun:
            self.request(node)
            time.sleep(self.time_s)
        dbg << "NODEGUARD stopped"
    def request (self,node,state=0,result=True):
        dbg << "NODEGUARD RTR %d -> \n"  % node,
        self.cif.canIdAdd(NODEGUARD_ID+node)
        t = self.cif.timestamp  # required for CAN-USB/2, see ntcan.CIF.canIdAdd() @UnusedVariable
        try:
            raise NotImplementedError( "Must provide expected dlen" ) # see http://de.wikipedia.org/wiki/Controller_Area_Network#Remote_Frame
            self.cmsg.canWriteByte(self.cif, NODEGUARD_ID+node, 0x10) # rtr
            try:
                self.cmsg.canRead(self.cif)
                state = self.cmsg.data.c[0]
                if self.cmsg.len == 1:
                    dbg << NODEGUARDstate.get(self.cmsg.data.c[0] & 0x7F)
                else:
                    dbg << "Wrong cmsg.len %d\n" %(self.cmsg.len)
            except IOError as errno:
                    dbg << "I/O error(%s): \n"  % (errno)
                    result=False
        finally:
            self.cif.canIdDelete(NODEGUARD_ID+node)
        return result,state
    def suspend (self):
        dbg << "NODEGUARD suspend"
        self.isrun=False
    def resume (self):
        dbg << "NODEGUARD resume"
        self.isrun=True
        self.run()


# EMERGENCY
class EMERGENCY:
    def __init__(self,net,baudrate,RxQS=default_RxQS,RxTO=default_RxTO,TxQS=default_TxQS,TxTO=default_TxTO):
        #CIF( net, rx_queuesize, rx_timeout, tx_timeout, tx_queuesize, ? )
        self.cif = ntcan.CIF( net, RxQS, RxTO, TxTO, TxQS )
        self.cif.baudrate = baudrate
        self.cmsg = ntcan.CMSG()
        #del cmsg
    def monitor (self,node,emerg_error_code=0,error_reg=0,no_of_errors=0,manu_specific_error_field=0,result=True):
        self.cif.canIdAdd(EMERGENCY_ID+node)
        t = self.cif.timestamp  # required for CAN-USB/2, see ntcan.CIF.canIdAdd() @UnusedVariable
        try:
            #dbg << "EMERGENCYmonitor node: %d -> \n"  %(node),
            try:
                self.cmsg.canRead(self.cif)
                if self.cmsg.len == 8:
                    result = True
                    emerg_error_code=self.cmsg.data.s[0]
                    error_reg=self.cmsg.data.c[2]
                    no_of_errors=self.cmsg.data.c[3]
                    manu_specific_error_field=self.cmsg.data.l[1]
                    dbg << "EMERGENCYmonitor node: %d -> \n"  %(node),
                    dbg << "0x%0.4X  0x%0.2X  %d  0x%0.8X\n"  %(emerg_error_code,error_reg,no_of_errors,manu_specific_error_field)
                else:
                    result = False

            except IOError as errno: #@UnusedVariable
                    #dbg << "I/O error(%s): \n"  % (errno)
                    result = False
        finally:
            self.cif.canIdDelete(EMERGENCY_ID+node)
        return result



# SDO -------------------------------------------------------------------------

class SDOException( IOError ):
    '''Exception class for reporting errors during SDO response reception.
    '''
    def __init__(self, value, response=None):
        self.value = value
        self.response = response
    def __str__(self):
        return "%r, response=%r" % (self.value, self.response)

class SDOExceptionAbort( IOError ):
    '''Exception class for reporting an SDO abort received from the remote SDO server
    '''
    def __init__(self, value, response=None):
        self.value = value
        self.response = response
    def __str__(self):
        return "%r, response=%r" % (self.value, self.response)

# A tuple with all the SDO abort codes that should trigger a retry of the SDO transfer:
g_retry_sdo_abort_codes = (eSDOerror.SDO_ERROR_NO_ERROR,
                           eSDOerror.SDO_ERROR_TOGGLE_BIT_NOT_ALTERNATED,
                           eSDOerror.SDO_ERROR_SDO_PROTOCOL_TIMED_OUT,
                           #eSDOerror.SDO_ERROR_CLIENT_SERVER_COMMAND_SPECIFIER_NOT_VALID_OR_UNKNOWN,
                           #eSDOerror.SDO_ERROR_INVALID_BLOCK_SIZE,
                           eSDOerror.SDO_ERROR_INVALID_SEQUENCE_NUMBER,
                           eSDOerror.SDO_ERROR_CRC_ERROR_,
                           #eSDOerror.SDO_ERROR_OUT_OF_MEMORY,
                           #eSDOerror.SDO_ERROR_UNSUPPORTED_ACCESS_TO_AN_OBJECT,
                           #eSDOerror.SDO_ERROR_ATTEMPT_TO_READ_A_WRITE_ONLY_OBJECT,
                           #eSDOerror.SDO_ERROR_ATTEMPT_TO_WRITE_A_READ_ONLY_OBJECT,
                           #eSDOerror.SDO_ERROR_OBJECT_DOES_NOT_EXIST_IN_THE_OBJECT_DICTIONARY,
                           #eSDOerror.SDO_ERROR_OBJECT_CANNOT_BE_MAPPED_TO_THE_PDO,
                           #eSDOerror.SDO_ERROR_THE_NUMBER_AND_LENGTH_OF_THE_OBJECTS_TO_BE_MAPPED_WOULD_EXCEED_PDO_LENGTH,
                           #eSDOerror.SDO_ERROR_GENERAL_PARAMETER_INCOMPATIBILITY_REASON,
                           #eSDOerror.SDO_ERROR_GENERAL_INTERNAL_INCOMPATIBILITY_IN_THE_DEVICE,
                           #eSDOerror.SDO_ERROR_ACCESS_FAILED_DUE_TO_AN_HARDWARE_ERROR,
                           #eSDOerror.SDO_ERROR_DATA_TYPE_DOES_NOT_MATCH_LENGTH_OF_SERVICE_PARAMETER_DOES_NOT_MATCH,
                           #eSDOerror.SDO_ERROR_DATA_TYPE_DOES_NOT_MATCH_LENGTH_OF_SERVICE_PARAMETER_TOO_HIGH,
                           #eSDOerror.SDO_ERROR_DATA_TYPE_DOES_NOT_MATCH_LENGTH_OF_SERVICE_PARAMETER_TOO_LOW,
                           #eSDOerror.SDO_ERROR_SUBINDEX_DOES_NOT_EXIST,
                           #eSDOerror.SDO_ERROR_VALUE_RANGE_OF_PARAMETER_EXCEEDED,
                           #eSDOerror.SDO_ERROR_VALUE_OF_PARAMETER_WRITTEN_TOO_HIGH,
                           #eSDOerror.SDO_ERROR_VALUE_OF_PARAMETER_WRITTEN_TOO_LOW,
                           #eSDOerror.SDO_ERROR_MAXIMUM_VALUE_IS_LESS_THAN_MINIMUM_VALUE,
                           eSDOerror.SDO_ERROR_GENERAL_ERROR,
                           #eSDOerror.SDO_ERROR_DATA_CANNOT_BE_TRANSFERRED_OR_STORED_TO_THE_APPLICATION,
                           #eSDOerror.SDO_ERROR_DATA_CANNOT_BE_TRANSFERRED_OR_STORED_TO_THE_APPLICATION_BECAUSE_OF_LOCAL_CONTROL,
                           #eSDOerror.SDO_ERROR_DATA_CANNOT_BE_TRANSFERRED_OR_STORED_TO_THE_APPLICATION_BECAUSE_OF_THE_PRESENT_DEVICE_STATE,
                           #eSDOerror.SDO_ERROR_OBJECT_DICTIONARY_DYNAMIC_GENERATION_FAILS_OR_NO_OBJECT_DICTIONARY_IS_PRESENT,
                           eSDOerror.SDO_ERROR_NO_DATA_AVAILABLE)

class SDO:
    '''Class to perform SDO (Service Data Object) access.
    \remark
    - If multiple threads are used each one requires its own SDO instance!
    '''
    def __init__(self,net,baudrate,RxQS=default_RxQS,RxTO=default_RxTO,TxQS=default_TxQS,TxTO=default_TxTO, force_first_sdo_server=False ):
        '''
        \param force_first_sdo_server - False : default: use secondary SDO server, if available
                                      - True  : use primary SDO server
        The provided force_first_sdo_server behavior can be overridden by each call to read* / write*
        '''
        self.cif = ntcan.CIF( net, RxQS, RxTO, TxTO, TxQS )
        self.cif.baudrate = baudrate
        self.cmsg = ntcan.CMSG()
        self.force_first_sdo_server = force_first_sdo_server
        #global dbg
        #self.dbg = dbg
        self.dbg = tDBG( False, "red", description="pyschunk.canopen.esdcanopen.SDO" )
        self.sdo_ids = dict()
        self.ids_added = dict()

    def __del__(self):
        try:
            #print( "Deleting SDO %r" % self )
            try:
                self.cif.canIdDelete( 0x000, 0x7ff )
            except ValueError:
                pass
            del self.cif
            self.dbg.Remove()
        except AttributeError:
            pass

    def read_old(self,node,index,subindex,data=0,result=True,add_id=True,tries=5, retry_time_s=0.010):
        sdo_txid = SDOTX_ID+node
        rdindex = 0
        lstr = [] #empty
        if ( add_id ):
            self.cif.canIdAdd(SDOTX_ID+node)
            t = self.cif.timestamp  # required for CAN-USB/2, see ntcan.CIF.canIdAdd() @UnusedVariable
        try:
            self.dbg << "SDO.read() node: %d index: 0x%0.4X subindex: 0x%0.2X\n" %(node,index,subindex),
            self.cmsg.canWriteByte(self.cif, SDORX_ID+node,8, SDO_SEG_REQ_INIT_UPLOAD,index & 0xFF,(index & 0xFF00)>>8,subindex,0,0,0,0)
            try:
                tries_o = tries
                while tries_o > 0:
                    tries_o -= 1
                    rc = self.cmsg.canRead(self.cif)
                    if ( rc != 0 or self.cmsg.len != 8 or self.cmsg.id != sdo_txid):
                        msg = "Invalid SDO response! rc/id/len=%d/0x%08x/%d (expected 0/0x%08x/8)." % (rc,self.cmsg.id,self.cmsg.len,sdo_txid)
                        if ( tries_o > 0 ):
                            self.dbg << msg + " Trying again.\n"
                            time.sleep(retry_time_s)
                            continue
                        raise IOError( msg )
                    #print( "received %s" % esdutil.CMSG_ToString(self.cmsg) )

                    #--- Check received index and subindex:
                    rdindex = self.cmsg.data.c[1] + self.cmsg.data.c[2] *256
                    rdsubindex = self.cmsg.data.c[3]
                    if (rdindex != index or rdsubindex != subindex):
                        msg = "Invalid SDO response: index/subindex, expected 0x%04x/%d, got 0x%04x/%d." % (index, subindex, rdindex, rdsubindex)
                        if ( tries_o > 0 ):
                            self.dbg << msg + " Trying again.\n"
                            time.sleep(retry_time_s)
                            continue
                        raise IOError( msg )
                    # read index and subindex is OK

                    #--- Check received scs (server command specifier):
                    if self.cmsg.data.c[0] == SDO_SEG_ABORT_TRANSFER:
                        self.dbg << "error: 0x%0.8X %s\n"  % (self.cmsg.data.l[1],eSDOerror.GetName( self.cmsg.data.l[1] ))
                        result = False
                        data = self.cmsg.data.l[1]
                    elif self.cmsg.data.c[0] == SDO_SEG_RES_INIT_UPLOAD_1BYTE:
                        data = self.cmsg.data.l[1] & 0x000000FF
                        self.dbg << "data: %d  0x%02x %c\n"  % (data,
                                                                self.cmsg.data.c[4],
                                                                PrintableChar(self.cmsg.data.c[4]))
                    elif self.cmsg.data.c[0] == SDO_SEG_RES_INIT_UPLOAD_2BYTE:
                        data = self.cmsg.data.l[1] & 0x0000FFFF
                        self.dbg << "data: %d  0x%02x %02x  %c%c\n"  % (data,
                                                                        self.cmsg.data.c[4],self.cmsg.data.c[5],
                                                                        PrintableChar(self.cmsg.data.c[4]),
                                                                        PrintableChar(self.cmsg.data.c[5]))
                    elif self.cmsg.data.c[0] == SDO_SEG_RES_INIT_UPLOAD_3BYTE:
                        data = self.cmsg.data.l[1] & 0x00FFFFFF
                        self.dbg << "data: %d  0x%02x %02x %02x  %c%c%c\n"  % (data,
                                                                               self.cmsg.data.c[4],self.cmsg.data.c[5],self.cmsg.data.c[6],
                                                                               PrintableChar(self.cmsg.data.c[4]),
                                                                               PrintableChar(self.cmsg.data.c[5]),
                                                                               PrintableChar(self.cmsg.data.c[6]))
                    elif (self.cmsg.data.c[0] == SDO_SEG_RES_INIT_UPLOAD_4BYTE or
                          self.cmsg.data.c[0] == SDO_SEG_RES_INIT_UPLOAD_xBYTE):
                        data = self.cmsg.data.l[1]
                        self.dbg << "data: %d  0x%02x %02x %02x %02x  %c%c%c%c\n"  % (data,
                                                                                      self.cmsg.data.c[4],self.cmsg.data.c[5],self.cmsg.data.c[6],self.cmsg.data.c[7],
                                                                                      PrintableChar(self.cmsg.data.c[4]),
                                                                                      PrintableChar(self.cmsg.data.c[5]),
                                                                                      PrintableChar(self.cmsg.data.c[6]),
                                                                                      PrintableChar(self.cmsg.data.c[7]) )
                    elif self.cmsg.data.c[0] == SDO_SEG_RES_INIT_UPLOAD_nBYTE:
                        dlen = self.cmsg.data.l[1]
                        cmd=0x60
                        while dlen>0:
                            #self.dbg << dlen
                            self.cmsg.canWriteByte(self.cif, SDORX_ID+node,8, cmd)
                            try:
                                tries_i = tries
                                while tries_i > 0:
                                    tries_i -= 1

                                    rc = self.cmsg.canRead(self.cif)
                                    if ( rc != 0 or self.cmsg.len != 8 or self.cmsg.id != sdo_txid):
                                        msg = "Invalid SDO segment response! rc/id/len=%d/0x%08x/%d (expected 0/0x%08x/8)." % (rc,self.cmsg.id,self.cmsg.len,sdo_txid)
                                        if ( tries_i > 0 ):
                                            self.dbg << msg + " Trying again.\n"
                                            time.sleep(retry_time_s)
                                            continue
                                        raise IOError( msg )
                                    self.dbg << "received SDO segment response %s\n" % esdutil.CMSG_ToString(self.cmsg)
                                    break

                                if ((self.cmsg.data.c[0]&0x10) != (cmd&0x10)):
                                    self.__error(node,index,subindex,0x05030000) # toggle bit wrong
                                    break
                                else:
                                    if (self.cmsg.data.c[0] & 0x01):
                                        # Last data segment:
                                        #if (self.cmsg.data.c[0] & 0x0E) == 0:
                                        #    pass # no data
                                        #else:
                                        dlen = 7 - ((self.cmsg.data.c[0] & 0x0E)>>1)
                                        for i in range(dlen):
                                            lstr.append(chr(self.cmsg.data.c[i+1]))
                                        break
                                    else:
                                        # further data segments will follow:
                                        dlen = dlen-7
                                        for i in range(7):
                                            lstr.append(chr(self.cmsg.data.c[i+1]))
                            except IOError as errno:
                                    self.dbg << "I/O error(%s): \n"  % (errno)
                                    result = False
                            if cmd==0x60: cmd=0x70
                            else: cmd=0x60
                        data = "".join(lstr)
                        #self.dbg << data << "\n"
                    elif SDO_SEG_RES_INIT_UPLOAD_xBYTE==0x42:
                        self.dbg << "Download not supported! Command: 0x%0.2X\n"  %  self.cmsg.data.c[0]
                        result = False
                    else:
                        self.dbg << "Unknown Command: 0x%0.2X\n"  %  self.cmsg.data.c[0]
                        result = False
                    break
            #            self.dbg << self.cif.msg_count
            except IOError as errno:
                    self.dbg << "I/O error(%s): \n"  % (errno)
                    result = False
        finally:
            if ( add_id ):
                self.cif.canIdDelete(SDOTX_ID+node)
        return result,data

    def GetSDO_IDs(self, node, force_first_sdo_server=None ):
        '''Return a pair (sdo_rxid,sdo_txid) of the SDO server CAN-IDs to use
        for \a node.

        \param node - node number
        \param force_first_sdo_server - Flag, to determine which SDO server to use
               - If None (default) then use self.force_first_sdo_server specified
                 at creation time of the self object
               - If True then the CAN-IDs for the first (mandatory) SDO server
                 of the node are returned. (Even if  previously the second SDO
                 server was used for that node)
               - If False then we return the previously found SDO server CAN-IDs
                 of \a node.
                 - If this is the first access then we try to access the
                   second (optional) SDO server first and use it on success,
                 - Else we return the first SDO server (without trying to access).
                 This access testing will only be done once, successive calls
                 will use the previous result (unless force_first_sdo_server is True).
        '''
        if ( force_first_sdo_server is None ):
            force_first_sdo_server = self.force_first_sdo_server

        if ( force_first_sdo_server ):
            return (SDORX_ID + node, SDOTX_ID + node )
        try:
            return self.sdo_ids[ node ]
        except KeyError:
            # First time to do SDO communication with node node,
            # so determin which SDO server to use:

            if ( node < 0x40 ):
                #--- try second SDO server:
                sdo2_rxid = SDO2RX_ID + node
                sdo2_txid = SDO2TX_ID + node
                try:
                    old_rx_timeout = self.cif.rx_timeout
                    self.cif.rx_timeout = 100
                    self.cif.canIdAdd(sdo2_txid)
                    t = self.cif.timestamp  # required for CAN-USB/2, see ntcan.CIF.canIdAdd() @UnusedVariable

                    index = 0x1201
                    subindex = 0
                    self.cmsg.canWriteByte( self.cif, sdo2_rxid, 8,
                                            SDO_SEG_REQ_INIT_UPLOAD,                     # ccs: client command specifier
                                            index & 0xFF, (index & 0xFF00)>>8, subindex, # m: multiplexer
                                            0,0,0,0)                                     # reserved

                    rc = self.cmsg.canRead(self.cif)
                    if ( rc == 0 and self.cmsg.len == 8 and self.cmsg.id == sdo2_txid):
                        # received correct answer from 2nd SDO server, so use it:
                        self.sdo_ids[ node ] = (sdo2_rxid,sdo2_txid)
                        return self.sdo_ids[ node ]
                except IOError:
                    # no response from second SDO server
                    pass
                finally:
                    self.cif.canIdDelete(sdo2_txid)
                    self.cif.rx_timeout = old_rx_timeout

            #--- second SDO server failed or is not available:
            self.sdo_ids[ node ] = (SDORX_ID + node, SDOTX_ID + node )
            return self.sdo_ids[ node ]

    def read( self, node, index, subindex, data=0, result=True, add_id=True, tries=5, retry_time_s=0.010, force_first_sdo_server=None):
        '''Perform SDO read access (upload).
        Read object \a index / \a subindex from the object dictionary of \a node.
        The length of the data to read is determined automatically and the
        proper SDO transfer (expedited/segmented) is chosen automaticially.
        Block-transfer is not supported.

        \param force_first_sdo_server - see descripton in self.GetSDO_IDs()

        The request/response ping pong is retried up to \a tries times on
        each level. I.e.
        - each response is retried up to \a tries times,
        - if that fails then the corresponding request is resent up to \a tries times
        In case of an SDO abort from the SDO server the whole transfer
        is retried if that makes sense (depends on the reported SDO abort code).

        \return (result,data) - result: False for error, True for OK
                                data: if result is True then the received data is returned here:
                                      - a signed integer for expedited transfers
                                      - a byte string for non expedited (segmented) transfers
        '''
        (sdo_rxid, sdo_txid) = self.GetSDO_IDs( node, force_first_sdo_server )
        if ( add_id and not sdo_txid in self.ids_added ):
            self.cif.canIdAdd(sdo_txid)
            self.ids_added[ sdo_txid ] = True
            t = self.cif.timestamp  # required for CAN-USB/2, see ntcan.CIF.canIdAdd() @UnusedVariable

        # Seems to be required with CAN-USB/2 in order not to get confused by older SDO responses:
        self.cif.canPurge()

        self.dbg << "SDO.read(): node=%d index=0x%04X subindex=%d\n" %(node,index,subindex),

        tries_w1 = tries
        while ( tries_w1 > 0 ):
            tries_w1 -= 1
            the_exception = None
            try:
                # Send upload initiate request:
                self.cmsg.canWriteByte( self.cif, sdo_rxid, 8,
                                        SDO_SEG_REQ_INIT_UPLOAD,                     # ccs: client command specifier
                                        index & 0xFF, (index & 0xFF00)>>8, subindex, # m: multiplexer
                                        0,0,0,0)                                     # reserved

                # Receive and handle upload response(s):
                return (True, self.HandleUpload( sdo_rxid, sdo_txid, index, subindex, tries, retry_time_s ))

            except SDOExceptionAbort as e:
                # Transfer was aborted by remote SDO server.
                # So we have to check if retrying makes sense at all:
                the_exception = e
                if ( tries_w1 <= 0 or not e.response.d in g_retry_sdo_abort_codes ):
                    return (False,data)
                    raise # reraise
                time.sleep(retry_time_s)
            except SDOException as e:
                # Invalid response received
                #   Just to be sure abort the SDO transfer:
                the_exception = e
                self.dbg << "caught %s for canWriteByte! Aborting SDO transfer\n" % (e)
                self.SDOAbort( node, index, subindex, eSDOerror.SDO_ERROR_SDO_PROTOCOL_TIMED_OUT, force_first_sdo_server )
                # So we have to check if retrying makes sense at all:
                if ( tries_w1 <= 0 ):
                    return (False,data)
                    raise # reraise
                time.sleep(retry_time_s)
            except IOError as e:
                # IOError happens on receive timeout only.
                # So we have to start all over and repeat the request again.
                #   Just to be sure abort the SDO transfer:
                the_exception = e
                self.SDOAbort( node, index, subindex, eSDOerror.SDO_ERROR_SDO_PROTOCOL_TIMED_OUT, force_first_sdo_server )

                if ( tries_w1 <= 0 ):
                    return (False,data)
                    raise # reraise
                # no need to sleep after timeout
            # We only get here in case an exception was caught and if we
            # still have tries left. Thus the exception e was saved to the_exception and tries_w1 > 0.
            self.dbg << "SDO.read(): caught %r. Try %d/%d, failure ignored, retrying.\n" % (the_exception,tries-tries_w1,tries)

        # \remark: Adding and deleting CAN IDs with cif.canIdAdd/cif.canIdDelete causes communication errors
        # with newer CAN-USB/2 (but not with older CAN-USB-mini). So do not delete the CAN ID here
        # \remark: solved, see bug 1603 comment #2. But still keeping the IDs added should be faster...

        # We should never get here
        raise RuntimeError( "Should not happen!" )

    def HandleUpload( self, sdo_rxid, sdo_txid, index, subindex, tries, retry_time_s ):
        '''Internal helper: receive and handle SDO responses with retries

        \return data - received data: an integer for expedited transfers, else a byte string
        '''
        tries_r1 = tries
        while tries_r1 > 0:
            tries_r1 -= 1
            the_exception = None
            try:
                response = self.GetSDOResponse( sdo_txid, expected_scs=2, expected_index=index, expected_subindex=subindex )
                # SDO abort transfer by server raises SDOExceptionAbort and is handled by caller

                if ( response.e == 1 ):
                    #--- expedited transfer
                    if ( response.s == 0 ):
                        # d contains an unspecified number of bytes => assume all and let caller decide
                        response.n = 0    # set n to 0 to indicate 4-0=4 bytes are available in d
                    for i in range(4-response.n,4):
                        response.d[i] = 0 # make sure that unused data is 0 before conversion by c2i32r
                    data = esdutil.c2i32r( *response.d )

                    if ( self.dbg.GetFlag() ):
                        self.dbg << "SDO.HandleUploadResponse(): Expedited upload: %d  ( " % (data)
                        for i in range(0,4-response.n):
                            self.dbg << "0x%02x " % (response.d[i])
                        self.dbg << "  "
                        for i in range(0,4-response.n):
                            self.dbg << "%c" % (PrintableChar(self.cmsg.data.c[i]))
                        self.dbg << ")\n"
                    return data
                    #--

                elif ( response.s == 0 ):
                    raise SDOException( "Invalid SDO response, size indicator s is 0, expected 1.", response )
                else:
                    #--- non expedited (segmented) transfer:
                    dlen = esdutil.c2lr( *response.d )

                    return self.HandleUploadSegments( sdo_rxid, sdo_txid, dlen, tries, retry_time_s )
                    #--
            # SDOExceptionAbort raised by remote SDO server must be handled by caller
            # IOError raised by receive timeout must be handled by caller
            except SDOException as e:
                # Something invalid was received. This might happen if this SDO
                # transfer interleaves with the SDO transfer of some other SDO
                # client, or messages got lost, or ...
                # So we retry to receive here without sending the
                # upload segment request again:
                the_exception = e
                if ( tries_r1 <= 0 ):
                    raise # reraise
                # No need to sleep here since nothing is re-sent

            # We only get here in case an exception was caught and if we
            # still have tries left. Thus the exception e was saved to the_exception and tries_r1 > 0.
            self.dbg << "SDO.HandleUploadResponseSegment(): caught %r. Try %d/%d, failure ignored, retrying.\n" % (the_exception,tries-tries_r1,tries_r1)
        # We should never get here
        raise RuntimeError( "Should not happen!" )

    def HandleUploadSegments( self, sdo_rxid, sdo_txid, dlen, tries, retry_time_s ):
        '''Handle uploading of SDO segments after initiation has been done already.
        Here we send the upload segment requests and receive and handle the upload segment responses.
        In case of a retryable failure we retry send/receive up to \a tries times

        \return the received data as a byte string

        Exceptions:
        - IOError       - In case of a receive timeout after retrying failed
        - SDOException  - In case of an invalid message length after retrying failed
        - SDOException  - In case of an invalid message ID after retrying failed
        - SDOException  - In case of an invalid return code from canRead after retrying failed
        - SDOExceptionAbort - In case of a received SDO abort transfer (the actual response will be a member of the exception)
        - SDOException  - In case of an unexpected scs (the actual response will be a member of the exception) after retrying failed
        - SDOException  - In case of an unexpected t (the actual response will be a member of the exception) after retrying failed
        - SDOException  - In case of an unexpected c (the actual response will be a member of the exception) after retrying failed
        - SDOException  - In case of an unexpected index/subindex (the actual response will be a member of the exception) after retrying failed
        '''
        data = ""
        t = 0
        while (dlen>0):
            if ( dlen > 7 ):
                c = 0  # expect more segments
            else:
                c = 1  # expect final segment

            tries_w2 = tries
            while tries_w2 > 0:
                tries_w2 -= 1
                the_exception = None
                try:
                    # Send upload segment request:
                    self.cmsg.canWriteByte( self.cif, sdo_rxid, 8,
                                            SDO_SEG_REQ_UPLOAD0 | (t<<4),  # ccs: client command specifier
                                            0,0,0,0,0,0,0 )                # reserved

                    # Receive and handle upload response:
                    response = self.HandleUploadResponseSegment( sdo_txid, t, c, tries, retry_time_s )
                    data += "".join( map(chr,response.d) )
                    dlen -= 7-response.n
                    t = 1-t # toggle toggle bit
                    break # success, so stop retrying in while tries_w2 > 0

                # SDOExceptionAbort raised by remote SDO server must be handled by caller
                except SDOException as e:
                    # Something invalid was received that could not be handled
                    # by the underlying HandleUploadResponseSegment(). This
                    # might happen if this SDO transfer interleaves with the
                    # SDO transfer of some other SDO client, or messages got
                    # lost, or ...
                    # So we retry to receive here _with_ resending the
                    # upload segment request again:
                    the_exception = e
                    if ( tries_w2 <= 0 ):
                        raise # reraise
                    time.sleep(retry_time_s)
                except IOError as e:
                    # IOError happens on receive timeout only.
                    # So we try to start sending the upload segment request again only.
                    the_exception = e
                    if ( tries_w2 <= 0 ):
                        raise # reraise
                    # No need to sleep after timeout
                # We only get here in case an exception was caught and if we
                # still have tries left. Thus the exception e was saved to the_exception and tries_w2 > 0.
                self.dbg << "SDO.HandleUploadSegments(): caught %r in upload segment. Try %d/%d, failure ignored, retrying.\n" % (the_exception,tries-tries_w2,tries_w2)
                # retry in while treis_w2 > 0
        return data

    def HandleUploadResponseSegment( self, sdo_txid, expected_t, expected_c, tries, retry_time_s ):
        '''
        '''
        tries_r2 = tries
        while tries_r2 > 0:
            tries_r2 -= 1
            the_exception = None
            try:
                return self.GetSDOResponse( sdo_txid, expected_scs=0, expected_t=expected_t, expected_c=expected_c )

            # SDOExceptionAbort raised by remote SDO server must be handled by caller
            # IOError raised by receive timeout must be handled by caller
            except SDOException as e:
                # Something invalid was received. This might happen if this
                # SDO transfer interleaves with the SDO transfer of some other
                # SDO client, or messages get lost, or ...
                # So we retry to receive again here _without_ sending the
                # upload segment request again:
                the_exception = e
                if ( tries_r2 <= 0 ):
                    raise # reraise
                # No need to sleep here since nothing is re-resent

            # We only get here in case an exception was caught (thus e is defined and tries_w1 > 0)
            self.dbg << "SDO.HandleUploadResponseSegment(): caught %r. Try %d/%d, failure ignored, retrying.\n" % (the_exception,tries-tries_r2,tries_r2)
        # We should never get here
        raise RuntimeError( "Should not happen!" )


    def GetSDOResponse( self, sdo_txid, expected_scs=None, expected_t=None, expected_c=None, expected_index=None, expected_subindex=None  ):
        '''Internal helper: Receive and decode a SDO response.
        \return A pyschunk.tools.util.Struct with elements set according to the received SDO response according to
                file://D:/home/osswald2/SCHUNK/CANopen/doc/CiA/301_v04020005_complete.pdf#page=52

        here the members of the response struct in the different cases:
        - upload segment response:
          - scs=0, t, n, c, d, is_error=False
        - download segment response:
          - scs=1, t, is_error=False
        - initiate upload response:
          - scs=2, n, e, s, index, subindex, d, is_error=False
        - initiate download response:
          - scs=3, index, subindex, is_error=False
        - abort transfer:
          - scs=4, index, subindex, d, is_error=True
        - other responses (block upload/download) not implemented yet
          all possible members are initialized to None

        Checks:
        - If expected_scs is given then the received scs is checked. If the actually
          received value does not match then an SDOException is raised.
        - If expected_t is given then the received toggle bit t is checked, if available.
          If the actually received value does not match then an SDOException is raised.
        - If expected_c is given then the received c bit is checked, if available.
          If the actually received value does not match then an SDOException is raised.
        - If expected_index and expected_subindex are given then these are checked. If
          the actual values do not match then an SDOException is raised.

        Exceptions:
        - IOError       - In case of a receive timeout
        - SDOExceptionAbort - In case of a received SDO abort transfer (the actual response will be a member of the exception)
        - SDOException  - In case of an invalid message length
        - SDOException  - In case of an invalid message ID
        - SDOException  - In case of an invalid return code from canRead
        - SDOException  - In case of an unexpected scs (the actual response will be a member of the exception)
        - SDOException  - In case of an unexpected t (the actual response will be a member of the exception)
        - SDOException  - In case of an unexpected c (the actual response will be a member of the exception)
        - SDOException  - In case of an unexpected index/subindex (the actual response will be a member of the exception)
        '''
        rc = self.cmsg.canRead(self.cif) # this might yield an IOError: Receive operation timed out
        #try:
        #    rc = self.cmsg.canRead(self.cif) # this might yield an IOError: Receive operation timed out
        #except IOError,e:
        #    print( "Caught %r" % e )
        #    print( "sdo.cif.rx_timeout=%r" % self.cif.rx_timeout )
        #    print( "sdo.cif.tx_timeout=%r" % self.cif.tx_timeout )
        #    print( "Reraising" )
        #    raise
        if ( rc != 0 ):
            self.dbg << "SDO.GetSDOResponse(): Invalid return code 0x%x from canRead, expected 0.\n" % (rc)
            raise SDOException( "Invalid return code 0x%x from canRead, expected 0." % (rc) )
        self.dbg << "SDO.GetSDOResponse(): received=%s\n" % (esdutil.CMSG_ToString(self.cmsg)) # TODO: comment out

        if ( self.cmsg.len != 8 ):
            raise SDOException( "Invalid CAN message length %d, expected 8." % (self.cmsg.len) )
        if ( self.cmsg.id != sdo_txid ):
            raise SDOException( "Invalid CAN message ID 0x%03x, expected 0x%03x." % (self.cmsg.id,sdo_txid) )

        response = pyschunk.tools.util.Struct()
        # decode response according to file://D:/home/osswald2/SCHUNK/CANopen/doc/CiA/301_v04020005_complete.pdf#page=52
        response.scs = self.cmsg.data.c[0] >> 5
        response.is_error = False
        response.t = response.n = response.c = response.d = response.e = response.s = response.index = response.subindex = None

        if ( response.scs==0 ):
            # upload segment response:
            # see file://D:/home/osswald2/SCHUNK/CANopen/doc/CiA/301_v04020005_complete.pdf#page=56
            response.t = (self.cmsg.data.c[0] >> 4) & 0x01
            response.n = (self.cmsg.data.c[0] >> 1) & 0x07
            response.c = (self.cmsg.data.c[0] >> 0) & 0x01
            response.d = self.cmsg.data.c[1:(8-response.n)]
            if ( (not (expected_c is None)) and response.c != expected_c ):
                raise SDOException( "Invalid SDO response: c-bit is %d, expected %d." % (response.c,expected_c), response )

        elif ( response.scs==1 ):
            # download segment response:
            # see file://D:/home/osswald2/SCHUNK/CANopen/doc/CiA/301_v04020005_complete.pdf#page=53
            response.t = (self.cmsg.data.c[0] >> 4) & 0x01

        elif ( response.scs==2 ):
            # initiate upload response:
            # see file://D:/home/osswald2/SCHUNK/CANopen/doc/CiA/301_v04020005_complete.pdf#page=55
            response.n = (self.cmsg.data.c[0] >> 2) & 0x03
            response.e = (self.cmsg.data.c[0] >> 1) & 0x01
            response.s = (self.cmsg.data.c[0] >> 0) & 0x01
            self.FillAndCheckIndexSubindex( response, expected_index, expected_subindex )
            response.d = self.cmsg.data.c[4:]

        elif ( response.scs==3 ):
            # initiate download response:
            # see file://D:/home/osswald2/SCHUNK/CANopen/doc/CiA/301_v04020005_complete.pdf#page=52
            self.FillAndCheckIndexSubindex( response, expected_index, expected_subindex )

        elif ( response.scs==4 ):
            # abort transfer
            # see file://D:/home/osswald2/SCHUNK/CANopen/doc/CiA/301_v04020005_complete.pdf#page=65
            response.index = esdutil.c2wr( *self.cmsg.data.c[1:3] )
            response.subindex = self.cmsg.data.c[3]
            response.d = esdutil.c2lr( *self.cmsg.data.c[4:8] )
            response.is_error = True
            raise SDOExceptionAbort( "SDO transfer aborted by server: %r." % eSDOerror.GetName( response.d ), response )

        elif ( response.scs==5 ):
            # block download
            # see file://D:/home/osswald2/SCHUNK/CANopen/doc/CiA/301_v04020005_complete.pdf#page=58
            raise NotImplementedError( "Invalid SDO response: SDO block download not implemented!" )

        elif ( response.scs==6 ):
            # block upload
            # see file://D:/home/osswald2/SCHUNK/CANopen/doc/CiA/301_v04020005_complete.pdf#page=62
            raise NotImplementedError( "Invalid SDO response: SDO block upload not implemented!" )
        else:
            raise NotImplementedError( "Invalid SDO response: SDO unknown server command specifier scs %d received, expected %r."  % (response.scs, expected_scs) )

        self.dbg << "SDO.GetSDOResponse(): parsed response=%r\n" % (response)  # TODO: comment out

        if ( (not (expected_scs is None)) and response.scs != expected_scs ):
            raise SDOException( "Invalid SDO response: server command specifier scs %d, expected %d." % (response.scs,expected_scs), response )
        if ( (not (expected_t is None)) and (not (response.t is None)) and response.t != expected_t ):
            raise SDOException( "Invalid SDO response: toggle t %d, expected %d." % (response.t,expected_t), response )

        return response

    def FillAndCheckIndexSubindex( self, response, expected_index=None, expected_subindex=None ):
        '''Internal helper: Fill the index and subindex members of response from self.cmsg.
        If expected_index and expected_subindex is given then these are checked. If
        the received ones do not match then an SDOException is raised.
        '''
        response.index = esdutil.c2wr( *self.cmsg.data.c[1:3] )
        response.subindex = self.cmsg.data.c[3]
        if ( (not (expected_index is None)) and response.index != expected_index ):
            raise SDOException( "Invalid SDO response: index 0x%04x, expected 0x%04x." % (response.index,expected_index), response )
        if ( (not (expected_subindex is None)) and response.subindex != expected_subindex ):
            raise SDOException( "GetSDOResponse: Invalid subindex 0x%02x, expected 0x%02x." % (response.subindex,expected_subindex), response )
        # no need to return as response is an object that is given by reference and modified


    def readFloat( self, node_no, index, subindex, name="?", tries=1, retry_time_s=0.010, force_first_sdo_server=None ):
        '''\param force_first_sdo_server - see descripton in self.GetSDO_IDs()
        '''
        result,raw = self.read( node_no, index=index, subindex=subindex, tries=tries, retry_time_s=retry_time_s, force_first_sdo_server=force_first_sdo_server )
        if ( not result ):
            # reading failed?
            raise ApplicationError( "Could not read %r parameter from OV 0x%04x/%d via SDO (No such module? Insufficient rights?)" % (name, index, subindex) )
        return esdutil.i322f( raw )

    def SDOAbort( self, node, index, subindex, error_code, force_first_sdo_server ):
        '''Internal helper: Send an SDO abort transfer according to
        file://D:/home/osswald2/SCHUNK/CANopen/doc/CiA/301_v04020005_complete.pdf#page=65
        \param force_first_sdo_server - see descripton in self.GetSDO_IDs()
        '''
        # Send expedited initiate download request:
        (sdo_rxid, sdo_txid) = self.GetSDO_IDs( node, force_first_sdo_server )  # @UnusedVariable
        self.cmsg.canWriteByte( self.cif, sdo_rxid, 8,
                                SDO_SEG_ABORT_TRANSFER,                     # cs + x
                                index & 0xFF,(index & 0xFF00)>>8, subindex, # multiplexer
                                *esdutil.l2cr( error_code ) )

    def writeFloat ( self, node, index, subindex, data, tries=1, retry_time_s=0.010, force_first_sdo_server=None ):
        '''\param force_first_sdo_server - see descripton in self.GetSDO_IDs()
        '''
        self.write(node,index,subindex,struct.pack("f",data),tries,retry_time_s, force_first_sdo_server=force_first_sdo_server )

    def write1Byte ( self, node, index, subindex, data, tries=1, retry_time_s=0.010, force_first_sdo_server=None ):
        '''\param force_first_sdo_server - see descripton in self.GetSDO_IDs()
        '''
        self.write(node,index,subindex,[ data&0xFF ],tries,retry_time_s, force_first_sdo_server=force_first_sdo_server  )

    def write2Byte ( self, node, index, subindex, data, tries=1, retry_time_s=0.010, force_first_sdo_server=None ):
        '''\param force_first_sdo_server - see descripton in self.GetSDO_IDs()
        '''
        self.write(node,index,subindex,[ data&0xFF, (data>>8)&0xFF ],tries,retry_time_s, force_first_sdo_server=force_first_sdo_server  )

    def write4Byte ( self, node, index, subindex, data, tries=1, retry_time_s=0.010, force_first_sdo_server=None ):
        '''\param force_first_sdo_server - see descripton in self.GetSDO_IDs()
        '''
        self.write(node,index,subindex,[ data&0xFF, (data>>8)&0xFF, (data>>16)&0xFF, (data>>24)&0xFF ],tries,retry_time_s, force_first_sdo_server=force_first_sdo_server  )

    def write( self, node, index, subindex, data, tries=1, retry_time_s=0.010, force_first_sdo_server=None ):
        '''Write \a data to \a node at \a index / \a subindex.
        In case of error try \a tries times with a delay of \a retry_time_s seconds between tries.
        \param force_first_sdo_server - see descripton in self.GetSDO_IDs()
        '''
        ##--- FIXed: remove this:
        #t = threading.current_thread()
        #if ( t.name != "MainThread"):
        #    print( "SDO.write in thread %r %d" % (t.name,t.ident) )
        ##--
        (sdo_rxid, sdo_txid) = self.GetSDO_IDs( node, force_first_sdo_server )
        if ( not sdo_txid in self.ids_added ):
            self.cif.canIdAdd(sdo_txid)
            self.ids_added[ sdo_txid ] = True
            t = self.cif.timestamp  # required for CAN-USB/2, see ntcan.CIF.canIdAdd() @UnusedVariable

        # TODO: do we need that:
        # As reported in D:\home\osswald2\SCHUNK\CANopen\feedback\2013-08-14_LWA_Tool\fehler.pdf
        # sometimes (e.g. on Jan's Desktop) the CAN read after a CAN write below yields a
        # previous SDO response
        #self.cmsg.canTake(self.cif)

        # Seems to be required with CAN-USB/2 in order not to get confused by older SDO responses:
        self.cif.canPurge()

        # TODO: restructure the code below using the improved features of self.GetSDOResponse() like the new self.read does.
        self.dbg << "SDO.write() node: %d index/subindex=0x%04X/%d data: %r\n" %(node,index,subindex,data),

        if ( type( data ) is bytes ):
            GetByte = GetByteFromBytes
        elif ( type( data ) is str ):
            GetByte = GetByteFromString
        elif ( type( data ) is list or type( data ) is tuple ):
            GetByte = GetByteFromListOrTuple
        else:
            raise TypeError( "Type of data not recognized. Must be str or list/tuple of bytes." )

        nb_bytes = len(data)
        if nb_bytes == 0:
            raise ValueError( "No data to write via SDO (length is 0)!" )
        while tries > 0:
            if nb_bytes == 1:
                # Send expedited initiate download request:
                self.cmsg.canWriteByte(self.cif, sdo_rxid,8, SDO_SEG_REQ_INIT_DOWNLOAD_1BYTE,index & 0xFF,(index & 0xFF00)>>8,subindex,GetByte(data[0]),0,0,0)
            elif nb_bytes == 2:
                # Send expedited initiate download request:
                self.cmsg.canWriteByte(self.cif, sdo_rxid,8, SDO_SEG_REQ_INIT_DOWNLOAD_2BYTE,index & 0xFF,(index & 0xFF00)>>8,subindex,GetByte(data[0]),GetByte(data[1]),0,0)
            elif nb_bytes == 3:
                # Send expedited initiate download request:
                self.cmsg.canWriteByte(self.cif, sdo_rxid,8, SDO_SEG_REQ_INIT_DOWNLOAD_3BYTE,index & 0xFF,(index & 0xFF00)>>8,subindex,GetByte(data[0]),GetByte(data[1]),GetByte(data[2]),0)
            elif nb_bytes == 4:
                # Send expedited initiate download request:
                self.cmsg.canWriteByte(self.cif, sdo_rxid,8, SDO_SEG_REQ_INIT_DOWNLOAD_4BYTE,index & 0xFF,(index & 0xFF00)>>8,subindex,GetByte(data[0]),GetByte(data[1]),GetByte(data[2]),GetByte(data[3]))
            else:
                # Send normal initiate download request:
                self.cmsg.canWriteByte( self.cif, sdo_rxid,8,
                                        SDO_SEG_REQ_INIT_DOWNLOAD_nBYTE,
                                        *(esdutil.w2cr( index )
                                          +(subindex,)
                                          +(esdutil.l2cr( nb_bytes ))) )

            # Receive expedited download response or initiate download response:
            response = self.GetSDOResponse(sdo_txid)

            if ( response.scs == 3 and response.index == index and response.subindex == subindex ):
                # Response indicates OK
                if ( nb_bytes <=4 ):
                    # Quick exit on all done and OK
                    return
                else:
                    # stop retrying and start transfering normal data
                    break

            # Response indicates something is wrong:
            tries -= 1
            # check response:
            if ( response.is_error ):
                msg = "Node %d: SDO transfer aborted by module! index/subindex=0x%04X/%d (expected 0x%04X/%d), error: 0x%08X %r"  % (node,response.index,response.subindex,index,subindex,response.d,eSDOerror.GetName(response.d))
                if ( tries > 0 ):
                    self.dbg << "Ignoring error %r\nTries left %d\n" % (msg,tries)
                else:
                    raise IOError( msg )

            elif ( response.scs != 3 or response.index != index or response.subindex != subindex ):
                msg = "Node %d: Invalid SDO response! scs/index/subdindex=%d/0x%04X/%d (expected 3/0x%04x/%d)" % (node,response.scs,response.index,response.subindex,index,subindex)
                if ( tries > 0 ):
                    self.dbg << "Ignoring error %r\nTries left %d\n" % (msg,tries)
                else:
                    raise IOError( msg )
            else:
                msg = "Node %d: Unexpected response %r." % (node,response)
                raise IOError( msg )

            # wait some time before retrying:
            time.sleep( retry_time_s )

        # if we get here with tries==0 then the response is something unexpected
        assert( tries > 0 )

        # Keep on sending/receiving download segment requests/response without retrying:
        send_index = 0
        t = 0 # toggle bit
        while send_index < nb_bytes:
            # Send download segment request:
            n = max(0,7-(nb_bytes-send_index)) # number of bytes in seg-data that do not contain segment data

            if ( send_index+7 < nb_bytes ):
                c = 0 # more segments to be downloaded
            else:
                c = 1 # no more segments to be downloaded
            self.cmsg.canWriteByte( self.cif, sdo_rxid,8,
                                    (t<<4) | (n<<1) | c,
                                    *(list(map(GetByte,data[send_index:send_index+7-n]))) )

            # Receive download segment response:
            response = self.GetSDOResponse(sdo_txid)
            if ( response.scs == 1 and response.t == t ):
                # Thats what we expect
                pass
            elif ( response.is_error ):
                msg = "Node %d: SDO download segment transfer aborted by module! index/subindex=0x%04X/%d (expected 0x%04X/%d), error: 0x%08X %r."  % (node,response.index,response.subindex,index,subindex,response.d,eSDOerror.GetName(response.d))
                #self.dbg << "raising %r\n" % (msg)
                raise IOError( msg )
            elif ( response.scs != 1 or response.t != t ):
                msg = "Node %d: Invalid SDO download segment response! scs/t=%d/%d (expected 1/%d)." % (node,response.scs,response.t,t)
                #self.dbg << "raising %r\n" % (msg)
                raise IOError( msg )
            else:
                msg = "Node %d: Unexpected response %r." % (node,response)
                #self.dbg << "raising %r\n" % (msg)
                raise IOError( msg )

            send_index += 7-n
            t = 1-t

        # \remark: Adding and deleting CAN IDs with cif.canIdAdd/cif.canIdDelete causes communication errors
        # with newer CAN-USB/2 (but not with older CAN-USB-mini). So do not delete the CAN ID here
        # \remark: solved, see bug 1603 comment #2. But still keeping the IDs added should be faster...


    def __error (self,node,index,subindex,error,result=True, force_first_sdo_server=None):
        '''\param force_first_sdo_server - see descripton in self.GetSDO_IDs()
        '''
        #rdindex = 0
        self.dbg << "error: 0x%0.8X %s\n" %(error,eSDOerror.GetName(error))
        #(sdo_rxid, sdo_txid) = self.GetSDO_IDs( node, force_first_sdo_server )
        #self.cmsg.canWriteByte(self.cif, sdo_rxid,8, SDO_SEG_REQ_INIT_DOWNLOAD_4BYTE,index & 0xFF,(index & 0xFF00)>>8,subindex,error&0xFF,(error>>8)&0xFF,(error>>16)&0xFF,(error>>24)&0xFF, force_first_sdo_server=force_first_sdo_server)
        return result
    def scan (self,node,startindex=0,stopindex=0,data=0,result=True, force_first_sdo_server=None):
        '''\param force_first_sdo_server - see descripton in self.GetSDO_IDs()
        '''
        # TODO: restructure the code below using the improved features of self.GetSDOResponse() like the new self.read does.
        (sdo_rxid, sdo_txid) = self.GetSDO_IDs( node, force_first_sdo_server )
        self.cif.canIdAdd(sdo_txid)
        t = self.cif.timestamp  # required for CAN-USB/2, see ntcan.CIF.canIdAdd() @UnusedVariable
        try:
            #self.dbg << "SDOscan node: %d index: 0x%0.4X subindex: 0x%0.2X -> " %(node,index,subindex),
            for index in range (startindex,stopindex+1,1):
                rdindex = 0
                subindex=0
                result = True
                while result == True:
                    lstr = [] #empty
                    self.cmsg.canWriteByte(self.cif, sdo_rxid,8, SDO_SEG_REQ_INIT_UPLOAD,index & 0xFF,(index & 0xFF00)>>8,subindex,0,0,0,0)
                    try:
                        self.cmsg.canRead(self.cif)
                        if self.cmsg.len == 8:
                            rdindex = self.cmsg.data.c[1] + self.cmsg.data.c[2] *256
                            if (rdindex == index and self.cmsg.data.c[3] == subindex):
                                if self.cmsg.data.c[0] == SDO_SEG_ABORT_TRANSFER:
                                    #self.dbg << "error: 0x%0.8X %s\n"  % (self.cmsg.data.l[1],eSDOerror.GetName(self.cmsg.data.l[1]))
                                    result = False
                                    data = self.cmsg.data.l[1]
                                elif self.cmsg.data.c[0] == SDO_SEG_RES_INIT_UPLOAD_xBYTE:
                                    data = self.cmsg.data.l[1]
                                    self.dbg << "SDOscan node: %d index: 0x%0.4X subindex: 0x%0.2X -> " %(node,index,subindex),
                                    self.dbg << "data: %d  0x%0.8X\n"  % (data,data)
                                elif self.cmsg.data.c[0] == SDO_SEG_RES_INIT_UPLOAD_1BYTE:
                                    data = self.cmsg.data.l[1] & 0xFF
                                    self.dbg << "SDOscan node: %d index: 0x%0.4X subindex: 0x%0.2X -> " %(node,index,subindex),
                                    self.dbg << "data: %d  0x%0.2X\n"  % (data,data),
                                    if (self.cmsg.data.c[4] >= 0x20): self.dbg << "%c\n"  % self.cmsg.data.c[4]
                                    else: self.dbg << " "
                                elif self.cmsg.data.c[0] == SDO_SEG_RES_INIT_UPLOAD_2BYTE:
                                    data = self.cmsg.data.l[1] & 0xFFFF
                                    self.dbg << "SDOscan node: %d index: 0x%0.4X subindex: 0x%0.2X -> " %(node,index,subindex),
                                    self.dbg << "data: %d  0x%0.4X\n"  % (data,data),
                                    if (self.cmsg.data.c[4] >= 0x20): self.dbg << "%c\n"  % self.cmsg.data.c[4],
                                    else: self.dbg << " ",
                                    if (self.cmsg.data.c[5] >= 0x20): self.dbg << "%c\n"  % self.cmsg.data.c[5]
                                    else: self.dbg << " "
                                elif self.cmsg.data.c[0] == SDO_SEG_RES_INIT_UPLOAD_3BYTE:
                                    data = self.cmsg.data.l[1] & 0xFFFFFF
                                    self.dbg << "SDOscan node: %d index: 0x%0.4X subindex: 0x%0.2X -> " %(node,index,subindex),
                                    self.dbg << "data: %d  0x%0.6X\n"  % (data,data),
                                    if (self.cmsg.data.c[4] >= 0x20): self.dbg << "%c\n"  % self.cmsg.data.c[4],
                                    else: self.dbg << " ",
                                    if (self.cmsg.data.c[5] >= 0x20): self.dbg << "%c\n"  % self.cmsg.data.c[5],
                                    else: self.dbg << " ",
                                    if (self.cmsg.data.c[6] >= 0x20): self.dbg << "%c\n"  % self.cmsg.data.c[6]
                                    else: self.dbg << " "
                                elif self.cmsg.data.c[0] == SDO_SEG_RES_INIT_UPLOAD_4BYTE:
                                    data = self.cmsg.data.l[1]
                                    self.dbg << "SDOscan node: %d index: 0x%0.4X subindex: 0x%0.2X -> " %(node,index,subindex),
                                    self.dbg << "data: %d  0x%0.8X\n"  % (data,data),
                                    if (self.cmsg.data.c[4] >= 0x20): self.dbg << "%c\n"  % self.cmsg.data.c[4],
                                    else: self.dbg << " ",
                                    if (self.cmsg.data.c[5] >= 0x20): self.dbg << "%c\n"  % self.cmsg.data.c[5],
                                    else: self.dbg << " ",
                                    if (self.cmsg.data.c[6] >= 0x20): self.dbg << "%c\n"  % self.cmsg.data.c[6],
                                    else: self.dbg << " ",
                                    if (self.cmsg.data.c[7] >= 0x20): self.dbg << "%c\n"  % self.cmsg.data.c[7]
                                    else: self.dbg << " "
                                elif SDO_SEG_RES_INIT_UPLOAD_nBYTE==0x41:
                                    dlen = self.cmsg.data.l[1]
                                    cmd=0x60
                                    self.dbg << "SDOscan node: %d index: 0x%0.4X subindex: 0x%0.2X -> " %(node,index,subindex),
                                    while dlen>0:
                                        self.cmsg.canWriteByte(self.cif, sdo_rxid,8, cmd)
                                        try:
                                            self.cmsg.canRead(self.cif)
                                            if ((self.cmsg.data.c[0]&0x10) != (cmd&0x10)):
                                                self.__error(node,index,subindex,0x05030000, force_first_sdo_server) # toggle bit wrong
                                                break
                                            else:
                                                if (self.cmsg.data.c[0] & 0x01):         # last data
                                                    dlen = 7 - ((self.cmsg.data.c[0] & 0x0E)>>1)
                                                    for i in range(dlen):
                                                        lstr.append(chr(self.cmsg.data.c[i+1]))
                                                    break
                                                else:
                                                    dlen = dlen-7
                                                    for i in range(7):
                                                        lstr.append(chr(self.cmsg.data.c[i+1]))
                                        except IOError as errno:
                                                self.dbg << "I/O error(%s): \n"  % (errno)
                                                result = False
                                        if cmd==0x60: cmd=0x70
                                        else: cmd=0x60
                                    data = "".join(lstr)
                                    self.dbg << data
                                elif SDO_SEG_RES_INIT_UPLOAD_xBYTE==0x42:
                                    self.dbg << "Download not supported! Command: 0x%0.2X\n"  %  self.cmsg.data.c[0]
                                    result = False
                                else:
                                    self.dbg << "Unknown Command: 0x%0.2X\n"  %  self.cmsg.data.c[0]
                                    result = False
                #            self.dbg << self.cif.msg_count
                        else:
                            self.dbg << "unknown"
                            result = False
                    except IOError as errno:
                        self.dbg << "I/O error(%s): \n"  % (errno)
                        result = False
                        return result,data
                    subindex = subindex + 1
        finally:
            self.cif.canIdDelete(sdo_txid)
        return result,data

    def ScanForNodes( self, node_range, index, subindex, force_first_sdo_server=None, must_have_object=False ):
        '''Scan for nodes in node_range. If any answer is received for index/subindex
        from node n then n is contained in the returned list depending on must_have_object.
        \param force_first_sdo_server - see descripton in self.GetSDO_IDs()
        \param must_have_object
          - if must_have_object is False (default) then node n will be reported,
            even if the node does not have the object index/subindex (and thus responded with "Abort: Object does not exist...")
          - if must_have_object is True then node n will only be reported, if
            the object index/subindex is actually available in the node
        '''
        #scanning took add+write=0.049000s read=0.001000s del=0.003000s total 0.053000s

        if ( force_first_sdo_server is None ):
            force_first_sdo_server = self.force_first_sdo_server

        #old_flag = self.dbg.GetFlag()
        #self.dbg.SetFlag(True)
        #scan_start = time.time()
        node_nos = set()
        # send all requests at once without handling answers yet
        for n in node_range:
            if ( n < 0x40 and not force_first_sdo_server  ):
                sdo_rxid = SDO2RX_ID + n
                sdo_txid = SDO2TX_ID + n
            else:
                sdo_rxid = SDORX_ID + n
                sdo_txid = SDOTX_ID + n
            self.cif.canIdAdd(sdo_txid)

            self.cmsg.canWriteByte( self.cif, sdo_rxid, 8,
                                    SDO_SEG_REQ_INIT_UPLOAD,                     # ccs: client command specifier
                                    index & 0xFF, (index & 0xFF00)>>8, subindex, # m: multiplexer
                                    0,0,0,0)                                     # reserved


        t = self.cif.timestamp  # required for CAN-USB/2, see ntcan.CIF.canIdAdd() @UnusedVariable
        #scan_add_write = time.time()
        old_rx_timeout = self.cif.rx_timeout
        self.cif.rx_timeout = 50 # set timeout for first response
        while True:
            try:
                rc = self.cmsg.canRead(self.cif) # this might yield an IOError: Receive operation timed out
                if ( rc != 0 ):
                    self.dbg << "ScanForNodes(): Invalid return code 0x%x from canRead, expected 0.\n" % (rc)
                    continue

                if ( self.cmsg.len != 8 ):
                    self.dbg << "ScanForNodes(): Invalid response, len=%d, expected 8.\n" % (self.cmsg.len)
                    continue

                if ( must_have_object and self.cmsg.data.c[0] == SDO_SEG_ABORT_TRANSFER ):
                    self.dbg << "ScanForNodes(): must have object but transfer aborted: 0x%0.8X %s\n"  % (self.cmsg.data.l[1],eSDOerror.GetName( self.cmsg.data.l[1] ))
                    continue

                if ( SDOTX_ID < self.cmsg.id  and self.cmsg.id <= SDOTX_ID+127 ):
                    node = int(self.cmsg.id - SDOTX_ID)
                else:
                    node = int(self.cmsg.id - SDO2TX_ID)
                if ( 1 <= node and node <= 128 ):
                    node_nos.add(node)
                    self.dbg << "ScanForNodes found node %d" % (node)
                else:
                    self.dbg << "ScanForNodes found invalid node %d" % (node)
            except IOError as e:
                self.dbg << "ScanForNodes.read(): caught %r.\n" % (e)
                break
            finally:
                self.cif.rx_timeout = 1 # reduce timeout for following responses as much as possible (setting to 0 will wait for ever)

        #scan_read = time.time()
        self.cif.rx_timeout = old_rx_timeout
        nodes_not_found = []
        for n in node_range:
            if n < 0x40 and not n in node_nos:
                nodes_not_found.append(n)

            if ( n < 0x40 and not force_first_sdo_server  ):
                sdo_txid = SDO2TX_ID + n
            else:
                sdo_txid = SDOTX_ID + n
            self.cif.canIdDelete(sdo_txid)

        if ( not force_first_sdo_server ):
            # if there were nodes not found for which we only tried the second sdo server
            # but which might have a first sdo server only: search again forcing the first sdo server
            self.dbg << "scanning again for %r\n" % nodes_not_found
            node_nos.update( self.ScanForNodes( nodes_not_found, index, subindex, True, must_have_object ) )

        #scan_stop = time.time()
        #print( "scanning took add+write=%fs read=%fs del=%fs total %fs" % (scan_add_write - scan_start,scan_read-scan_add_write,scan_stop-scan_read, scan_stop-scan_start) )
        #self.dbg.SetFlag( old_flag )
        nl = list(node_nos)
        nl.sort()
        return nl

#     def ScanForNodes( self, node_range, index, subindex, force_first_sdo_server=None ):
#         '''Scan for nodes in node_range if an answer is received for index/subindex
#         \param force_first_sdo_server - see descripton in self.GetSDO_IDs()
#         '''
#         #scanning took add=0.008000s read=1.511000s del=0.007000s total 1.526000s
#         scan_start = time.time()
#         node_nos = []
#         for n in node_range:
#             (sdo_rxid, sdo_txid) = self.GetSDO_IDs( n, force_first_sdo_server )  # @UnusedVariable
#             self.cif.canIdAdd(sdo_txid)
#         scan_add = time.time()
#         t = self.cif.timestamp  # required for CAN-USB/2, see ntcan.CIF.canIdAdd() @UnusedVariable
#         old_rx_timeout = self.cif.rx_timeout
#         self.cif.rx_timeout = 10
#         try:
#             for n in node_range:
#                 if ( n < 20 ):
#                     tries = 2
#                 else:
#                     tries = 1
#                 result,value = self.read( n, index, subindex, add_id=False, tries=tries, retry_time_s=0.0, force_first_sdo_server=force_first_sdo_server )  # @UnusedVariable
#                 if ( result ):
#                     node_nos.append(n)
#         finally:
#             scan_read = time.time()
#             self.cif.rx_timeout = old_rx_timeout
#             for n in node_range:
#                 (sdo_rxid, sdo_txid) = self.GetSDO_IDs( n, force_first_sdo_server )  # @UnusedVariable
#                 self.cif.canIdDelete(sdo_txid)
#
#         scan_stop = time.time()
#         print( "scanning took add=%fs read=%fs del=%fs total %fs" % (scan_add - scan_start,scan_read-scan_add,scan_stop-scan_read, scan_stop-scan_start) )
#         return node_nos
    def read_visible_string( self, node, index, subindex, data=0, result=True, add_id=True, tries=5, retry_time_s=0.010, force_first_sdo_server=None ):
        '''Convenience function for read to ensure that a string is returned as data.
        This is the same as SDO.read but in case of success the data returned is always
        a string, even for expedited responses where SDO.read would return an integer.
        Use this if you're reading short VISIBLE_STRING parameters.

        Perform SDO read access (upload).
        Read object \a index / \a subindex from the object dictionary of \a node.
        The length of the data to read is determined automatically and the
        proper SDO transfer (expedited/segmented) is chosen automaticially.
        Block-transfer is not supported.

        \param force_first_sdo_server - see descripton in self.GetSDO_IDs()

        The request/response ping pong is retried up to \a tries times on
        each level. I.e.
        - each response is retried up to \a tries times,
        - if that fails then the corresponding request is resent up to \a tries times
        In case of an SDO abort from the SDO server the whole transfer
        is retried if that makes sense (depends on the reported SDO abort code).

        \return (result,data) - result: False for error, True for OK
                                data: if result is True then the received data is returned here as a string
        '''
        (result,data) = self.read( node, index, subindex, data, result, add_id, tries, retry_time_s, force_first_sdo_server )

        if ( result and not type( data ) is str ):
            # Very short visible strings data is transfered as an expedited SDOs.
            # This yield an integer and not a string as data.
            # So convert the integer back to a string as required here:
            d = ""
            while ( data > 0 ):
                d += chr( data & 0xff )
                data = data >> 8
            data = d

        return (result,data)


# PDO -------------------------------------------------------------------------
def PDO1writeByte (cif,node,dlen,d0=0,d1=0,d2=0,d3=0,d4=0,d5=0,d6=0,d7=0):
    cmsg = ntcan.CMSG()
    dbg << "PDO1writeByte node: %d -> " %(node),
    cmsg.canWriteByte(cif, PDO1RX_ID+node,dlen,d0,d1,d2,d3,d4,d5,d6,d7)
    dbg << cmsg
    del cmsg

def PDO1writeShort (cif,node,dlen,d0=0,d1=0,d2=0,d3=0):
    cmsg = ntcan.CMSG()
    dbg << "PDO1writeShort node: %d -> " %(node),
    cmsg.canWriteShort(cif, PDO1RX_ID+node,dlen,d0,d1,d2,d3)
    dbg << cmsg
    del cmsg

def PDO1writeLong (cif,node,dlen,d0=0,d1=0):
    cmsg = ntcan.CMSG()
    dbg << "PDO1writeLong node: %d -> " %(node),
    cmsg.canWriteLong(cif, PDO1RX_ID+node,dlen,d0,d1)
    dbg << cmsg
    del cmsg

def PDO2writeByte (cif,node,dlen,d0=0,d1=0,d2=0,d3=0,d4=0,d5=0,d6=0,d7=0):
    cmsg = ntcan.CMSG()
    dbg << "PDO2writeByte node: %d -> " %(node),
    cmsg.canWriteByte(cif, PDO2RX_ID+node,dlen,d0,d1,d2,d3,d4,d5,d6,d7)
    dbg << cmsg
    del cmsg

def PDO2writeShort (cif,node,dlen,d0=0,d1=0,d2=0,d3=0):
    cmsg = ntcan.CMSG()
    dbg << "PDO2writeShort node: %d -> " %(node),
    cmsg.canWriteShort(cif, PDO1RX_ID+node,dlen,d0,d1,d2,d3)
    dbg << cmsg
    del cmsg

def PDO2writeLong (cif,node,dlen,d0=0,d1=0):
    cmsg = ntcan.CMSG()
    dbg << "PDO2writeLong node: %d -> " %(node),
    cmsg.canWriteLong(cif, PDO2RX_ID+node,dlen,d0,d1)
    dbg << cmsg
    del cmsg

def PDO3writeByte (cif,node,dlen,d0=0,d1=0,d2=0,d3=0,d4=0,d5=0,d6=0,d7=0):
    cmsg = ntcan.CMSG()
    dbg << "PDO3writeByte node: %d -> " %(node),
    cmsg.canWriteByte(cif, PDO3RX_ID+node,dlen,d0,d1,d2,d3,d4,d5,d6,d7)
    dbg << cmsg
    del cmsg

def PDO3writeShort (cif,node,dlen,d0=0,d1=0,d2=0,d3=0):
    cmsg = ntcan.CMSG()
    dbg << "PDO3writeShort node: %d -> " %(node),
    cmsg.canWriteShort(cif, PDO3RX_ID+node,dlen,d0,d1,d2,d3)
    dbg << cmsg
    del cmsg

def PDO3writeLong (cif,node,dlen,d0=0,d1=0):
    cmsg = ntcan.CMSG()
    dbg << "PDO3writeLong node: %d -> " %(node),
    cmsg.canWriteLong(cif, PDO3RX_ID+node,dlen,d0,d1)
    dbg << cmsg
    del cmsg

def PDO4writeByte (cif,node,dlen,d0=0,d1=0,d2=0,d3=0,d4=0,d5=0,d6=0,d7=0):
    cmsg = ntcan.CMSG()
    dbg << "PDO4writeByte node: %d -> " %(node),
    cmsg.canWriteByte(cif, PDO4RX_ID+node,dlen,d0,d1,d2,d3,d4,d5,d6,d7)
    dbg << cmsg
    del cmsg

def PDO4writeShort (cif,node,dlen,d0=0,d1=0,d2=0,d3=0):
    cmsg = ntcan.CMSG()
    dbg << "PDO4writeShort node: %d -> " %(node),
    cmsg.canWriteShort(cif, PDO4RX_ID+node,dlen,d0,d1,d2,d3)
    dbg << cmsg
    del cmsg

def PDO4writeLong (cif,node,dlen,d0=0,d1=0):
    cmsg = ntcan.CMSG()
    dbg << "PDO4writeLong node: %d -> " %(node),
    cmsg.canWriteLong(cif, PDO4RX_ID+node,dlen,d0,d1)
    dbg << cmsg
    del cmsg


def PDO1read (cif,node,cmsg=0,result=True):
    lcmsg=ntcan.CMSG()
    cif.canIdAdd(PDO1TX_ID+node)
    t = cif.timestamp  # required for CAN-USB/2, see ntcan.CIF.canIdAdd() @UnusedVariable
    try:
        dbg << "PDO1read node: %d -> " %(node),
        lcmsg.canWriteByte(cif, PDO1TX_ID+node,0x10)
        try:
            lcmsg.canRead(cif)
            dbg << lcmsg
        except IOError as xxx_todo_changeme12:
                (errno) = xxx_todo_changeme12
                dbg << "I/O error(%s): \n"  % (errno)
                result = False
    finally:
        cif.canIdDelete(PDO1TX_ID+node)
        cmsg = lcmsg
        del lcmsg
    return result,cmsg

def PDO2read (cif,node,cmsg=0,result=True):
    lcmsg=ntcan.CMSG()
    cif.canIdAdd(PDO2TX_ID+node)
    t = cif.timestamp  # required for CAN-USB/2, see ntcan.CIF.canIdAdd() @UnusedVariable
    try:
        dbg << "PDO2read node: %d -> " %(node),
        lcmsg.canWriteByte(cif, PDO2TX_ID+node,0x10)
        try:
            lcmsg.canRead(cif)
            dbg << lcmsg
        except IOError as errno:
                dbg << "I/O error(%s): \n"  % (errno)
                result = False
    finally:
        cif.canIdDelete(PDO2TX_ID+node)
        cmsg = lcmsg
        del lcmsg
    return result,cmsg

def PDO3read (cif,node,cmsg=0,result=True):
    lcmsg=ntcan.CMSG()
    cif.canIdAdd(PDO3TX_ID+node)
    t = cif.timestamp  # required for CAN-USB/2, see ntcan.CIF.canIdAdd() @UnusedVariable
    try:
        dbg << "PDO3read node: %d -> " %(node),
        lcmsg.canWriteByte(cif, PDO3TX_ID+node,0x10)
        try:
            lcmsg.canRead(cif)
            dbg << lcmsg
        except IOError as errno:
                dbg << "I/O error(%s): \n"  % (errno)
                result = False
    finally:
        cif.canIdDelete(PDO3TX_ID+node)
        cmsg = lcmsg
        del lcmsg
    return result,cmsg

def PDO4read (cif,node,cmsg=0,result=True):
    lcmsg=ntcan.CMSG()
    cif.canIdAdd(PDO4TX_ID+node)
    t = cif.timestamp  # required for CAN-USB/2, see ntcan.CIF.canIdAdd() @UnusedVariable
    try:
        dbg << "PDO4read node: %d -> " %(node),
        lcmsg.canWriteByte(cif, PDO4TX_ID+node,0x10)
        try:
            lcmsg.canRead(cif)
            dbg << lcmsg
        except IOError as errno:
                dbg << "I/O error(%s): \n"  % (errno)
                result = False
    finally:
        cif.canIdDelete(PDO4TX_ID+node)
        cmsg = lcmsg
        del lcmsg
    return result,cmsg



class PDO(object):
    def __init__(self,obj,net,baudrate,RxQS=default_RxQS,RxTO=default_RxTO,TxQS=default_TxQS,TxTO=default_TxTO):
        if obj>4 or obj <1:
            dbg << "PDO -> wrong obj %d -> " %(obj)
            return
        #CIF( net, rx_queuesize, rx_timeout, tx_timeout, tx_queuesize, ? )
        self.cif = ntcan.CIF( net, RxQS, RxTO, TxTO, TxQS )
        self.cif.baudrate = baudrate
        self.cmsg = ntcan.CMSG()
        self.obj = obj
        self.txid = PDO1TX_ID + (obj-1)*0x100
        self.rxid = PDO1RX_ID + (obj-1)*0x100
        #dbg << "obj %d txid: 0x%0.3X rxid: 0x%0.3X"%(self.obj,self.txid,self.rxid)
        #del cmsg

    def __splitdata(self,data,dlen):
        pos = 0
        rdata=[0,0,0,0,0,0,0,0]
        if dlen==1:
            rdata[pos]=data&0xFF
        elif dlen==2:
            rdata[pos+1]=(data>>8)&0xFF
            rdata[pos+0]=(data>>0)&0xFF
        elif dlen==3:
            rdata[pos+2]=(data>>16)&0xFF
            rdata[pos+1]=(data>>8)&0xFF
            rdata[pos+0]=(data>>0)&0xFF
        elif dlen==4:
            rdata[pos+3]=(data>>24)&0xFF
            rdata[pos+2]=(data>>16)&0xFF
            rdata[pos+1]=(data>>8)&0xFF
            rdata[pos+0]=(data>>0)&0xFF
        return rdata

    def write (self,node,d0=0,l0=0,d1=0,l1=0,d2=0,l2=0,d3=0,l3=0,d4=0,l4=0,d5=0,l5=0,d6=0,l6=0,d7=0,l7=0):
        dbg << "PDO%dwrite node: %d -> " %(self.obj,node),
        dlen = l0+l1+l2+l3+l4+l5+l6+l7
        if (dlen > 8 or dlen < 0):
            dbg << "Error: wrong data length (%d)\n"  % (dlen)
        else:
            pos=0
            _datalen=[l0,l1,l2,l3,l4,l5,l6,l7]
            _data=[d0,d1,d2,d3,d4,d5,d6,d7]
#            dbg << _datalen
#            dbg << _data
            _candata=[0,0,0,0,0,0,0,0]
            for x in range(8):
                _candata[pos:pos+_datalen[x]]=self.__splitdata(_data[x],_datalen[x])
                pos = pos + _datalen[x]
#                dbg << x,_datalen[x],_data[x],pos
#                dbg << _candata
            self.cmsg.canWriteByte(self.cif,(self.rxid+node),dlen,_candata[0],_candata[1],_candata[2],_candata[3],_candata[4],_candata[5],_candata[6],_candata[7])
            dbg << self.cmsg
    def writeByte (self,node,dlen,d0=0,d1=0,d2=0,d3=0,d4=0,d5=0,d6=0,d7=0):
        dbg << "PDO%dwriteByte node: %d -> " %(self.obj,node),
        self.cmsg.canWriteByte(self.cif,(self.rxid+node),dlen,d0,d1,d2,d3,d4,d5,d6,d7)
        dbg << self.cmsg
    def writeShort (self,node,dlen,d0=0,d1=0,d2=0,d3=0):
        dbg << "PDO%dwriteShort node: %d -> " %(self.obj,node),
        self.cmsg.canWriteShort(self.cif,(self.rxid+node),dlen,d0,d1,d2,d3)
        dbg << self.cmsg
    def writeLong (self,node,dlen,d0=0,d1=0):
        dbg << "PDO%dwriteLong node: %d -> " %(self.obj,node),
        self.cmsg.canWriteLong(self.cif,(self.rxid+node),dlen,d0,d1)
        dbg << self.cmsg
    def writeString (self,node,strdat):
        dbg << "PDO%dwriteString node: %d -> " %(self.obj,node),
        strlen = len(strdat)
        i = 0
        #a = (((strlen//8)*8)+8)
        #dbg << a
        strdat = strdat.ljust( ((strlen//8)*8)+8 )
        #dbg << "#%s#"%(strdat)
        while (strlen>0):
            if strlen > 7: pdolen = 8
            else: pdolen=strlen%8
            self.cmsg.canWriteByte(self.cif, (self.rxid+node),pdolen, ord(strdat[i]),ord(strdat[i+1]),ord(strdat[i+2]),ord(strdat[i+3]),ord(strdat[i+4]),ord(strdat[i+5]),ord(strdat[i+6]),ord(strdat[i+7]))
            strlen = strlen-8
            i=i+8
            #dbg << "%d %d %d"%(pdolen,strlen,i),
        dbg << strdat #self.cmsg
    def read (self,node,dlen=None,cmsg=0,result=True,silent=False):
        if ( dlen is None or dlen < 0 or dlen>8 ):
            raise ValueError( "invalid dlen %r. Must be the dlen of the response to request with rtr." % dlen ) # see http://de.wikipedia.org/wiki/Controller_Area_Network#Remote_Frame

        self.cif.canIdAdd(self.txid+node) #FIXME: should we really do canIdAdd/Delete in every PDO read???
        t = self.cif.timestamp  # required for CAN-USB/2, see ntcan.CIF.canIdAdd() @UnusedVariable
        try:
            if (silent): dbg << "PDO%dread node: %d -> " %(self.obj,node),
            self.cmsg.canWriteByte(self.cif,(self.txid+node),0x10+dlen)    #rtr
            try:
                self.cmsg.canRead(self.cif)
                if (silent): dbg << cmsg
            except IOError as errno:
                    if (silent): dbg << "I/O error(%s): \n"  % (errno)
                    result = False
        finally:
            self.cif.canIdDelete(self.txid+node)
        cmsg = self.cmsg
        return result,cmsg
    def readNoRtr (self,node,cmsg=0,result=True,silent=False):
        self.cif.canIdAdd(self.txid+node)
        t = self.cif.timestamp  # required for CAN-USB/2, see ntcan.CIF.canIdAdd() @UnusedVariable
        try:
            if (silent): dbg << "PDO%dreadNoRtr node: %d -> " %(self.obj,node),
            #self.cmsg.canWriteByte(self.cif,(self.txid+node),0x10)    #rtr
            try:
                self.cmsg.canRead(self.cif)
                if (silent): dbg << cmsg
            except IOError as errno:  # @UnusedVariable
                    result = False
        finally:
            self.cif.canIdDelete(self.txid+node)
        cmsg = self.cmsg
        return result,cmsg

class LSS:
    '''Class to implement the CANopen Layer Settings Services
    Incomplete: only switching the node number and baudrate is implemented yet.
    '''
    def __init__(self,net,baudrate,RxQS=default_RxQS,RxTO=default_RxTO,TxQS=default_TxQS,TxTO=default_TxTO):
        #CIF( net, rx_queuesize, rx_timeout, tx_timeout, tx_queuesize, ? )
        self.cif = ntcan.CIF( net, RxQS, RxTO, TxTO, TxQS )
        self.cif.baudrate = baudrate
        self.cmsg = ntcan.CMSG()

    def SwitchModeGlobal(self, enable_lss_configuration):
        dbg << "LMT/LSS Switch Mode Global to operation mode\n"
        if ( enable_lss_configuration not in (0,1) ):
            raise ValueError( "enable_lss_configuration not in [0,1]" )

        self.cmsg.canWriteByte(self.cif, LSS_M_ID, 8, 0x04, enable_lss_configuration, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 )
        # this service is unconfirmed => no response from module(s)

    def SwitchState(self,vendor_id,product_code,revision_number,serial_number):
        dbg << "LSS Switch state selective\n"
        self.cif.canIdAdd(LSS_S_ID)                        # add id
        t = self.cif.timestamp  # required for CAN-USB/2, see ntcan.CIF.canIdAdd() @UnusedVariable
        try:
            self.cmsg.canWriteByte(self.cif, LSS_M_ID, 8, 0x40, *esdutil.l2cr(vendor_id) )
            self.cmsg.canWriteByte(self.cif, LSS_M_ID, 8, 0x41, *esdutil.l2cr(product_code) )
            self.cmsg.canWriteByte(self.cif, LSS_M_ID, 8, 0x42, *esdutil.l2cr(revision_number) )
            self.cmsg.canWriteByte(self.cif, LSS_M_ID, 8, 0x43, *esdutil.l2cr(serial_number) )

            try:
                self.cmsg.canRead(self.cif)
            except IOError as errno:
                raise IOError( "(%s) while reading LSS switch state selective Resp." % (errno) )

            if ( self.cmsg.len != 8 or self.cmsg.data.c != [0x44, 0, 0, 0, 0, 0, 0, 0] ):
                raise IOError( "invalid LSS switch state selective Resp." )
        finally:
            self.cif.canIdDelete(LSS_S_ID)                    # delete id

    def _FlushInput(self):
        '''Internal helper to flush input. Needed when addressing severall nodes via LSS.
        '''
        # LSS_S_ID must already be added!
        old_timeout = self.cif.rx_timeout
        self.cif.rx_timeout = 300
        try:
            # Read as many responses as available until a timeout:
            while True:
                try:
                    self.cmsg.canRead(self.cif)
                except IOError:
                    break
        finally:
            self.cif.rx_timeout = old_timeout

    def _CheckResponse(self, b0, msg ):
        '''Internal helper, read and check a LSS response for matching byte 0 \a b0
        '''
        # LSS_S_ID must already be added!
        try:
            self.cmsg.canRead(self.cif)
        except IOError as errno:
            raise IOError( "LSS: (%s) while reading LSS response %r" % (errno,msg) )

        if ( self.cmsg.len != 8 or self.cmsg.data.c != [b0, 0, 0, 0, 0, 0, 0, 0] ):
            # TODO: decipher error code (byte 1) and error extension (byte 2), see http://www.canopensolutions.com/english/about_canopen/lss.shtml
            raise IOError( "LSS: invalid response %r. Expected %r but got %r" % (msg,[b0,0,0,0,0,0,0,0],self.cmsg.data.c) )
        self._FlushInput()

    def StoreConfiguration(self):
        dbg << "store configuration\n"
        self.cif.canIdAdd(LSS_S_ID)                        # add id
        t = self.cif.timestamp  # required for CAN-USB/2, see ntcan.CIF.canIdAdd() @UnusedVariable
        try:
            self.cmsg.canWriteByte(self.cif, LSS_M_ID, 8, 0x17, 0, 0, 0, 0, 0, 0, 0 )
            self._CheckResponse( 0x17, "store configuration successfully completed" )
        finally:
            self.cif.canIdDelete(LSS_S_ID)                 # delete id

    def ConfigureId(self,new_id):
        dbg << "LSS configure id\n"
        self.cif.canIdAdd(LSS_S_ID)                        # add id
        t = self.cif.timestamp  # required for CAN-USB/2, see ntcan.CIF.canIdAdd() @UnusedVariable
        try:
            self.cmsg.canWriteByte(self.cif, LSS_M_ID, 8, 0x11, new_id, 0, 0, 0, 0, 0, 0 )
            self._CheckResponse( 0x11, "Configure Module Id protocol successfully completed" )
        finally:
            self.cif.canIdDelete(LSS_S_ID)                 # delete id

    def ConfigureBaudrate(self,new_baudrate):
        dbg << "LSS configure baudrate\n"
        self.cif.canIdAdd(LSS_S_ID)                        # add id
        t = self.cif.timestamp  # required for CAN-USB/2, see ntcan.CIF.canIdAdd() @UnusedVariable
        try:
            canopen_baudrate_codes = { 1000000: 0,
                                       800000:  1,
                                       500000:  2,
                                       250000:  3,
                                       #reserved: 5,
                                       125000:  4,
                                       50000:  6,
                                       20000:  7,
                                       10000:  8 }
            bit_timing_table = 0
            self.cmsg.canWriteByte(self.cif, LSS_M_ID, 8, 0x13, bit_timing_table, canopen_baudrate_codes[new_baudrate], 0, 0, 0, 0, 0 )
            self._CheckResponse( 0x13, "Configure Bit Timing Parameters successfully completed" )
        finally:
            self.cif.canIdDelete(LSS_S_ID)                # delete id

    def ActivateBitTiming(self,delay_ms):
        dbg << "LSS activate bit timing\n"
        (delay_ms_lb, delay_ms_hb) = esdutil.w2cr( int( delay_ms ) )
        self.cmsg.canWriteByte(self.cif, LSS_M_ID, 8, 0x15, delay_ms_lb, delay_ms_hb, 0, 0, 0, 0, 0 )


# PDO transmission types
PDO_TT_SYNCHRONOUS_ACYCLIC = 0
def PDO_TT_SYNCHRONOUS_CYCLIC(n):
    if ( n < 1 or n > 240 ):
        raise ValueError( "n=%d out of range [1..240]" % (n) )
    return n
PDO_TT_RTR_ONLY_SYNCHRONOUS = 252
PDO_TT_RTR_ONLY_EVENT_DRIVEN = 253
PDO_TT_EVENT_DRIVEN_MANUFACTURER_SPECIFIC = 254
PDO_TT_EVENT_DRIVEN_PROFILE_SPECIFIC = 255

PDO_TYPE_TRANSMIT = 0  # transmit from the perspective of the slave: slave->master
PDO_TYPE_RECEIVE  = 1  # receive from the perspective of the slave:  slave<-master

def MapPDO( sdo, node_no, pdo_type, pdo_no, transmission_type, index_subindex_len_list ):
    '''Change the mode and mapping of a transmit PDO.
    \param node_no - node number
    \param pdo_type - type of PDO either PDO_TYPE_TRANSMIT or PDO_TYPE_RECEIVE
    \param pdo_no - pdo number (1..4)
    \param transmission_type - PDO transmission type, see above PDO_TT_*
    \param index_subindex_len_list - list of (index,subindex,len) tuples with new objects to map
    '''
    if ( transmission_type == PDO_TT_RTR_ONLY_SYNCHRONOUS ):
        mode = "synchronous, acyclic"
    elif ( transmission_type == PDO_TT_RTR_ONLY_EVENT_DRIVEN ):
        mode = "RTR only, synchronous"
    elif ( transmission_type == PDO_TT_EVENT_DRIVEN_MANUFACTURER_SPECIFIC ):
        mode = "RTR only, synchronous"
    elif ( transmission_type == PDO_TT_EVENT_DRIVEN_PROFILE_SPECIFIC ):
        mode = "RTR only, synchronous"
    elif ( transmission_type == PDO_TT_RTR_ONLY_SYNCHRONOUS ):
        mode = "RTR only, synchronous"
    else:
        mode = "synchronous, cyclic every %d SYNC" % transmission_type
    if ( pdo_type == PDO_TYPE_RECEIVE ):
        pdo_type_s = "R"
    elif ( pdo_type == PDO_TYPE_TRANSMIT):
        pdo_type_s = "T"
    else:
        raise ValueError( "Invalid pdo_type %r" % pdo_type )

    #dbg = tDBG( True, "red", description="pyschunk.canopen.esdcanopen.MapPDO" )
    dbg << "MapPDO: new %s mapping for node %d, %sPDO %d:\n" % (mode, node_no, pdo_type_s, pdo_no)
    for (index,subindex,dlen) in index_subindex_len_list:
        dbg << "  OV-Index/Subindex: 0x%04x/%d length %d bits\n" % (index,subindex,dlen)

    if ( pdo_type == PDO_TYPE_RECEIVE ):
        pdo_communication_parameter = 0x1400 + pdo_no - 1
        pdo_mapping_parameter       = 0x1600 + pdo_no - 1
        pdo_id                      = PDOxRX_ID[ pdo_no ] + node_no
    else:
        pdo_communication_parameter = 0x1800 + pdo_no - 1
        pdo_mapping_parameter       = 0x1a00 + pdo_no - 1
        pdo_id                      = PDOxTX_ID[ pdo_no ] + node_no

    # according to CiA DS 301 page 142:
    #1.   Destroy  RPDO/TPDO  by  setting  bit  valid  to  1 b   of  sub-index  01 h   of  the  according  RPDO/TPDO communication parameter.
    #dbg << "MapPDO1 node:%r pdo_communication_parameter:%0x04x/%d, 0x%08x\n" % (node_no, pdo_communication_parameter, 0x01, 0x80000000 | pdo_id )
    sdo.write4Byte( node_no, pdo_communication_parameter, 0x01, 0x80000000 | pdo_id )    # node,index,subindex,data)

    #2.   Disable mapping by setting sub-index 00 h  to 00 h .
    #dbg << "MapPDO2 node:%r pdo_mapping_parameter:0x%04x/%d, 0x%02x\n" % (node_no, pdo_mapping_parameter, 0x00, 0 )
    sdo.write1Byte( node_no, pdo_mapping_parameter, 0x00, 0 )    # node,index,subindex,data)

    #3.   Modify mapping by changing the values of the corresponding sub-indices.
    for (i,(index,subindex,dlen)) in enumerate( index_subindex_len_list ):
        #dbg << "MapPDO3 node:%r pdo_mapping_parameter:0x%04x/%d, 0x%08x\n" % (node_no, pdo_mapping_parameter, 0x01+i, ((index&0xffff) << 16) | ((subindex&0xff) << 8) | (dlen&0xff) )
        sdo.write4Byte( node_no, pdo_mapping_parameter, 0x01+i, ((index&0xffff) << 16) | ((subindex&0xff) << 8) | (dlen&0xff) )    # node,index,subindex,data)
        #time.sleep(0.050)

    #4.   Enable mapping by setting sub-index 00 h  to the number mapped objects.
    #dbg << "MapPDO4 node:%r pdo_mapping_parameter:0x%04x/%d, 0x%02x\n" % (node_no, pdo_mapping_parameter, 0x00, len(index_subindex_len_list) )
    sdo.write1Byte( node_no, pdo_mapping_parameter, 0x00, len(index_subindex_len_list) )    # node,index,subindex,data)

    #4.5  set transmissiont type
    #dbg << "MapPDO4.5 node:%r pdo_communication_parameter:0x%04x/%d, 0x%02x\n" %  (node_no, pdo_communication_parameter, 0x02, transmission_type )
    sdo.write1Byte( node_no, pdo_communication_parameter, 0x02, transmission_type )  # node,index,subindex,data)

    #5.   Create  pdo  by  setting  bit  valid  to  0 b   of  sub-index  01 h   of  the  according  RPDO/TPDO communication parameter.
    #dbg << "MapPDO5 node:%r pdo_communication_parameter:0x%04x/%d, 0x%08x\n" %  ( node_no, pdo_communication_parameter, 0x01, pdo_id )
    sdo.write4Byte( node_no, pdo_communication_parameter, 0x01, pdo_id )  # node,index,subindex,data)
    #dbg << "Mapping finished node:%r\n" % (node_no)

# dictionary mapping net number to cPDOConsumer objects
_pdo_consumers = dict()

def PDOConsumer( net, baudrate, node_tpdo_nos, lock, RxQS=default_RxQS, RxTO=default_RxTO,callbacks=None ):
    '''Function to return a new or already existing cPDOConsumer
    '''
    if ( net in _pdo_consumers ):
        pc = _pdo_consumers[net]
        assert( baudrate == pc.cif.baudrate )
        assert( lock == pc.lock )
        #assert( RxQS == pc.cif.RxQS ) # parameter not available in cif?
        assert( RxTO == pc.cif.rx_timeout )
        dbg << "PDOConsumer adding node_tpdo_nos %r to existing cPDOConsumer object\n" % node_tpdo_nos
        pc.Add( node_tpdo_nos )
        return pc

    # create new cPDOConsumer
    pc = cPDOConsumer( net, baudrate, node_tpdo_nos, lock, RxQS, RxTO, callbacks )
    _pdo_consumers[net] = pc
    return pc


class cPDOCallback(object):
    '''Class to do callback on reception of some PDOs.

    A list of cPDOCallback objects can be given to a pdo_consumer on creation.
    '''
    def __init__( self, node_tpdo_nos, callback ):
        '''CTor: create a callback object that will be called by a pdo_consumer
        if all (node_no,tpdo_no) TPDOs in \a node_tpdo_nos have been received
        '''
        self.node_tpdo_nos = node_tpdo_nos
        self.node_tpdo_nos_received = dict()
        self.callback = callback
        self.Reset()

    def Reset(self):
        '''Internal helper'''
        for (node_no,tpdo_no) in self.node_tpdo_nos:
            self.node_tpdo_nos_received[ (node_no,tpdo_no) ] = False

    def Received( self, node_no, tpdo_no ):
        '''Called by pdo consumer on reception of TPDO (node_no, tpdo_no).
        (node_no_tpdo_no) given might not be in self.node_tpdo_nos.'''
        if ( (node_no,tpdo_no) in self.node_tpdo_nos_received ):
            self.node_tpdo_nos_received[ (node_no,tpdo_no) ] = True

    def CallIfComplete( self, pdo_consumer ):
        '''Called by pdo consumer if all TPDOs have been received then
        the callback is called'''
        for (node_no,tpdo_no) in self.node_tpdo_nos:
            if ( not self.node_tpdo_nos_received[ (node_no,tpdo_no) ] ):
                return
        values = []
        for (node_no,tpdo_no) in self.node_tpdo_nos:
            values.append( pdo_consumer.GetLastPDO( node_no, tpdo_no ) )
        self.callback( values )
        self.Reset()


class cPDOConsumer(threading.Thread):
    '''Class that implements a thread that receives multiple PDOs.
    '''
    def __init__(self,net,baudrate,node_tpdo_nos,lock,RxQS=default_RxQS,RxTO=default_RxTO,callbacks=None):
        '''CTor. Create the thread object and prepare for receiving the IDs
        \param net - esd net number
        \param baudrate - esd baudrate code
        \param RxQS - receive queue size
        \param RxTO - receive timeout in ms
        \param node_tpdo_nos - list of (node_no,tpdo_no) tuples.
               node_no is a node number and tpdo_no is a tpdo_number [1-4]
        \param lock - lock object for exclusive access to self.last_pdo, self.pdo_available and self.any_pdo_available
        \param callbacks - list of cPDOCallback objects or None

        threading.Event variables for external access:
        - self.pdo_available - a dictionary of "PDO available" events with (node_no,tpdo_no) index
        - self.any_pdo_available - an event that gets set on any PDO received
        '''
        threading.Thread.__init__(self, name="cPDOConsumer")
        #CIF( net, rx_queuesize, rx_timeout, tx_timeout, tx_queuesize, ? )
        self.cif = ntcan.CIF( net, RxQS, RxTO )
        self.cif.baudrate = baudrate
        self.cmsg = ntcan.CMSG_T()
        self.isrun=False
        self.node_tpdo_nos = []
        self.lock = lock
        self.callbacks = []
        self.nb_starters = 0

        # self.last_pdo is a dictionary that maps (node_no,tpdo_no) indices
        # to CMSG_T objects with aditional members:
        # - no - is a counter for this PDO
        # - time - is the time.time() of the reception of this last PDO
        self.last_pdo = dict()
        self.pdo_available = dict()
        self.nos = dict()
        self.Add( node_tpdo_nos, callbacks )
        self.any_pdo_available = threading.Event()

    def start(self):
        '''Overloaded version of start() so that it can be called multiple times. All but the first call will be ignored
        '''
        if ( self.nb_starters == 0 ):
            dbg << "cPDOConsumer starting\n"
            threading.Thread.start(self)
        else:
            dbg << "cPDOConsumer ignoring %d-th start\n" % (self.nb_starters+2)
        self.nb_starters += 1

    def Add( self, node_tpdo_nos, callbacks=None ):
        '''Add node_tpdo_nos and callbacks (if any)
        '''
        for (node_no,tpdo_no) in node_tpdo_nos:
            self.nos[(node_no,tpdo_no)] = 0
            try:
                self.cif.canIdAdd( PDOxTX_ID[tpdo_no]+node_no )
                t = self.cif.timestamp  # required for CAN-USB/2, see ntcan.CIF.canIdAdd() @UnusedVariable
            except ValueError as e:
                if (str(e) == "CAN-ID already enabled"):
                    dbg << "Ignoring ValueError %r\n" % e
                else:
                    raise
            dbg << "PDOConsumer: Listening for ID 0x%03x (node %d, tpdo %d)\n" % (PDOxTX_ID[tpdo_no]+node_no, node_no, tpdo_no)
            self.last_pdo[(node_no,tpdo_no)] = None
            self.pdo_available[(node_no,tpdo_no)] = threading.Event()
        self.node_tpdo_nos.append( node_tpdo_nos )

        if ( not callbacks is None ):
            self.callbacks += callbacks

    def GetLastPDO(self, node_no, tpdo_no ):
        '''Return the last PDO received for \a node_no and \a tpdo_no
        The CMSG_T object returned will have additional members:
        - time - the time.time() when the PDO was received
        - no - counter of the received PDO
        If no such PDO has been received None is returned
        '''
        return self.last_pdo[(node_no,tpdo_no)]

    def run (self):
        dbg << "PDOConsumer start\n"
        dbg.output.flush()
        self.isrun=True
        while self.isrun:
            try:
                #last_timestamp = self.cmsg.timestamp
                self.cmsg.canRead(self.cif)
                if ( self.cmsg.len & 0x10 ):
                    # we received our own RTR request => ignore
                    continue
                t = time.time()
                (node_no,tpdo_no) = GetNodeNoTPDONoFromID( self.cmsg.id )
                self.nos[(node_no,tpdo_no)] += 1
                dbg << "PDOConsumer: Received ID 0x%03x (node %d, tpdo %d)\n" % (self.cmsg.id, node_no, tpdo_no)
                #temperature = esdutil.c2f( *(self.cmsg.data.c[0:4]) )
                #dbg.var("temperature")

                # Make a pseudo copy of self.cmsg:
                # (necessary since CMSG_T objects are not native python objects
                #  and cannot be copied with copy)
                tpdo = pyschunk.tools.util.Struct( id=self.cmsg.id,
                                             data=pyschunk.tools.util.Struct(c=self.cmsg.data.c,s=self.cmsg.data.s,l=self.cmsg.data.l),
                                             len=self.cmsg.len,
                                             msg_lost=self.cmsg.msg_lost,
                                             timestamp=self.cmsg.timestamp,
                                             no=self.nos[(node_no,tpdo_no)],
                                             time = t )
                dbg.var("tpdo")
                with self.lock:
                    self.last_pdo[(node_no,tpdo_no)] = tpdo
                    self.pdo_available[(node_no,tpdo_no)].set()
                    self.any_pdo_available.set()

                for cb in self.callbacks:
                    cb.Received( node_no, tpdo_no )
                    cb.CallIfComplete( self )

                #dbg << "%f,%f received %d PDO from node %d\n" % (time.time(),self.last_pdo[node_no][1],self.last_pdo[node_no][0],node_no)
                #dbg.output.flush()

            except IOError as errno:
                dbg << "I/O error(%s): \n"  % (errno)
                dbg.output.flush()

        dbg << "PDOConsumer stopped\n"
        dbg.output.flush()

    def suspend (self):
        '''Request to suspend the thread.
        The execution of run() will only be suspended when as many calls to
        resume() as calls to start() have been seen.
        I.E the last starter of the thread calls resume().
        '''
        self.nb_starters -= 1
        if ( self.nb_starters <= 0 ):
            dbg << "PDOConsumer suspend\n"
            self.isrun=False
            del _pdo_consumers[ self.cif.net ]
        else:
            dbg << "PDOConsumer suspend ignored, still %d starters using it\n" % self.nb_starters

def GetCIF( options, RxQS=default_RxQS, RxTO=default_RxTO, TxQS=default_TxQS, TxTO=default_TxTO ):
    '''Return a ntcan CIF object according to options
    '''
    #CIF( net, rx_queuesize, rx_timeout, tx_timeout, tx_queuesize, ? )
    cif = ntcan.CIF( options.net, RxQS, RxTO, TxTO, TxQS )
    cif.baudrate = options.baudrate_code
    return cif

def GetSDOError( value ):
    '''\return an SDO error description according to \a value
    '''
    try:
        return "SDO error %r" % (eSDOerror.GetName( value ))
    except ValueError:
        return "SDO error 'unknown'"

def GetNMTState( node_no, cif=None, options=None ):
    '''Return the NMT state of node \a node_no
    \param cif - if not None then a ntcan CIF to reuse.
    \param options - only required if \a cif is None. Struct with CAN options (baudrate, net)
    '''
    if ( cif is None ):
        cif = ntcan.CIF( options.net, default_RxQS, default_RxTO, default_TxTO, default_TxQS )
        cif.baudrate = options.baudrate_code
    result,state,toggle = NODEGUARDrequest( cif, node_no )  # @UnusedVariable
    if ( not result ):
        raise EnvironmentError( "Could not read Nodeguard request for node %r" % node_no )
    return state
