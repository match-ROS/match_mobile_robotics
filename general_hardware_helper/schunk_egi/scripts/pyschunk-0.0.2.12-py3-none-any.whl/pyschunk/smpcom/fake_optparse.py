# -*- coding: latin-1 -*-
#######################################################################
# The python docstring for the module follows below.
#   (The doxygen input filter doxypy (http://code.foosel.org/doxypy) 
#    allows you to use doxygen markup in the python docstrings for 
#    files, classes and functions)
'''
  \file
  \section smpcom_fake_optparse_py_general General file information

    \author   Osswald2
    \date     13.01.2010

  \brief  
    Implementation of command line option parser that allows to specify 
    fake command line arguments at construction time

  \section smpcom_fake_optparse_py_copyright Copyright

  - Copyright (c) 2009 SCHUNK GmbH & Co. KG

  <HR>
  \internal

    \subsection smpcom_fake_optparse_py_details SVN related, detailed file specific information:
      $LastChangedBy$
      $LastChangedDate$
      \par SVN file revision:
        $Id$

  \subsection smpcom_fake_optparse_py_changelog Changelog of this file:
      \include fake_optparse.py.log
'''
#######################################################################


#######################################################################
## \anchor smpcom_fake_optparse_py_python_vars
#  \name   Python specific variables
#  
#  Some definitions that describe the module for python.
#
#  @{

__author__    = "Dirk Osswald: dirk.osswald@de.schunk.com"
__url__       = "http://www.schunk.com"
__version__   = "$Id$"
__copyright__ = "Copyright (c) 2009 SCHUNK GmbH & Co. KG"

## end of doxygen name group smpcom_fake_optparse_py_python_vars
#  @}
######################################################################


######################################################################
# import needed modules:

# standard python modules
import optparse

# submodules from this package:
#import

# 
######################################################################



######################################################################
# The actual classes

class cFakeOptionParser( optparse.OptionParser ):
    '''Derived command line option parser that allows to specify 
    fake command line arguments at construction time
    '''
    def __init__(self, 
                 usage=None,
                 option_list=None,
                 option_class=optparse.Option,
                 version=None,
                 conflict_handler="error",
                 description=None,
                 formatter=None,
                 add_help_option=True,
                 prog=None,
                 epilog=None,
                 fake_args=None):
        # save fake args:
        self.fake_args = fake_args
        # call base class CTor:
        optparse.OptionParser.__init__(self,usage,option_list,option_class,version,conflict_handler,description,formatter,add_help_option,prog,epilog)
                     
    def _get_args(self, args):
        '''overloaded method that returns self.fake_args in case that \a args is not None
        '''
        if args is None:
            return self.fake_args
        else:
            return args[:]              # don't modify caller's list
        
# end of class 
##############
