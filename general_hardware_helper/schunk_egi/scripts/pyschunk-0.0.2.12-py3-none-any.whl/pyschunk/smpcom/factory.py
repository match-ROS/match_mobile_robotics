# -*- coding: latin-1 -*-
#######################################################################
# The python docstring for the module follows below.
#   (The doxygen input filter doxypy (http://code.foosel.org/doxypy)
#    allows you to use doxygen markup in the python docstrings for
#    files, classes and functions)
'''
  \file
  \section smpcom_factory_py_general General file information

    \author   Osswald2
    \date     17.12.2009

  \brief
    Implementation of a somewhat generic factory

  \section smpcom_factory_py_copyright Copyright

  - Copyright (c) 2009 SCHUNK GmbH & Co. KG

  <HR>
  \internal

    \subsection smpcom_factory_py_details SVN related, detailed file specific information:
      $LastChangedBy$
      $LastChangedDate$
      \par SVN file revision:
        $Id$

  \subsection smpcom_factory_py_changelog Changelog of this file:
      \include factory.py.log
'''
#######################################################################


#######################################################################
## \anchor smpcom_factory_py_python_vars
#  \name   Python specific variables
#
#  Some definitions that describe the module for python.
#
#  @{

__author__    = "Dirk Osswald: dirk.osswald@de.schunk.com"
__url__       = "http://www.schunk.com"
__version__   = "$Id$"
__copyright__ = "Copyright (c) 2009 SCHUNK GmbH & Co. KG"

## end of doxygen name group smpcom_factory_py_python_vars
#  @}
######################################################################


######################################################################
# import needed modules:

# standard python modules
import fnmatch, os, sys
import zipfile
from pyschunk.tools.dbg import tDBG

# submodules from this package:
#import

#
######################################################################

# By default debug messages from here are enabled. But they can
# be disabled by setting a factory_debug_flag = False in the main module
try:
    debug_flag = sys.modules["__main__"].factory_debug_flag
except AttributeError:
    #debug_flag = True # enable factory debug by default
    debug_flag = False # disable factory debug by default
dbg = tDBG( debug_flag, "blue", description="pyschunk.smpcom.factory" )

## dictionary of known factories.
#  (This is actually a Singleton, since variables on module level are unique)
_factories = dict()


######################################################################
# The actual classes


class cFactory(object):
    '''Somewhat generic implementation of the factory pattern.

    Several classes that implement something of a certain category
    must register themselves via the Register() member.
    The user can iterate over the registered members.
    '''
    def __init__(self,category):
        '''Create a new factory for classes of \a category (e.g. a string)

        Derived classes for a certain category should fix the category.
        '''
        global _factories
        self.category = category
        _factories.setdefault( self.category, [] )

        self.factory = _factories[ self.category ]

    def __iter__(self):
        ''' Returns an iterator object for the list of registered factory classes of the self.category
        '''
        return self.factory.__iter__()

    def __len__(self):
        ''' Returns number of registered factory classes
        '''
        return len(self.factory)

    def Register( self, klass ):
        ''' Register the new factory \a klass
        '''
        self.factory.append( klass )

    def Import( self, package, pattern ):
        ''' Import all files matching \a pattern in directory \a dir.

        This does not call Register() any classes found, so the
        imported modules must do that explicitly
        '''
        # get factory modules

        packagepath = package.replace( ".", "/" )

        dbg << "cFactory.Import():\n"
        dbg.var("package packagepath pattern")

        factory_file_names = set()
        matching_files = []
        for path in sys.path:
            dbg.var("path")
            try:
                if ( zipfile.is_zipfile( path ) ):
                    # path is a zip archive
                    z = zipfile.ZipFile( path, "r" )
                    packagefiles = []
                    for f in z.namelist():
                        if ( f.startswith(packagepath+"/") ):
                            f = f.replace( packagepath+"/", "" )
                            if ( f.endswith( ".pyc" ) ):
                                # py2exe packs only pyc files in the zip archive.
                                # But to make the fnmatch.filter find these as
                                # well we have to rename them here:
                                f = f.replace( ".pyc", ".py" )
                            packagefiles.append( f )
                    matching_files = fnmatch.filter( packagefiles, pattern )
                else:
                    # path is not a zip archive (hopefully a normal directory
                    directory = os.path.join(path,packagepath)
                    dbg.var("directory")
                    if ( os.path.exists( directory ) ):
                        dbg << "  there in package " << package << " found: " << fnmatch.filter( os.listdir(directory), pattern ) << "\n"
                        dbg << "os.listdir(directory)" << os.listdir(directory) << "\n"
                        matching_files = fnmatch.filter( os.listdir(directory), pattern )
                for f in matching_files:
                    m = package + "." + f
                    dbg << "  matching file " << m << "\n"
                    factory_file_names.add(m)
            except WindowsError as e:
                # This catches "WindowsError: [Error 267] Der Verzeichnisname ist ung�ltig:"
                # when callingvia python3win and cygwin symlinks are in the PYTHONPATH.
                dbg << "Ignoring %r\n" % e
        dbg << "cFactory.Import(): Found factory files: " << factory_file_names << "\n"

        # The PyInstaller runtime imports modules via FrozenImporter. So use
        # its toc (table of content) to find our patterned modules:
        toc = None
        #--- First find the FrozenImporter instance in sys.meta_path and use its toc:
        for p in sys.meta_path:
            try:
                toc = p.toc
                break
            except:
                pass
        if (toc):
            dbg << "Found FrozenImporter.toc!\n"
            # toc is a set of strings like 'smpcom.smp_interface_canesd'
            matching_files = fnmatch.filter( [ m + ".py" for m in toc ],
                                             package + "." + pattern )

            for f in matching_files:
                dbg << "  matching file " << f << "\n"
                factory_file_names.add( f )
            dbg << "cFactory.Import(): Found frozen factory files: " << factory_file_names << "\n"
        else:
            dbg << "No FrozenImporter.toc found!\n"

        # and import them
        self.factory_modules = []
        for f in factory_file_names:
            dbg << "cFactory.Import():   importing factory module %s.%s\n" % (package,f)
            try:
                mod = f[:-3]
                self.factory_modules.append( __import__( mod, fromlist=f[:-3] ) )
            except ImportError as e:
                dbg << "Ignoring error %r\nwhile importing module %r\n" % (e,mod)
        dbg.SetFlag( False )
        #----------------------------


# end of class cFactory
######################################################################
