#
# Auto generated file, do not edit
#   containes the SMP codes like command codes or configuration codes as integer values
#   (since py has no enums)
#
import pyschunk.tools.util
#
# First some common string constants:
#
## Date and time of code generation as string
SMP_GEN_DATE = "2012-08-01"

## Name of code generator as string
SMP_GEN_NAME = "MetaProtocolParser"

## Release of code generator as string
SMP_GEN_RELEASE = "0.0.0.5-dev"

## \defgroup smp_command_codes_group command codes extracted from CmdCodes.h:
#  @{
eCmdCode = pyschunk.tools.util.enum()
eCmdCode.DUMMY_CMD = 0x00
eCmdCode.STATE_MASK_POS = 0x01
eCmdCode.STATE_MASK_VEL = 0x02
eCmdCode.UNKNOWN_CMD_03 = 0x03
eCmdCode.STATE_MASK_CUR = 0x04
eCmdCode.UNKNOWN_CMD_05 = 0x05
eCmdCode.UNKNOWN_CMD_06 = 0x06
eCmdCode.UNKNOWN_CMD_07 = 0x07
eCmdCode.UNKNOWN_CMD_08 = 0x08
eCmdCode.UNKNOWN_CMD_09 = 0x09
eCmdCode.UNKNOWN_CMD_0A = 0x0a
eCmdCode.UNKNOWN_CMD_0B = 0x0b
eCmdCode.UNKNOWN_CMD_0C = 0x0c
eCmdCode.UNKNOWN_CMD_0D = 0x0d
eCmdCode.UNKNOWN_CMD_0E = 0x0e
eCmdCode.UNKNOWN_CMD_0F = 0x0f
eCmdCode.UNKNOWN_CMD_10 = 0x10
eCmdCode.CMD_RELEASE_WORK_PIECE = 0x11
eCmdCode.UNKNOWN_CMD_12 = 0x12
eCmdCode.UNKNOWN_CMD_13 = 0x13
eCmdCode.UNKNOWN_CMD_14 = 0x14
eCmdCode.UNKNOWN_CMD_15 = 0x15
eCmdCode.CMD_ZERO_VECTOR_SEARCH = 0x16
eCmdCode.MOVE_JOG_POS = 0x17
eCmdCode.MOVE_JOG_NEG = 0x18
eCmdCode.CMD_RELEASE_BRAKE = 0x19
eCmdCode.UNKNOWN_CMD_1A = 0x1a
eCmdCode.UNKNOWN_CMD_1B = 0x1b
eCmdCode.UNKNOWN_CMD_1C = 0x1c
eCmdCode.UNKNOWN_CMD_1D = 0x1d
eCmdCode.UNKNOWN_CMD_1E = 0x1e
eCmdCode.UNKNOWN_CMD_1F = 0x1f
eCmdCode.MOVE_ROT_VECT = 0x20
eCmdCode.UNKNOWN_CMD_21 = 0x21
eCmdCode.UNKNOWN_CMD_22 = 0x22
eCmdCode.MOVE_FO_VECT = 0x23
eCmdCode.UNKNOWN_CMD_24 = 0x24
eCmdCode.UNKNOWN_CMD_25 = 0x25
eCmdCode.UNKNOWN_CMD_26 = 0x26
eCmdCode.UNKNOWN_CMD_27 = 0x27
eCmdCode.UNKNOWN_CMD_28 = 0x28
eCmdCode.UNKNOWN_CMD_29 = 0x29
eCmdCode.UNKNOWN_CMD_2A = 0x2a
eCmdCode.UNKNOWN_CMD_2B = 0x2b
eCmdCode.UNKNOWN_CMD_2C = 0x2c
eCmdCode.UNKNOWN_CMD_2D = 0x2d
eCmdCode.UNKNOWN_CMD_2E = 0x2e
eCmdCode.UNKNOWN_CMD_2F = 0x2f
eCmdCode.UNKNOWN_CMD_30 = 0x30
eCmdCode.UNKNOWN_CMD_31 = 0x31
eCmdCode.UNKNOWN_CMD_32 = 0x32
eCmdCode.UNKNOWN_CMD_33 = 0x33
eCmdCode.UNKNOWN_CMD_34 = 0x34
eCmdCode.UNKNOWN_CMD_35 = 0x35
eCmdCode.UNKNOWN_CMD_36 = 0x36
eCmdCode.UNKNOWN_CMD_37 = 0x37
eCmdCode.UNKNOWN_CMD_38 = 0x38
eCmdCode.UNKNOWN_CMD_39 = 0x39
eCmdCode.UNKNOWN_CMD_3A = 0x3a
eCmdCode.UNKNOWN_CMD_3B = 0x3b
eCmdCode.UNKNOWN_CMD_3C = 0x3c
eCmdCode.UNKNOWN_CMD_3D = 0x3d
eCmdCode.UNKNOWN_CMD_3E = 0x3e
eCmdCode.UNKNOWN_CMD_3F = 0x3f
eCmdCode.UNKNOWN_CMD_40 = 0x40
eCmdCode.UNKNOWN_CMD_41 = 0x41
eCmdCode.CMD_BRAKE_TEST = 0x42
eCmdCode.UNKNOWN_CMD_43 = 0x43
eCmdCode.UNKNOWN_CMD_44 = 0x44
eCmdCode.UNKNOWN_CMD_45 = 0x45
eCmdCode.UNKNOWN_CMD_46 = 0x46
eCmdCode.UNKNOWN_CMD_47 = 0x47
eCmdCode.UNKNOWN_CMD_48 = 0x48
eCmdCode.UNKNOWN_CMD_49 = 0x49
eCmdCode.UNKNOWN_CMD_4A = 0x4a
eCmdCode.UNKNOWN_CMD_4B = 0x4b
eCmdCode.UNKNOWN_CMD_4C = 0x4c
eCmdCode.UNKNOWN_CMD_4D = 0x4d
eCmdCode.UNKNOWN_CMD_4E = 0x4e
eCmdCode.UNKNOWN_CMD_4F = 0x4f
eCmdCode.UNKNOWN_CMD_50 = 0x50
eCmdCode.UNKNOWN_CMD_51 = 0x51
eCmdCode.UNKNOWN_CMD_52 = 0x52
eCmdCode.UNKNOWN_CMD_53 = 0x53
eCmdCode.UNKNOWN_CMD_54 = 0x54
eCmdCode.UNKNOWN_CMD_55 = 0x55
eCmdCode.UNKNOWN_CMD_56 = 0x56
eCmdCode.UNKNOWN_CMD_57 = 0x57
eCmdCode.UNKNOWN_CMD_58 = 0x58
eCmdCode.UNKNOWN_CMD_59 = 0x59
eCmdCode.UNKNOWN_CMD_5A = 0x5a
eCmdCode.UNKNOWN_CMD_5B = 0x5b
eCmdCode.UNKNOWN_CMD_5C = 0x5c
eCmdCode.UNKNOWN_CMD_5D = 0x5d
eCmdCode.UNKNOWN_CMD_5E = 0x5e
eCmdCode.UNKNOWN_CMD_5F = 0x5f
eCmdCode.UNKNOWN_CMD_60 = 0x60
eCmdCode.UNKNOWN_CMD_61 = 0x61
eCmdCode.UNKNOWN_CMD_62 = 0x62
eCmdCode.CMD_ASCII = 0x63
eCmdCode.UNKNOWN_CMD_64 = 0x64
eCmdCode.UNKNOWN_CMD_65 = 0x65
eCmdCode.UNKNOWN_CMD_66 = 0x66
eCmdCode.UNKNOWN_CMD_67 = 0x67
eCmdCode.UNKNOWN_CMD_68 = 0x68
eCmdCode.UNKNOWN_CMD_69 = 0x69
eCmdCode.UNKNOWN_CMD_6A = 0x6a
eCmdCode.UNKNOWN_CMD_6B = 0x6b
eCmdCode.UNKNOWN_CMD_6C = 0x6c
eCmdCode.UNKNOWN_CMD_6D = 0x6d
eCmdCode.UNKNOWN_CMD_6E = 0x6e
eCmdCode.UNKNOWN_CMD_6F = 0x6f
eCmdCode.UNKNOWN_CMD_70 = 0x70
eCmdCode.UNKNOWN_CMD_71 = 0x71
eCmdCode.UNKNOWN_CMD_72 = 0x72
eCmdCode.UNKNOWN_CMD_73 = 0x73
eCmdCode.UNKNOWN_CMD_74 = 0x74
eCmdCode.UNKNOWN_CMD_75 = 0x75
eCmdCode.UNKNOWN_CMD_76 = 0x76
eCmdCode.UNKNOWN_CMD_77 = 0x77
eCmdCode.UNKNOWN_CMD_78 = 0x78
eCmdCode.UNKNOWN_CMD_79 = 0x79
eCmdCode.UNKNOWN_CMD_7A = 0x7a
eCmdCode.UNKNOWN_CMD_7B = 0x7b
eCmdCode.UNKNOWN_CMD_7C = 0x7c
eCmdCode.UNKNOWN_CMD_7D = 0x7d
eCmdCode.UNKNOWN_CMD_7E = 0x7e
eCmdCode.UNKNOWN_CMD_7F = 0x7f
eCmdCode.GET_CONFIG = 0x80
eCmdCode.SET_CONFIG = 0x81
eCmdCode.GET_CONFIG_EXT = 0x82
eCmdCode.SET_CONFIG_EXT = 0x83
eCmdCode.FRAG_START = 0x84
eCmdCode.FRAG_MIDDLE = 0x85
eCmdCode.FRAG_END = 0x86
eCmdCode.FRAG_ACK = 0x87
eCmdCode.CMD_ERROR = 0x88
eCmdCode.CMD_WARNING = 0x89
eCmdCode.CMD_INFO = 0x8a
eCmdCode.CMD_ACK = 0x8b
eCmdCode.CMD_DEFAULT = 0x8c
eCmdCode.UNKNOWN_CMD_8D = 0x8d
eCmdCode.UNKNOWN_CMD_8E = 0x8e
eCmdCode.CMD_CALIB_CUR = 0x8f
eCmdCode.CMD_FAST_STOP = 0x90
eCmdCode.CMD_STOP = 0x91
eCmdCode.CMD_REFERENCE = 0x92
eCmdCode.CMD_MOVE_BLOCKED = 0x93
eCmdCode.CMD_POS_REACHED = 0x94
eCmdCode.GET_STATE = 0x95
eCmdCode.GET_DETAILED_ERROR_INFO = 0x96
eCmdCode.CMD_REFERENCE_HAND = 0x97
eCmdCode.GET_STATE_AXIS = 0x98
eCmdCode.GET_OTP_AREA = 0x99
eCmdCode.GET_CYCLE_TIME = 0x9a
eCmdCode.UNKNOWN_CMD_9B = 0x9b
eCmdCode.UNKNOWN_CMD_9C = 0x9c
eCmdCode.UNKNOWN_CMD_9D = 0x9d
eCmdCode.UNKNOWN_CMD_9E = 0x9e
eCmdCode.UNKNOWN_CMD_9F = 0x9f
eCmdCode.SET_TARGET_VEL = 0xa0
eCmdCode.SET_TARGET_ACC = 0xa1
eCmdCode.SET_TARGET_JERK = 0xa2
eCmdCode.SET_TARGET_CUR = 0xa3
eCmdCode.SET_TARGET_TIME = 0xa4
eCmdCode.SET_TARGET_FORCE = 0xa5
eCmdCode.SET_TARGET_POS = 0xa6
eCmdCode.SET_TARGET_POS_REL = 0xa7
eCmdCode.UNKNOWN_CMD_A8 = 0xa8
eCmdCode.UNKNOWN_CMD_A9 = 0xa9
eCmdCode.UNKNOWN_CMD_AA = 0xaa
eCmdCode.UNKNOWN_CMD_AB = 0xab
eCmdCode.UNKNOWN_CMD_AC = 0xac
eCmdCode.UNKNOWN_CMD_AD = 0xad
eCmdCode.UNKNOWN_CMD_AE = 0xae
eCmdCode.MOVE_GRIP_WORKPIECE_WITH_POSITION = 0xaf
eCmdCode.MOVE_POS = 0xb0
eCmdCode.MOVE_POS_TIME = 0xb1
eCmdCode.MOVE_SRU_POS = 0xb2
eCmdCode.MOVE_CUR = 0xb3
eCmdCode.MOVE_FORCE = 0xb4
eCmdCode.MOVE_VEL = 0xb5
eCmdCode.MOVE_PWM = 0xb6
eCmdCode.MOVE_GRIP = 0xb7
eCmdCode.MOVE_POS_REL = 0xb8
eCmdCode.MOVE_POS_TIME_REL = 0xb9
eCmdCode.MOVE_POS_LOOP = 0xba
eCmdCode.MOVE_POS_TIME_LOOP = 0xbb
eCmdCode.MOVE_POS_REL_LOOP = 0xbc
eCmdCode.MOVE_POS_TIME_REL_LOOP = 0xbd
eCmdCode.CMD_TEST_REL_POS = 0xbe
eCmdCode.MOVE_CUR_PWM = 0xbf
eCmdCode.SET_PHRASE = 0xc0
eCmdCode.EXE_PHRASE = 0xc1
eCmdCode.GET_PHRASES = 0xc2
eCmdCode.PRG_GOTO = 0xc3
eCmdCode.PRG_WAIT = 0xc4
eCmdCode.PRG_END = 0xc5
eCmdCode.CONFIG_VES = 0xc6
eCmdCode.OPCODE = 0xc7
eCmdCode.PRG_GET_PROGRAM_NO = 0xc8
eCmdCode.PRG_SET_PARAMETER = 0xc9
eCmdCode.PRG_GET_PARAMETER = 0xca
eCmdCode.PRG_END_PROGRAM = 0xcb
eCmdCode.UNKNOWN_CMD_CC = 0xcc
eCmdCode.UNKNOWN_CMD_CD = 0xcd
eCmdCode.CMD_RESTART_ANYBUS = 0xce
eCmdCode.PRG_EXE = 0xcf
eCmdCode.PRG_EXEC_GRIP_TEST = 0xd0
eCmdCode.EXE_PHRASE1 = 0xd1
eCmdCode.EXE_PHRASE2 = 0xd2
eCmdCode.EXE_PHRASE3 = 0xd3
eCmdCode.EXE_PHRASE4 = 0xd4
eCmdCode.EXE_PHRASE5 = 0xd5
eCmdCode.EXE_PHRASE6 = 0xd6
eCmdCode.EXE_PHRASE7 = 0xd7
eCmdCode.EXE_PHRASE8 = 0xd8
eCmdCode.EXE_PHRASE9 = 0xd9
eCmdCode.EXE_PHRASE10 = 0xda
eCmdCode.EXE_PHRASE11 = 0xdb
eCmdCode.EXE_PHRASE12 = 0xdc
eCmdCode.EXE_PHRASE13 = 0xdd
eCmdCode.EXE_PHRASE14 = 0xde
eCmdCode.EXE_PHRASE15 = 0xdf
eCmdCode.CMD_REBOOT = 0xe0
eCmdCode.CMD_DIO = 0xe1
eCmdCode.CMD_FLASH_MODE = 0xe2
eCmdCode.CHANGE_USER = 0xe3
eCmdCode.CHECK_MC_PC_COMMUNICATION = 0xe4
eCmdCode.CHECK_PC_MC_COMMUNICATION = 0xe5
eCmdCode.CMD_DISCONNECT = 0xe6
eCmdCode.CMD_TOGGLE_IMPULSE_MESSAGE = 0xe7
eCmdCode.CMD_FLASH_MODE_SWITCH = 0xe8
eCmdCode.CMD_GET_DIO = 0xe9
eCmdCode.CMD_SET_DIO = 0xea
eCmdCode.CMD_DIO_AXIS = 0xeb
eCmdCode.CMD_SLAVE_MODE = 0xec
eCmdCode.CMD_MASTER_MODE = 0xed
eCmdCode.CMD_MAG_PROTOCOL_ACTIVE = 0xee
eCmdCode.GET_SENSOR_TEMPERATURE = 0xef
eCmdCode.GET_TEMPERATURE = 0xf0
eCmdCode.CMD_HWTEST = 0xf1
eCmdCode.UNKNOWN_CMD_F2 = 0xf2
eCmdCode.UNKNOWN_CMD_F3 = 0xf3
eCmdCode.UNKNOWN_CMD_F4 = 0xf4
eCmdCode.CMD_MAG_SET_VALVE = 0xf5
eCmdCode.CMD_LASE = 0xf6
eCmdCode.CMD_LASE_IMPULSE = 0xf7
eCmdCode.CAMAT_CHANGE_PROGRAM = 0xf8
eCmdCode.CAMAT_SETTINGS_CHANGED = 0xf9
eCmdCode.CAMAT_RES_MEASUREMENT_BLOCK = 0xfa
eCmdCode.CMD_ROBOT = 0xfb
eCmdCode.CMD_ROBOT_PARAM = 0xfc
eCmdCode.CMD_ROBOT_RESERVED = 0xfd
eCmdCode.CAMAT_TRIGGER = 0xfe
eCmdCode.ERASE_CYCLE_COUNT = 0xff
##
#  @} # end of group smp_command_codes_group

#
#Protocol version from ProtocolVersion.h:
#
PROTOKOLL_VERSION                        = 0x04

#
## \defgroup smp_configuration_codes_group configuration codes for GET_CONFIG from eepromParam.h:
#  @{
eParamList = pyschunk.tools.util.enum()
eParamList.PARAM_ID = 0x01
eParamList.PARAM_GROUP = 0x02
eParamList.PARAM_RS232_BAUD = 0x03
eParamList.PARAM_CAN_BAUD = 0x04
eParamList.PARAM_COMMINTERFACE_MAIN = 0x05
eParamList.PARAM_UNITSYSTEM = 0x06
eParamList.PARAM_SOFT_HIGH_TMP = 0x07
eParamList.PARAM_SOFT_LOW_TMP = 0x08
eParamList.PARAM_MAX_VEL = 0x09
eParamList.PARAM_MAX_ACC = 0x0a
eParamList.PARAM_MAX_CURRENT = 0x0b
eParamList.PARAM_NOM_CURRENT = 0x0c
eParamList.PARAM_MAX_JERK = 0x0d
eParamList.PARAM_OFFSET_PHASE_A = 0x0e
eParamList.PARAM_OFFSET_PHASE_B = 0x0f
eParamList.PARAM_POS_ADC_OFFSET = 0x10
eParamList.PARAM_DEFAULT_VALUES = 0x11
eParamList.PARAM_SERVICE_ERROR = 0x12
eParamList.PARAM_DATA_CRC = 0x13
eParamList.PARAM_OFFSET_REFERENCE = 0x14
eParamList.PARAM_SER_NUM_DEVICE = 0x15
eParamList.PARAM_ORDER_NUMBER = 0x16
eParamList.PARAM_MAX_FORCE = 0x17
eParamList.PARAM_GEAR_RATIO = 0x18
eParamList.PARAM_GET_NUM_AXIS = 0x19
eParamList.PARAM_PINION_EXTEND = 0x1a
eParamList.PARAM_SPINDLE_RISING = 0x1b
eParamList.PARAM_MAX_VEL_REMEMBER = 0x1c
eParamList.PARAM_MAX_ACC_REMEMBER = 0x1d
eParamList.PARAM_AXIS_LENGTH = 0x1e
eParamList.PARAM_GEAR_DIVIDEND = 0x1f
eParamList.PARAM_MAX_MEASURE_CURRENT = 0x20
eParamList.PARAM_OPTION = 0x21
eParamList.PARAM_MOTOR_VOLTAGE = 0x22
eParamList.PARAM_LOGIC_VOLTAGE = 0x23
eParamList.PARAM_INST_ASSIST_FLAGS = 0x24
eParamList.PARAM_EEPROM_VERSION = 0x25
eParamList.PARAM_SOFT_HIGH = 0x26
eParamList.PARAM_SOFT_LOW = 0x27
eParamList.PARAM_REF_MODE = 0x28
eParamList.PARAM_MAX_TEMP = 0x29
eParamList.PARAM_COMMINTERFACE_SECOND = 0x2a
eParamList.PARAM_MIN_TEMP = 0x30
eParamList.PARAM_DIGITAL_IN_USAGE = 0x31
eParamList.PARAM_DIGITAL_OUT_USAGE = 0x32
eParamList.PARAM_OTP_YEAR_WEEK = 0x33
eParamList.PARAM_HARDWARE_VERSION = 0x34
eParamList.PARAM_REFERENCE_USE_INDEX = 0x35
eParamList.PARAM_DISTANCE_FROM_INDEX = 0x36
eParamList.PARAM_ERROR_DETAIL_LINE = 0x37
eParamList.PARAM_ERROR_DETAIL_FILE = 0x38
eParamList.PARAM_ERROR_DETAIL_VALUE = 0x39
eParamList.PARAM_POSSYSTEM_PARAM1 = 0x3a
eParamList.PARAM_COMMUTATION_MODE = 0x40
eParamList.SECT_ERROR_HISTORY = 0xfd
eParamList.SECT_CONFIG = 0xfe
eParamList.SECT_EXTENDED = 0xff
eParamList.Add( 'PARAM_MOTOR_RESISTANCE', 0x100 )
eParamList.Add( 'PARAM_MOTOR_INDUCTANCE', 0x101 )
eParamList.Add( 'PARAM_MOTOR_CONSTANT', 0x102 )
eParamList.Add( 'PARAM_SLAVE_MOTOR_SINGLE_BIT', 0x1a0 )
eParamList.Add( 'PARAM_SLAVE_MOTOR_MULTI_BIT', 0x1a1 )
eParamList.Add( 'PARAM_SLAVE_MOTOR_RATIO', 0x1a2 )
eParamList.Add( 'PARAM_KR_CURRENT', 0x2000 )
eParamList.Add( 'PARAM_TN_CURRENT', 0x2001 )
eParamList.Add( 'PARAM_TD_CURRENT', 0x2002 )
eParamList.Add( 'PARAM_KC_CURRENT', 0x2003 )
eParamList.Add( 'PARAM_KR_SPEED', 0x2010 )
eParamList.Add( 'PARAM_TN_SPEED', 0x2011 )
eParamList.Add( 'PARAM_TD_SPEED', 0x2012 )
eParamList.Add( 'PARAM_KC_SPEED', 0x2013 )
eParamList.Add( 'PARAM_KS_FEED_FORWARD', 0x2014 )
eParamList.Add( 'PARAM_KR_POS', 0x2020 )
eParamList.Add( 'PARAM_TN_POS', 0x2021 )
eParamList.Add( 'PARAM_TD_POS', 0x2022 )
eParamList.Add( 'PARAM_KC_POS', 0x2023 )
eParamList.Add( 'PARAM_FEED_FORWARD', 0x2024 )
eParamList.Add( 'PARAM_CONTROLLER_STRUCT', 0x2030 )
eParamList.Add( 'PARAM_POSITIONING_RAMP_TYPE', 0x2040 )
eParamList.Add( 'PARAM_CONTROLLER_DELTA_POS', 0x2041 )
eParamList.Add( 'PARAM_DEVICE_TOW_ERROR', 0x2042 )
eParamList.Add( 'PARAM_VALVE0_VOLTAGE', 0x3000 )
eParamList.Add( 'PARAM_VALVE1_VOLTAGE', 0x3001 )
eParamList.Add( 'PARAM_VALVE2_VOLTAGE', 0x3002 )
eParamList.Add( 'PARAM_VALVE3_VOLTAGE', 0x3003 )
eParamList.Add( 'PARAM_VALVE4_VOLTAGE', 0x3004 )
eParamList.Add( 'PARAM_VALVE5_VOLTAGE', 0x3005 )
eParamList.Add( 'PARAM_VALVE6_VOLTAGE', 0x3006 )
eParamList.Add( 'PARAM_VALVE7_VOLTAGE', 0x3007 )
eParamList.Add( 'PARAM_VALVE8_VOLTAGE', 0x3008 )
eParamList.Add( 'PARAM_VALVE0_RESISTANCE', 0x3010 )
eParamList.Add( 'PARAM_VALVE1_RESISTANCE', 0x3011 )
eParamList.Add( 'PARAM_VALVE2_RESISTANCE', 0x3012 )
eParamList.Add( 'PARAM_VALVE3_RESISTANCE', 0x3013 )
eParamList.Add( 'PARAM_VALVE4_RESISTANCE', 0x3014 )
eParamList.Add( 'PARAM_VALVE5_RESISTANCE', 0x3015 )
eParamList.Add( 'PARAM_VALVE6_RESISTANCE', 0x3016 )
eParamList.Add( 'PARAM_VALVE7_RESISTANCE', 0x3017 )
eParamList.Add( 'PARAM_VALVE8_RESISTANCE', 0x3018 )
eParamList.Add( 'PARAM_VALVE0_INDUCTANCE', 0x3020 )
eParamList.Add( 'PARAM_VALVE1_INDUCTANCE', 0x3021 )
eParamList.Add( 'PARAM_VALVE2_INDUCTANCE', 0x3022 )
eParamList.Add( 'PARAM_VALVE3_INDUCTANCE', 0x3023 )
eParamList.Add( 'PARAM_VALVE4_INDUCTANCE', 0x3024 )
eParamList.Add( 'PARAM_VALVE5_INDUCTANCE', 0x3025 )
eParamList.Add( 'PARAM_VALVE6_INDUCTANCE', 0x3026 )
eParamList.Add( 'PARAM_VALVE7_INDUCTANCE', 0x3027 )
eParamList.Add( 'PARAM_VALVE8_INDUCTANCE', 0x3028 )
eParamList.Add( 'PARAM_VALVE0_FLAG_ENABLE', 0x3030 )
eParamList.Add( 'PARAM_VALVE1_FLAG_ENABLE', 0x3031 )
eParamList.Add( 'PARAM_VALVE2_FLAG_ENABLE', 0x3032 )
eParamList.Add( 'PARAM_VALVE3_FLAG_ENABLE', 0x3033 )
eParamList.Add( 'PARAM_VALVE4_FLAG_ENABLE', 0x3034 )
eParamList.Add( 'PARAM_VALVE5_FLAG_ENABLE', 0x3035 )
eParamList.Add( 'PARAM_VALVE6_FLAG_ENABLE', 0x3036 )
eParamList.Add( 'PARAM_VALVE7_FLAG_ENABLE', 0x3037 )
eParamList.Add( 'PARAM_VALVE8_FLAG_ENABLE', 0x3038 )
eParamList.Add( 'PARAM_VALVE0_NOM_CURRENT', 0x3040 )
eParamList.Add( 'PARAM_VALVE1_NOM_CURRENT', 0x3041 )
eParamList.Add( 'PARAM_VALVE2_NOM_CURRENT', 0x3042 )
eParamList.Add( 'PARAM_VALVE3_NOM_CURRENT', 0x3043 )
eParamList.Add( 'PARAM_VALVE4_NOM_CURRENT', 0x3044 )
eParamList.Add( 'PARAM_VALVE5_NOM_CURRENT', 0x3045 )
eParamList.Add( 'PARAM_VALVE6_NOM_CURRENT', 0x3046 )
eParamList.Add( 'PARAM_VALVE7_NOM_CURRENT', 0x3047 )
eParamList.Add( 'PARAM_VALVE8_NOM_CURRENT', 0x3048 )
eParamList.Add( 'PARAM_VALVE0_EXCITATION_CURRENT', 0x3050 )
eParamList.Add( 'PARAM_VALVE1_EXCITATION_CURRENT', 0x3051 )
eParamList.Add( 'PARAM_VALVE2_EXCITATION_CURRENT', 0x3052 )
eParamList.Add( 'PARAM_VALVE3_EXCITATION_CURRENT', 0x3053 )
eParamList.Add( 'PARAM_VALVE4_EXCITATION_CURRENT', 0x3054 )
eParamList.Add( 'PARAM_VALVE5_EXCITATION_CURRENT', 0x3055 )
eParamList.Add( 'PARAM_VALVE6_EXCITATION_CURRENT', 0x3056 )
eParamList.Add( 'PARAM_VALVE7_EXCITATION_CURRENT', 0x3057 )
eParamList.Add( 'PARAM_VALVE8_EXCITATION_CURRENT', 0x3058 )
eParamList.Add( 'PARAM_VALVE0_EXCITATION_ENABLE', 0x3060 )
eParamList.Add( 'PARAM_VALVE1_EXCITATION_ENABLE', 0x3061 )
eParamList.Add( 'PARAM_VALVE2_EXCITATION_ENABLE', 0x3062 )
eParamList.Add( 'PARAM_VALVE3_EXCITATION_ENABLE', 0x3063 )
eParamList.Add( 'PARAM_VALVE4_EXCITATION_ENABLE', 0x3064 )
eParamList.Add( 'PARAM_VALVE5_EXCITATION_ENABLE', 0x3065 )
eParamList.Add( 'PARAM_VALVE6_EXCITATION_ENABLE', 0x3066 )
eParamList.Add( 'PARAM_VALVE7_EXCITATION_ENABLE', 0x3067 )
eParamList.Add( 'PARAM_VALVE8_EXCITATION_ENABLE', 0x3068 )
eParamList.Add( 'PARAM_VALVE0_KP', 0x3070 )
eParamList.Add( 'PARAM_VALVE1_KP', 0x3071 )
eParamList.Add( 'PARAM_VALVE2_KP', 0x3072 )
eParamList.Add( 'PARAM_VALVE3_KP', 0x3073 )
eParamList.Add( 'PARAM_VALVE4_KP', 0x3074 )
eParamList.Add( 'PARAM_VALVE5_KP', 0x3075 )
eParamList.Add( 'PARAM_VALVE6_KP', 0x3076 )
eParamList.Add( 'PARAM_VALVE7_KP', 0x3077 )
eParamList.Add( 'PARAM_VALVE8_KP', 0x3078 )
eParamList.Add( 'PARAM_VALVE0_TN', 0x3080 )
eParamList.Add( 'PARAM_VALVE1_TN', 0x3081 )
eParamList.Add( 'PARAM_VALVE2_TN', 0x3082 )
eParamList.Add( 'PARAM_VALVE3_TN', 0x3083 )
eParamList.Add( 'PARAM_VALVE4_TN', 0x3084 )
eParamList.Add( 'PARAM_VALVE5_TN', 0x3085 )
eParamList.Add( 'PARAM_VALVE6_TN', 0x3086 )
eParamList.Add( 'PARAM_VALVE7_TN', 0x3087 )
eParamList.Add( 'PARAM_VALVE8_TN', 0x3088 )
eParamList.Add( 'PARAM_VALVE0_KC', 0x3090 )
eParamList.Add( 'PARAM_VALVE1_KC', 0x3091 )
eParamList.Add( 'PARAM_VALVE2_KC', 0x3092 )
eParamList.Add( 'PARAM_VALVE3_KC', 0x3093 )
eParamList.Add( 'PARAM_VALVE4_KC', 0x3094 )
eParamList.Add( 'PARAM_VALVE5_KC', 0x3095 )
eParamList.Add( 'PARAM_VALVE6_KC', 0x3096 )
eParamList.Add( 'PARAM_VALVE7_KC', 0x3097 )
eParamList.Add( 'PARAM_VALVE8_KC', 0x3098 )
eParamList.Add( 'PARAM_VALVE0_MAX_TEMP', 0x3100 )
eParamList.Add( 'PARAM_VALVE1_MAX_TEMP', 0x3101 )
eParamList.Add( 'PARAM_VALVE2_MAX_TEMP', 0x3102 )
eParamList.Add( 'PARAM_VALVE3_MAX_TEMP', 0x3103 )
eParamList.Add( 'PARAM_VALVE4_MAX_TEMP', 0x3104 )
eParamList.Add( 'PARAM_VALVE5_MAX_TEMP', 0x3105 )
eParamList.Add( 'PARAM_VALVE6_MAX_TEMP', 0x3106 )
eParamList.Add( 'PARAM_VALVE7_MAX_TEMP', 0x3107 )
eParamList.Add( 'PARAM_VALVE8_MAX_TEMP', 0x3108 )
eParamList.Add( 'PARAM_VALVE0_MAX_MEAS_CURRENT', 0x3110 )
eParamList.Add( 'PARAM_VALVE1_MAX_MEAS_CURRENT', 0x3111 )
eParamList.Add( 'PARAM_VALVE2_MAX_MEAS_CURRENT', 0x3112 )
eParamList.Add( 'PARAM_VALVE3_MAX_MEAS_CURRENT', 0x3113 )
eParamList.Add( 'PARAM_VALVE4_MAX_MEAS_CURRENT', 0x3114 )
eParamList.Add( 'PARAM_VALVE5_MAX_MEAS_CURRENT', 0x3115 )
eParamList.Add( 'PARAM_VALVE6_MAX_MEAS_CURRENT', 0x3116 )
eParamList.Add( 'PARAM_VALVE7_MAX_MEAS_CURRENT', 0x3117 )
eParamList.Add( 'PARAM_VALVE8_MAX_MEAS_CURRENT', 0x3118 )
eParamList.Add( 'PARAM_VALVE0_OVER_EXCITATION_DURATION', 0x3120 )
eParamList.Add( 'PARAM_VALVE1_OVER_EXCITATION_DURATION', 0x3121 )
eParamList.Add( 'PARAM_VALVE2_OVER_EXCITATION_DURATION', 0x3122 )
eParamList.Add( 'PARAM_VALVE3_OVER_EXCITATION_DURATION', 0x3123 )
eParamList.Add( 'PARAM_VALVE4_OVER_EXCITATION_DURATION', 0x3124 )
eParamList.Add( 'PARAM_VALVE5_OVER_EXCITATION_DURATION', 0x3125 )
eParamList.Add( 'PARAM_VALVE6_OVER_EXCITATION_DURATION', 0x3126 )
eParamList.Add( 'PARAM_VALVE7_OVER_EXCITATION_DURATION', 0x3127 )
eParamList.Add( 'PARAM_VALVE8_OVER_EXCITATION_DURATION', 0x3128 )
eParamList.Add( 'PARAM_VALVE0_DELAY_TIME', 0x3130 )
eParamList.Add( 'PARAM_VALVE1_DELAY_TIME', 0x3131 )
eParamList.Add( 'PARAM_VALVE2_DELAY_TIME', 0x3132 )
eParamList.Add( 'PARAM_VALVE3_DELAY_TIME', 0x3133 )
eParamList.Add( 'PARAM_VALVE4_DELAY_TIME', 0x3134 )
eParamList.Add( 'PARAM_VALVE5_DELAY_TIME', 0x3135 )
eParamList.Add( 'PARAM_VALVE6_DELAY_TIME', 0x3136 )
eParamList.Add( 'PARAM_VALVE7_DELAY_TIME', 0x3137 )
eParamList.Add( 'PARAM_VALVE8_DELAY_TIME', 0x3138 )
eParamList.Add( 'PARAM_VALVE0_MAX_CURRENT', 0x3140 )
eParamList.Add( 'PARAM_VALVE1_MAX_CURRENT', 0x3141 )
eParamList.Add( 'PARAM_VALVE2_MAX_CURRENT', 0x3142 )
eParamList.Add( 'PARAM_VALVE3_MAX_CURRENT', 0x3143 )
eParamList.Add( 'PARAM_VALVE4_MAX_CURRENT', 0x3144 )
eParamList.Add( 'PARAM_VALVE5_MAX_CURRENT', 0x3145 )
eParamList.Add( 'PARAM_VALVE6_MAX_CURRENT', 0x3146 )
eParamList.Add( 'PARAM_VALVE7_MAX_CURRENT', 0x3147 )
eParamList.Add( 'PARAM_VALVE8_MAX_CURRENT', 0x3148 )
eParamList.Add( 'PARAM_VALVE0_CUR_CONTROL_ENABLE', 0x3150 )
eParamList.Add( 'PARAM_VALVE1_CUR_CONTROL_ENABLE', 0x3151 )
eParamList.Add( 'PARAM_VALVE2_CUR_CONTROL_ENABLE', 0x3152 )
eParamList.Add( 'PARAM_VALVE3_CUR_CONTROL_ENABLE', 0x3153 )
eParamList.Add( 'PARAM_VALVE4_CUR_CONTROL_ENABLE', 0x3154 )
eParamList.Add( 'PARAM_VALVE5_CUR_CONTROL_ENABLE', 0x3155 )
eParamList.Add( 'PARAM_VALVE6_CUR_CONTROL_ENABLE', 0x3156 )
eParamList.Add( 'PARAM_VALVE7_CUR_CONTROL_ENABLE', 0x3157 )
eParamList.Add( 'PARAM_VALVE8_CUR_CONTROL_ENABLE', 0x3158 )
eParamList.Add( 'PARAM_POSA_WAIT_TIME', 0x3160 )
eParamList.Add( 'PARAM_POSB_WAIT_TIME', 0x3161 )
eParamList.Add( 'PARAM_POSC_WAIT_TIME', 0x3162 )
eParamList.Add( 'PARAM_POSD_WAIT_TIME', 0x3163 )
eParamList.Add( 'PARAM_POSE_WAIT_TIME', 0x3164 )
eParamList.Add( 'PARAM_POSF_WAIT_TIME', 0x3165 )
eParamList.Add( 'PARAM_MODULE_VARIANT', 0x3166 )
eParamList.Add( 'PARAM_DIRECTION_WAIT_POSB', 0x3170 )
eParamList.Add( 'PARAM_DIRECTION_WAIT_POSC', 0x3171 )
eParamList.Add( 'PARAM_GRIPPER_AVAILABLE', 0x3190 )
eParamList.Add( 'PARAM_GRIPPER_POSA_POSD', 0x3200 )
eParamList.Add( 'PARAM_EXTERN_START', 0x3300 )
eParamList.Add( 'PARAM_NUMBER_OF_CYCLES', 0x3333 )
eParamList.Add( 'PARAM_INTERMEDIATE_STOP', 0x4444 )
eParamList.Add( 'PARAM_CONTRA_PRSSURE_DURATION', 0x5555 )
eParamList.Add( 'POWERBALL_OFFSET_PHASEA', 0x6001 )
eParamList.Add( 'POWERBALL_OFFSET_PHASEB', 0x6002 )
eParamList.Add( 'POWERBALL_OFFSET_INDUCTANCE', 0x6003 )
eParamList.Add( 'WINTER_PARAM_SPEED', 0x7001 )
eParamList.Add( 'WINTER_PARAM_CUR20NM', 0x7002 )
eParamList.Add( 'WINTER_PARAM_CUR40NM', 0x7003 )
eParamList.Add( 'WINTER_PARAM_CUR60NM', 0x7004 )
eParamList.Add( 'WINTER_PARAM_DELTA_OPEN_POS', 0x7005 )
eParamList.Add( 'WINTER_PARAM_WAIT_ANALOG', 0x7006 )
eParamList.Add( 'WINTER_PARAM_WAIT_TIPP', 0x7007 )
eParamList.Add( 'WINTER_PARAM_MOVE_BACK', 0x7008 )
eParamList.Add( 'WINTER_PARAM_POS_MOMENT_CHANGE', 0x7009 )
eParamList.Add( 'WINTER_PARAM_MIN_VOLTAGE', 0x700a )
eParamList.Add( 'WINTER_PARAM_WORKING_VOLTAGE', 0x700b )
eParamList.Add( 'PARAM_DEBUG_FLAGS', 0x7f00 )
eParamList.Add( 'PARAM_LAST_VALUE', 0x7fff )
##
#  @} # end of group smp_configuration_codes_group

#
## \defgroup smp_robot_command_codes_group robot command codes from RobotCodes.h:
#
ROBOT_ERROR                              = 0x00
MOVE_CART                                = 0x01
MOVE_JOINT                               = 0x02
GET_CART_POS                             = 0x03
GET_JOINT_POS                            = 0x04
MOVE_CART_ALL                            = 0x05
MOVE_JOINT_ALL                           = 0x06
SET_PROFILE                              = 0x07
##
#  @} # end of group smp_robot_command_codes_group

#
## \defgroup smp_error_codes_group info and error codes from ReturnCodes.h:
#
eErrorCode = pyschunk.tools.util.enum()
eErrorCode.ERROR_NONE = 0x00
eErrorCode.INFO_BOOT = 0x01
eErrorCode.INFO_TODO = 0x01
eErrorCode.INFO_NO_FREE_SPACE = 0x02
eErrorCode.INFO_NO_RIGHTS = 0x03
eErrorCode.INFO_UNKNOWN_COMMAND = 0x04
eErrorCode.INFO_FAILED = 0x05
eErrorCode.INFO_NOT_REFERENCED = 0x06
eErrorCode.INFO_SEARCH_SINUS_VECTOR = 0x07
eErrorCode.UNKNOWN_ERROR_07 = 0x07
eErrorCode.UNKNOWN_ERROR_08 = 0x08
eErrorCode.INFO_NO_ERROR = 0x08
eErrorCode.INFO_COMMUNICATION_ERROR = 0x09
eErrorCode.INFO_PROGRAM_DEBUGDATA = 0x0a
eErrorCode.INFO_PROGRAM_FINISHED = 0x0b
eErrorCode.INFO_PROGRAM_ABORTED = 0x0c
eErrorCode.INFO_PROGRAM_PAUSED = 0x0d
eErrorCode.INFO_PROGRAM_CONTINUED = 0x0e
eErrorCode.INFO_SEQUENCE_END = 0x0f
eErrorCode.INFO_TIMEOUT = 0x10
eErrorCode.INFO_UNKNOWN_AXIS_INDEX = 0x11
eErrorCode.INFO_WRONG_DATA_TYPE = 0x12
eErrorCode.INFO_RESTART = 0x13
eErrorCode.UNKNOWN_ERROR_14 = 0x14
eErrorCode.UNKNOWN_ERROR_15 = 0x15
eErrorCode.INFO_WRONG_BAUDRATE = 0x16
eErrorCode.UNKNOWN_ERROR_17 = 0x17
eErrorCode.UNKNOWN_ERROR_18 = 0x18
eErrorCode.INFO_CHECKSUM = 0x19
eErrorCode.UNKNOWN_ERROR_1A = 0x1a
eErrorCode.INFO_VALUE_LIMIT_MAX = 0x1b
eErrorCode.INFO_VALUE_LIMIT_MIN = 0x1c
eErrorCode.INFO_MESSAGE_LENGTH = 0x1d
eErrorCode.INFO_WRONG_PARAMETER = 0x1e
eErrorCode.INFO_PROGRAM_END = 0x1f
eErrorCode.INFO_BATTERY_LOW = 0x20
eErrorCode.ERROR_BATTERY_DOWN = 0x21
eErrorCode.INFO_POSITION_NOT_REACHABLE = 0x22
eErrorCode.INFO_UNKNOWN_PARAMETER = 0x23
eErrorCode.ERROR_HEARTBEAT_TIMEOUT = 0x24
eErrorCode.INFO_NMT_STOPPED = 0x25
eErrorCode.INFO_NMT_RESETNODE = 0x26
eErrorCode.INFO_NMT_PREOPERATIONAL = 0x27
eErrorCode.ERROR_BRAKE_TEST_FAILED = 0x28
eErrorCode.ERROR_SAFE_TORQUE_OFF = 0x29
eErrorCode.ERROR_GEARSIDE_POS_SYSTEM = 0x2a
eErrorCode.UNKNOWN_ERROR_2B = 0x2b
eErrorCode.UNKNOWN_ERROR_2C = 0x2c
eErrorCode.UNKNOWN_ERROR_2D = 0x2d
eErrorCode.UNKNOWN_ERROR_2E = 0x2e
eErrorCode.UNKNOWN_ERROR_2F = 0x2f
eErrorCode.UNKNOWN_ERROR_30 = 0x30
eErrorCode.UNKNOWN_ERROR_31 = 0x31
eErrorCode.UNKNOWN_ERROR_32 = 0x32
eErrorCode.UNKNOWN_ERROR_33 = 0x33
eErrorCode.UNKNOWN_ERROR_34 = 0x34
eErrorCode.UNKNOWN_ERROR_35 = 0x35
eErrorCode.UNKNOWN_ERROR_36 = 0x36
eErrorCode.UNKNOWN_ERROR_37 = 0x37
eErrorCode.UNKNOWN_ERROR_38 = 0x38
eErrorCode.UNKNOWN_ERROR_39 = 0x39
eErrorCode.UNKNOWN_ERROR_3A = 0x3a
eErrorCode.UNKNOWN_ERROR_3B = 0x3b
eErrorCode.UNKNOWN_ERROR_3C = 0x3c
eErrorCode.UNKNOWN_ERROR_3D = 0x3d
eErrorCode.UNKNOWN_ERROR_3E = 0x3e
eErrorCode.UNKNOWN_ERROR_3F = 0x3f
eErrorCode.INFO_TRIGGER = 0x40
eErrorCode.INFO_READY = 0x41
eErrorCode.INFO_GUI_CONNECTED = 0x42
eErrorCode.INFO_GUI_DISCONNECTED = 0x43
eErrorCode.INFO_PROGRAM_CHANGED = 0x44
eErrorCode.INFO_PROGRAM_CHANGE_FAILED = 0x45
eErrorCode.UNKNOWN_ERROR_46 = 0x46
eErrorCode.UNKNOWN_ERROR_47 = 0x47
eErrorCode.UNKNOWN_ERROR_48 = 0x48
eErrorCode.UNKNOWN_ERROR_49 = 0x49
eErrorCode.UNKNOWN_ERROR_4A = 0x4a
eErrorCode.UNKNOWN_ERROR_4B = 0x4b
eErrorCode.UNKNOWN_ERROR_4C = 0x4c
eErrorCode.UNKNOWN_ERROR_4D = 0x4d
eErrorCode.UNKNOWN_ERROR_4E = 0x4e
eErrorCode.UNKNOWN_ERROR_4F = 0x4f
eErrorCode.ERROR_FORCE25 = 0x50
eErrorCode.ERROR_FORCE50 = 0x51
eErrorCode.ERROR_FORCE75 = 0x52
eErrorCode.ERROR_FORCE100 = 0x53
eErrorCode.INFO_MAINTENANCE = 0x54
eErrorCode.INFO_UPLOAD_REQUEST = 0x55
eErrorCode.INFO_WRONG_FORCE = 0x56
eErrorCode.INFO_WRONG_WORKPIECE = 0x57
eErrorCode.ERROR_POSITION_BLOCKED = 0x58
eErrorCode.INFO_TEMP_HIGH = 0x59
eErrorCode.ERROR_TECHNO_VOLTAGE_LOW = 0x5a
eErrorCode.ERROR_TECHNO_VOLTAGE_HIGH = 0x5b
eErrorCode.UNKNOWN_ERROR_5C = 0x5c
eErrorCode.UNKNOWN_ERROR_5D = 0x5d
eErrorCode.UNKNOWN_ERROR_5E = 0x5e
eErrorCode.UNKNOWN_ERROR_5F = 0x5f
eErrorCode.ERROR_FILE_IS_NOT_FOUND = 0x60
eErrorCode.ERROR_FILE_IS_CORRUPT = 0x61
eErrorCode.ERROR_FILE_TYPE_WRONG = 0x62
eErrorCode.ERROR_FILE_WRONG_KEY = 0x63
eErrorCode.ERROR_FILE_SYSTEM_WRONG = 0x64
eErrorCode.ERROR_FILE_READ = 0x65
eErrorCode.ERROR_FILE_IS_NOT_CREATED = 0x66
eErrorCode.ERROR_FILE_WRITE = 0x67
eErrorCode.UNKNOWN_ERROR_68 = 0x68
eErrorCode.UNKNOWN_ERROR_69 = 0x69
eErrorCode.ERROR_CONNECTION_TEMP_LOW = 0x6a
eErrorCode.ERROR_CONNECTION_TEMP_HIGH = 0x6b
eErrorCode.ERROR_MOTOR_TEMP_LOW = 0x6c
eErrorCode.ERROR_MOTOR_TEMP_HIGH = 0x6d
eErrorCode.ERROR_TEMP_LOW_OPTION = 0x6e
eErrorCode.ERROR_TEMP_HIGH_OPTION = 0x6f
eErrorCode.ERROR_TEMP_LOW = 0x70
eErrorCode.ERROR_TEMP_HIGH = 0x71
eErrorCode.ERROR_LOGIC_LOW = 0x72
eErrorCode.ERROR_LOGIC_HIGH = 0x73
eErrorCode.ERROR_MOTOR_VOLTAGE_LOW = 0x74
eErrorCode.ERROR_MOTOR_VOLTAGE_HIGH = 0x75
eErrorCode.ERROR_CABLE_BREAK = 0x76
eErrorCode.ERROR_MOTOR_VOLTAGE_SHORT = 0x77
eErrorCode.ERROR_POWER = 0x78
eErrorCode.ERROR_BRAKE_VOLTAGE = 0x79
eErrorCode.ERROR_LIFE_SIGN = 0x7a
eErrorCode.ERROR_CUSTOM_DEFINED = 0x7b
eErrorCode.ERROR_REBOOT = 0x7c
eErrorCode.ERROR_MOTOR_PHASE = 0x7d
eErrorCode.UNKNOWN_ERROR_7E = 0x7e
eErrorCode.UNKNOWN_ERROR_7F = 0x7f
eErrorCode.ERROR_POWER_TEMP = 0x80
eErrorCode.ERROR_BRAKE_RESISTOR_TEMP = 0x81
eErrorCode.ERROR_OVERSHOOT = 0x82
eErrorCode.ERROR_HARDWARE_VERSION = 0x83
eErrorCode.ERROR_SOFTWARE_VERSION = 0x84
eErrorCode.ERROR_ANYBUS_EXCEPTION = 0x85
eErrorCode.UNKNOWN_ERROR_86 = 0x86
eErrorCode.UNKNOWN_ERROR_87 = 0x87
eErrorCode.UNKNOWN_ERROR_88 = 0x88
eErrorCode.UNKNOWN_ERROR_89 = 0x89
eErrorCode.UNKNOWN_ERROR_8A = 0x8a
eErrorCode.UNKNOWN_ERROR_8B = 0x8b
eErrorCode.UNKNOWN_ERROR_8C = 0x8c
eErrorCode.UNKNOWN_ERROR_8D = 0x8d
eErrorCode.UNKNOWN_ERROR_8E = 0x8e
eErrorCode.UNKNOWN_ERROR_8F = 0x8f
eErrorCode.UNKNOWN_ERROR_90 = 0x90
eErrorCode.UNKNOWN_ERROR_91 = 0x91
eErrorCode.UNKNOWN_ERROR_92 = 0x92
eErrorCode.UNKNOWN_ERROR_93 = 0x93
eErrorCode.UNKNOWN_ERROR_94 = 0x94
eErrorCode.UNKNOWN_ERROR_95 = 0x95
eErrorCode.UNKNOWN_ERROR_96 = 0x96
eErrorCode.UNKNOWN_ERROR_97 = 0x97
eErrorCode.UNKNOWN_ERROR_98 = 0x98
eErrorCode.UNKNOWN_ERROR_99 = 0x99
eErrorCode.UNKNOWN_ERROR_9A = 0x9a
eErrorCode.UNKNOWN_ERROR_9B = 0x9b
eErrorCode.UNKNOWN_ERROR_9C = 0x9c
eErrorCode.UNKNOWN_ERROR_9D = 0x9d
eErrorCode.UNKNOWN_ERROR_9E = 0x9e
eErrorCode.UNKNOWN_ERROR_9F = 0x9f
eErrorCode.UNKNOWN_ERROR_A0 = 0xa0
eErrorCode.UNKNOWN_ERROR_A1 = 0xa1
eErrorCode.UNKNOWN_ERROR_A2 = 0xa2
eErrorCode.UNKNOWN_ERROR_A3 = 0xa3
eErrorCode.UNKNOWN_ERROR_A4 = 0xa4
eErrorCode.UNKNOWN_ERROR_A5 = 0xa5
eErrorCode.UNKNOWN_ERROR_A6 = 0xa6
eErrorCode.UNKNOWN_ERROR_A7 = 0xa7
eErrorCode.UNKNOWN_ERROR_A8 = 0xa8
eErrorCode.UNKNOWN_ERROR_A9 = 0xa9
eErrorCode.UNKNOWN_ERROR_AA = 0xaa
eErrorCode.UNKNOWN_ERROR_AB = 0xab
eErrorCode.UNKNOWN_ERROR_AC = 0xac
eErrorCode.UNKNOWN_ERROR_AD = 0xad
eErrorCode.UNKNOWN_ERROR_AE = 0xae
eErrorCode.UNKNOWN_ERROR_AF = 0xaf
eErrorCode.ERROR_PROGRAM_ABORTION = 0xb0
eErrorCode.ERROR_PROGRAM_RUNTIME = 0xb1
eErrorCode.ERROR_PROGRAM_INVALID = 0xb2
eErrorCode.ERROR_PROGRAM_CONFLICT = 0xb3
eErrorCode.UNKNOWN_ERROR_B4 = 0xb4
eErrorCode.UNKNOWN_ERROR_B5 = 0xb5
eErrorCode.UNKNOWN_ERROR_B6 = 0xb6
eErrorCode.UNKNOWN_ERROR_B7 = 0xb7
eErrorCode.UNKNOWN_ERROR_B8 = 0xb8
eErrorCode.UNKNOWN_ERROR_B9 = 0xb9
eErrorCode.UNKNOWN_ERROR_BA = 0xba
eErrorCode.UNKNOWN_ERROR_BB = 0xbb
eErrorCode.UNKNOWN_ERROR_BC = 0xbc
eErrorCode.UNKNOWN_ERROR_BD = 0xbd
eErrorCode.UNKNOWN_ERROR_BE = 0xbe
eErrorCode.UNKNOWN_ERROR_BF = 0xbf
eErrorCode.UNKNOWN_ERROR_C0 = 0xc0
eErrorCode.UNKNOWN_ERROR_C1 = 0xc1
eErrorCode.UNKNOWN_ERROR_C2 = 0xc2
eErrorCode.UNKNOWN_ERROR_C3 = 0xc3
eErrorCode.UNKNOWN_ERROR_C4 = 0xc4
eErrorCode.UNKNOWN_ERROR_C5 = 0xc5
eErrorCode.UNKNOWN_ERROR_C6 = 0xc6
eErrorCode.UNKNOWN_ERROR_C7 = 0xc7
eErrorCode.ERROR_WRONG_RAMP_TYPE = 0xc8
eErrorCode.UNKNOWN_ERROR_C9 = 0xc9
eErrorCode.UNKNOWN_ERROR_CA = 0xca
eErrorCode.UNKNOWN_ERROR_CB = 0xcb
eErrorCode.UNKNOWN_ERROR_CC = 0xcc
eErrorCode.UNKNOWN_ERROR_CD = 0xcd
eErrorCode.UNKNOWN_ERROR_CE = 0xce
eErrorCode.UNKNOWN_ERROR_CF = 0xcf
eErrorCode.UNKNOWN_ERROR_D0 = 0xd0
eErrorCode.ERROR_WRONG_DIRECTION = 0xd1
eErrorCode.ERROR_CONFIG_MEMORY = 0xd2
eErrorCode.ERROR_PROGRAM_MEMORY = 0xd3
eErrorCode.ERROR_INVALID_PHRASE = 0xd4
eErrorCode.ERROR_SOFT_LOW = 0xd5
eErrorCode.ERROR_SOFT_HIGH = 0xd6
eErrorCode.ERROR_PRESSURE = 0xd7
eErrorCode.ERROR_SERVICE = 0xd8
eErrorCode.ERROR_FAST_STOP = 0xd9
eErrorCode.ERROR_TOW = 0xda
eErrorCode.ERROR_VPC3 = 0xdb
eErrorCode.ERROR_FRAGMENTATION = 0xdc
eErrorCode.ERROR_COMMUTATION = 0xdd
eErrorCode.ERROR_CURRENT = 0xde
eErrorCode.ERROR_I2T = 0xdf
eErrorCode.ERROR_INITIALIZE = 0xe0
eErrorCode.ERROR_INTERNAL = 0xe1
eErrorCode.ERROR_HARD_LOW = 0xe2
eErrorCode.ERROR_HARD_HIGH = 0xe3
eErrorCode.ERROR_TOO_FAST = 0xe4
eErrorCode.ERROR_POS_SYSTEM = 0xe5
eErrorCode.ERROR_ANALOG_INPUT = 0xe6
eErrorCode.ERROR_FLASH_MEMORY = 0xe7
eErrorCode.ERROR_LIMITER_ACTIVE = 0xe8
eErrorCode.ERROR_STOP_CMD_TIMEOUT = 0xe9
eErrorCode.ERROR_UNEXPECTED_STOP_DURING_PHRASE = 0xea
eErrorCode.ERROR_RESOLVER_CHECK_FAILED = 0xeb
eErrorCode.ERROR_MATH = 0xec
eErrorCode.ERROR_LEAVE_MASTER = 0xed
eErrorCode.ERROR_CALIB_CURRENT = 0xee
eErrorCode.UNKNOWN_ERROR_EF = 0xef
eErrorCode.UNKNOWN_ERROR_F0 = 0xf0
eErrorCode.UNKNOWN_ERROR_F1 = 0xf1
eErrorCode.UNKNOWN_ERROR_F2 = 0xf2
eErrorCode.UNKNOWN_ERROR_F3 = 0xf3
eErrorCode.UNKNOWN_ERROR_F4 = 0xf4
eErrorCode.UNKNOWN_ERROR_F5 = 0xf5
eErrorCode.UNKNOWN_ERROR_F6 = 0xf6
eErrorCode.UNKNOWN_ERROR_F7 = 0xf7
eErrorCode.UNKNOWN_ERROR_F8 = 0xf8
eErrorCode.UNKNOWN_ERROR_F9 = 0xf9
eErrorCode.UNKNOWN_ERROR_FA = 0xfa
eErrorCode.UNKNOWN_ERROR_FB = 0xfb
eErrorCode.UNKNOWN_ERROR_FC = 0xfc
eErrorCode.UNKNOWN_ERROR_FD = 0xfd
eErrorCode.UNKNOWN_ERROR_FE = 0xfe
eErrorCode.UNKNOWN_ERROR_FF = 0xff
##
#  @} # end of group smp_error_codes_group


eStateMask = pyschunk.tools.util.enum()
eStateMask.REFERENCED   = 0x01
eStateMask.MOVING       = 0x02
eStateMask.PHRASE_MODE  = 0x04
eStateMask.WARNING      = 0x08
eStateMask.QUIT         = 0x10
eStateMask.BRAKE        = 0x20
eStateMask.MOVE_BLOCKED = 0x40
eStateMask.POS_REACHED  = 0x80

# settings according to enum eDataType in DataStructures.h
eDataType = pyschunk.tools.util.enum()
eDataType.DT_UNKNOWN = 0x00
eDataType.DT_UINT8   = 0x01
eDataType.DT_INT8    = 0x02
eDataType.DT_UINT16  = 0x03
eDataType.DT_INT16   = 0x04
eDataType.DT_UINT32  = 0x05
eDataType.DT_INT32   = 0x06
eDataType.DT_UINT64  = 0x07
eDataType.DT_INT64   = 0x08
eDataType.DT_FLOAT   = 0x09
eDataType.DT_DOUBLE  = 0x0a
eDataType.DT_STRING  = 0x0b
eDataType.DT_BOOL    = 0x0c
eDataType.DT_BINARY  = 0x0d
eDataType.DT_ENUM    = 0x0e
eDataType.MAX_DATA_TYPE = 0x0f

## \defgroup smp_hw_test_codes_group test codes extracted from TestCodes.h:
#   For now this is done manually here for selected test codes only
#  @{
eHWTestCode = pyschunk.tools.util.enum()
eHWTestCode.TEST_SPI_FLASH_FREQUENCY = 0x1001
eHWTestCode.TEST_CAN_COUNTER         = 0x00E7
eHWTestCode.TEST_READ_TI_MEMORY      = 0x00fc
##
#  @} # end of group smp_hw_test_codes_group
