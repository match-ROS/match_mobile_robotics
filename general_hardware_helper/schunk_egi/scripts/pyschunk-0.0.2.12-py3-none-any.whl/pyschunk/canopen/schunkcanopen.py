'''
Created on 27.10.2011

@author: Osswald2
'''

import re
import ntcan
import pyschunk.smpcom
import pyschunk.tools.util

from . import esdutil

from pyschunk.canopen.esdcanopen import dbg

SWITCH_TO_SMP_NODE_NO = 123

def DisconnectNode( sdo, node_no, do_ack=False ):
    exc = None
    try:
        if ( do_ack ):
            sdo.write1Byte (node_no,0x200a,0x00,0x05)  # node,index,subindex,data)
        else:
            sdo.write1Byte (node_no,0x200a,0x00,0x01)  # node,index,subindex,data)
    except IOError as e:
        # A timeout exception is the expected behaviour
        exc = e   # see https://stackoverflow.com/questions/24271752/except-clause-deletes-local-variable
        exc.__traceback__ = None
    if ( exc is None ):
        raise IOError( "Expected timeout NOT caught!" )

def RebootNode( sdo, node_no ):
    exc = None
    try:
        sdo.write1Byte (node_no,0x200a,0x00,0x02)  # node,index,subindex,data)
    except IOError as e:
        # A timeout exception is the expected behaviour
        exc = e   # see https://stackoverflow.com/questions/24271752/except-clause-deletes-local-variable
        exc.__traceback__ = None
    if ( exc is None ):
        raise IOError( "Expected timeout NOT caught!" )

def ChangeUser( sdo, node_no, password ):
    try:
        sdo.write(node_no,0x2008,0x00, password )  # node,index,subindex,strdat,data=0,result=True):
    except IOError:
        # invalid password is indicated by a 'SDO transfer aborted. error: 0x08000000 general error'
        # => ignore it
        pass

def GetUser( sdo, node_no ):
    '''Return the user id from cob 0x2009/0
    '''
    result, user = sdo.read (node_no, 0x2009, 0)
    if result != True:
        raise IOError("Could not read user object 0x2009/0!")
    return user

class tCANopenStream( object ):
    """class to read debug messages from a SCHUNK CANopen node (PDO4)
    """

    def __init__( self, node, options ):
        """
        """
        self._cif = None
        self._id_read = node + 0x480  # read from OV?
        try:
            self._id_read = options.can_id
        except AttributeError:
            pass
        self._net = options.net
        # Open CAN Interface
        # ---> cif = ntcan.CIF( net, RxQueueSize, RxTimeOut, TxTimeOut, TxQueueSize, Flags)
        self._RxQS=2000                       # RxQueueSize [0, 10000]
        self._TxQS=1                          # TxQueueSize [0, 10000]
        self._RxTO=0                          # RxTimeOut in Millseconds, 0=wait forever
        self._TxTO=1000                       # TxTimeOut in Millseconds
        #cifFlags=                            # Flags
        #CIF( net, rx_queuesize, rx_timeout, tx_timeout, tx_queuesize, ? )
        self._cif = ntcan.CIF( self._net, self._RxQS, self._RxTO, self._TxTO, self._TxQS )

        baudrate_codes = dict( [(1000000,0x0),  # see ESD API documentation page 51
                                (800000, 0xE),
                                (666600, 0x1),
                                (500000, 0x2),
                                (333300, 0x3),
                                (250000, 0x4),
                                (166000, 0x5),
                                (125000, 0x6),
                                (100000, 0x7),
                                (83300, 0x10),
                                (66600, 0x8),
                                (50000, 0x9),
                                (33300, 0xA),
                                (20000, 0xB),
                                (12500, 0xC),
                                (10000, 0xD) ] )
        self._cif.baudrate = baudrate_codes[ options.baudrate ]
        self._cif.canIdAdd( self._id_read )
        t = self._cif.timestamp  # required for CAN-USB/2, see ntcan.CIF.canIdAdd() @UnusedVariable
        self._rcmsg = ntcan.CMSG()
        self._buffer  = ""

    def close( self ):
        ''' close the CAN communication object
        '''
        try:
            self._cif.canIdDelete( self._id_read )
        except IOError:
            pass # ignoring IOError on close
        finally:
            del self._cif
            del self._rcmsg
            del self._buffer

    def readline( self, eol='\n' ):
        '''read a complete line (terminated by the \a eol character sequence) from CAN and return it as string.
        '''
        while True:
            self._rcmsg.canRead( self._cif )
            for c in self._rcmsg.data.c[0:self._rcmsg.len]:
                self._buffer += chr(c)
            if ( eol in self._buffer ):  # TODO: searching eos over and over again might be inefficient
                l = self._buffer.split( eol, 1 )
                self._buffer = l[1]
                return l[0] + eol

def GetModuleInfo( sdo, node_no ):
    '''Read the CANopen module info via SDOs from OV 0x1018, 0x1008-0x100a
    \return a structure with the following elements:
    - vendor_id
    - product_code
    - revision_number
    - serial_number
    - manufacturer_software_version
    - manufacturer_software_version_no
    - manufacturer_software_version_build
    - manufacturer_software_version_date
    - manufacturer_software_version_time
    '''
    s = pyschunk.tools.util.Struct()

    # 1018 RECORD Identity Object Identity (23h) ro M
    result, data = sdo.read (node_no, 0x1018, 0)        #@UnusedVariable
    if result != True:
        raise IOError("Could not read identity object 0x1018!")

    result, s.vendor_id       = sdo.read (node_no, 0x1018, 1)
    result, s.product_code    = sdo.read (node_no, 0x1018, 2)
    result, s.revision_number = sdo.read (node_no, 0x1018, 3)
    result, s.serial_number   = sdo.read (node_no, 0x1018, 4)

    result, s.manufacturer_device_name = sdo.read_visible_string( node_no, 0x1008, 0 )
    if ( not result ):
        raise IOError("Could not read Manufacturer hardware version object 0x1008!")

    result, s.manufacturer_hardware_version = sdo.read_visible_string( node_no, 0x1009, 0 )
    if ( not result ):
        raise IOError("Could not read Manufacturer hardware version object 0x1009!")

    result, s.manufacturer_software_version = sdo.read_visible_string (node_no, 0x100a, 0)
    if result != True:
        raise IOError("Could not read Manufacturer software version object 0x100a!")

    #54 Build:1065 Date:2011-11-11 14:35:32
    mo = re.match( "(\d+)( Build:(\d+) Date:([0-9-]+) ([0-9:]+))?", s.manufacturer_software_version )
    if ( mo is None ):
        raise IOError("Could not decode manufacturer_software_version from %r" % s.manufacturer_software_version )
    s.manufacturer_software_version_no = int(mo.group(1))
    if ( mo.group(3) is str ):
        s.manufacturer_software_version_build = int(mo.group(3))
        s.manufacturer_software_version_date = mo.group(4)
        s.manufacturer_software_version_time = mo.group(5)
    else:
        s.manufacturer_software_version_build = 9999 # dummy build number to get over "old-firmware-test" in COT_ResetToSMP
        s.manufacturer_software_version_date = ""
        s.manufacturer_software_version_time = ""

    dbg.var( "s" )

    return s


def ValueToKey( dd, vv ):
    '''http://stackoverflow.com/questions/2568673/inverse-dictionary-lookup-python
    \return the key of value \a vv in dict \a dd
    - raises ValueError if \a vv is not a value in \a dd
    - returns an arbitrary key if multiple keys have value \a vv
    '''
    try:
        key = (key for key,value in dd.items() if value==vv).next()
    except StopIteration:
        raise ValueError( "Value %r is not in dict" % (vv) )
    return key


def ExplainManufacturerStatus( ms ):
    '''Return a string explaining the 0x1002/0 manufacturer_status
    '''
    error_code = ms & 0x00ff
    command_code = (ms>>8) & 0x00ff
    try:
        ecs = pyschunk.smpcom.eErrorCode.GetName( error_code )
    except ValueError:
        ecs = "?"
    try:
        ccs = pyschunk.smpcom.eCmdCode.GetName( command_code )
    except ValueError:
        ccs = "?"
    return "SMP command code = %s, SMP error code = %s" % (ccs,ecs)


def ExplainPredefinedErrorField( pef ) :
    '''Return a string explaining the 0x1003/i predefined_error_field
    '''
    error_code_cop = pef & 0x0000ffff
    error_code_smp = (pef>>16) & 0x000000ff
    # bits 31..24 of pef contain lowest byte of smp error details (1/4 of a float...)

    eccs = esdutil.ExplainErrorCode( error_code_cop )
    try:
        ecss = pyschunk.smpcom.eErrorCode.GetName( error_code_smp )
    except ValueError:
        ecss = "?"
    return "CANopen error code = %s, SMP error code=%s" % (eccs,ecss)

def ExplainSMPErrorCode( ec ) :
    '''Return a string explaining the 0x200f/(1..20) smp error code
    '''
    try:
        return pyschunk.smpcom.eErrorCode.GetName( ec )
    except ValueError:
        return "?"
