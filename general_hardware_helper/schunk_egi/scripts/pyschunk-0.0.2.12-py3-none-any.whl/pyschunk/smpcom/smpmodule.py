'''
Created on 02.04.2012

@author: osswald2
'''

#switch off debug messages from factory:
from pyschunk.smpcom                import smp_types
from pyschunk.smpcom                import smptools
from pyschunk.smpcom.smp_message_id import cSMPMessageID
from pyschunk.smpcom                import smp_interfaces
from pyschunk.smpcom.smp_message    import cSMPMessage
from pyschunk.smpcom.smp_codes      import eCmdCode
from pyschunk.smpcom.smp_codes      import eParamList
from pyschunk.smpcom.smp_codes      import eDataType

from pyschunk.tools.dbg import tDBG
import re
import pyschunk.tools.util
#import copy #needed for ESD CAN-USB-mini, but not sufficient to make that work (bug 2305)

class tr(str):
    '''Class for very simple internationalization

    Usage example:
    \code
        from pyschunk.smpmodule import tr
        tr.language = tr.english   # or tr.german
        ...
        def f():
            print( tr( "Etwas deutscher Text", "Some english text" ) )

    \endcode
    '''
    german   = 1
    english  = 2
    language = 2
    def __new__(cls,g,e):
        if ( tr.language == tr.german ):
            return str.__new__(cls,g)
        return str.__new__(cls,e)


def JaNein( v ):
    if ( v ):
        return tr( "Ja", "Yes" )
    return tr( "Nein", "No" )


class cSMPModule( object ):
    def __init__( self, options, module_id=1, timeout=1.0 ):
        '''Prepare some standard default settings:

        - self.module_id - a SMP module id initialized from \a module_id
          used to create self.request_id, self.response_id and self.error_response_id
        - self.request_id - a SMP message id used for requests (messages from PC to module)
        - self.response_id - a SMP message id used for responses (messages from module to PC)
        - self.error_response_id - a SMP message id used for error responses (messages from module to PC)
        - self.iface - the opened interface object to communicate with the module according to self.GetOptions()
        - self.timeout - the timeout for receiving answers from a module, initialized from \a timeout
        '''
        self.dbg = tDBG( options.debug_level > 0, "green", description="pyschunk.smpcom.smpmodule.cSMPModule module_id=%d" % module_id )

        # set some options for all tests here:
        self.module_id = module_id
        self.is_canopen = False


        # set up default request and response IDs
        self.request_id  = cSMPMessageID()
        self.request_id.module_id     = self.module_id
        self.request_id.is_module_id  = True
        self.request_id.from_module   = False
        self.request_id.is_normal     = True

        self.response_id = cSMPMessageID()
        self.response_id.module_id    = self.module_id
        self.response_id.is_module_id = True
        self.response_id.from_module  = True
        self.response_id.is_normal    = True

        self.error_response_id = self.response_id.Clone()
        self.error_response_id.module_id = self.module_id
        self.error_response_id.is_normal = False

        self.last_get_state_response = None

        options.timeout = timeout

        # create and open interface to use for communication with module
        options.debug_level -= 1
        self.iface = smp_interfaces.interfaces.Create( options )
        self.iface.Open()
        self.timeout = timeout

        # By default the iface will receives all CAN-IDs. But since this cSMPModule instance
        # connects to one specific SMP module only get rid of all the unwanted IDs
        # ANOTE: This deleting takes ca. 0.010s
        #import time
        #t0=time.time()
        try:
            # this will work when using esdcan only
            raw_response_id       = (self.response_id.GetByte(0) << 8) | self.response_id.GetByte(1)
            raw_error_response_id = (self.error_response_id.GetByte(0) << 8) | self.error_response_id.GetByte(1)
            #ids_added = copy.copy( self.iface.ids_added ) #needed for ESD CAN-USB-mini, but not sufficient to make that work (bug 2305)
            #for can_id in ids_added:                      #needed for ESD CAN-USB-mini, but not sufficient to make that work (bug 2305)
            for can_id in range( 1<<11 ):
                if ( can_id in (raw_response_id, raw_error_response_id) ):
                    continue
                try:
                    self.iface.cif.canIdDelete( can_id )
                    #self.iface.ids_added.discard( can_id ) #needed for ESD CAN-USB-mini, but not sufficient to make that work (bug 2305)
                except ValueError:
                    pass # ignore ValueError: The CAN identifier is not enabled
        finally:
            pass
        #t1=time.time()
        #print( "deleting ids took %fs" % (t1-t0) )

    def ReceiveExpected(self, expected, tries=5, caller="" ):
        '''Try to recieve the \a expected message up to \a tries times
        Ignore other received messages, e.g. impulse message, GET_STATE...
        If more than \a tries other non matching messages are received then an IOError is raised
        \return the response
        '''
        #print( "\nexpecting %s" % str(expected) )
        matches = None
        mismatch_msg = None
        ignored_exception = None
        ignored_exceptions = []
        while ( tries > 0 ):
            response = expected.Clone()
            try:
                response = self.iface.Receive( response )
                #print( "received %s" % str(response) )
                matches,mismatch_msg = expected.MatchedBy( response )
                if (matches):
                    return response
            except UnicodeEncodeError as e:
                pass
                raise # reraise
            except ValueError as e:
                self.dbg << "Ignoring exception %r\n" % e
                ignored_exception = e
                ignored_exception.__traceback__ = None  # see https://stackoverflow.com/questions/24271752/except-clause-deletes-local-variable
                ignored_exceptions.append( ignored_exception )
            tries -= 1
        self.dbg << "%s(): invalid response! matches=%r mismatch_msg=%s)\n" % (caller, matches,mismatch_msg)
        raise IOError( "Could not receive expected response for %s, received %r instead. Mismatch due to %r (ignored exceptions=%r)" % (caller,response,mismatch_msg, ignored_exceptions) )

    def Close(self):
        self.iface.Close()

    def CmdAck(self):
        '''Send CMD_ACK to module.
        Warning: the response is not read, so if you want to read other
        responses later on you must read or discard the CMD_ACK response first!
        '''
        request = cSMPMessage( self.request_id, eCmdCode.CMD_ACK )
        self.iface.Send( request )

    def MovePos(self, position):
        '''Send CMD_ACK and MOVE_POS to module.
        Warning: the responses are not read, so if you want to read other
        responses later on you must read or discard the CMD_ACK and MOVE_POS responses first!
        '''
        self.CmdAck() # TODO: is automatic acknowledge the right thing??? Check!
        request = cSMPMessage( self.request_id, eCmdCode.MOVE_POS, smp_types.cInt32( position ) )
        self.iface.Send( request )

    def MoveSpeed(self, speed):
        '''Send CMD_ACK and MOVE_POS to module.
        Warning: the responses are not read, so if you want to read other
        responses later on you must read or discard the CMD_ACK and MOVE_POS responses first!
        '''
        self.CmdAck()  # TODO: is automatic acknowledge the right thing??? Check!
        request = cSMPMessage( self.request_id, eCmdCode.MOVE_VEL, smp_types.cInt32( speed=speed ) )
        self.iface.Send( request )

    def Stop(self):
        '''Send CMD_STOP to module.
        Warning: the response is not read, so if you want to read other
        responses later on you must read or discard the CMD_STOP response first!
        '''
        request = cSMPMessage( self.request_id, eCmdCode.CMD_STOP )
        self.iface.Send( request )

    def FastStop(self):
        '''Send CMD_FAST_STOP to module.
        Warning: the response is not read, so if you want to read other
        responses later on you must read or discard the CMD_FAST_STOP response first!
        '''
        request = cSMPMessage( self.request_id, eCmdCode.CMD_FAST_STOP )
        self.iface.Send( request )

    def SetSoftLowTmp( self, soft_low_tmp ):
        '''Set soft limit low temporarily.
        Warning: the response is not read, so if you want to read other
        responses later on you must read or discard the response first!

        PROFI right required
        '''
        request = cSMPMessage( self.request_id,
                                      eCmdCode.SET_CONFIG,
                                      smp_types.cUInt8( eParamList.PARAM_SOFT_LOW_TMP ),
                                      smp_types.cInt32( soft_low_tmp=soft_low_tmp ) )
        self.iface.Send( request )

    def SetSoftHighTmp( self, soft_high_tmp ):
        '''Set soft limit high temporarily.
        Warning: the response is not read, so if you want to read other
        responses later on you must read or discard the response first!

        PROFI right required
        '''
        request = cSMPMessage( self.request_id,
                                      eCmdCode.SET_CONFIG,
                                      smp_types.cUInt8( eParamList.PARAM_SOFT_HIGH_TMP ),
                                      smp_types.cInt32( soft_low_tmp=soft_high_tmp ) )
        self.iface.Send( request )

    def SetTargetCurrent( self, target_current ):
        '''Set target current.
        Warning: the response is not read, so if you want to read other
        responses later on you must read or discard the response first!
        '''
        request = cSMPMessage( self.request_id,
                                      eCmdCode.SET_TARGET_CUR,
                                      smp_types.cInt32( target_current=target_current ) )
        self.iface.Send( request )


    def SetTargetAcceleration( self, target_acceleration ):
        '''Set target acceleration.
        Warning: the response is not read, so if you want to read other
        responses later on you must read or discard the response first!
        '''
        request = cSMPMessage( self.request_id,
                                      eCmdCode.SET_TARGET_ACC,
                                      smp_types.cInt32( target_acceleration=target_acceleration) )
        self.iface.Send( request )


    def SetTargetVelocity( self, target_velocity ):
        '''Set target velocity.
        Warning: the response is not read, so if you want to read other
        responses later on you must read or discard the response first!
        '''
        request = cSMPMessage( self.request_id,
                                      eCmdCode.SET_TARGET_VEL,
                                      smp_types.cInt32( target_velocity=target_velocity ) )
        self.iface.Send( request )

    def SetTargetPosition( self, target_position ):
        '''Set target position.
        Warning: the response is not read, so if you want to read other
        responses later on you must read or discard the response first!
        '''
        request = cSMPMessage( self.request_id,
                                      eCmdCode.SET_TARGET_POS,
                                      smp_types.cInt32( target_position=target_position ) )
        self.iface.Send( request )

    def CheckMcPcCommunication( self ):
        request = cSMPMessage( self.request_id,
                                eCmdCode.CHECK_MC_PC_COMMUNICATION)
        self.iface.Send( request )
        expected = cSMPMessage( self.response_id,
                                eCmdCode.CHECK_MC_PC_COMMUNICATION,
                                smp_types.cFloat( -1.2345),
                                smp_types.cFloat( 47.11),
                                smp_types.cInt32( 287454020),
                                smp_types.cInt32( -1122868),
                                smp_types.cInt16( 512),
                                smp_types.cInt16( -20482))
        self.ReceiveExpected( expected, 5, "CheckMcPcCommunication" )

    def GetPosSystemOffset(self):
        '''Not implemented for SMP
        '''
        # TODO: implement this
        return -1.0

    def GetReferenceOffset(self):
        request = cSMPMessage( self.request_id, eCmdCode.GET_CONFIG, eParamList.PARAM_OFFSET_REFERENCE )
        self.iface.FlushInput()

        expected = cSMPMessage( self.response_id,
                                eCmdCode.GET_CONFIG,
                                eParamList.PARAM_OFFSET_REFERENCE,
                                smp_types.cInt32( reference_offset=smp_types.ANY ) )
        self.dbg << "Sending GetReferenceOffset request %s\n" % str(request)
        self.iface.Send( request )
        try:
            response = self.ReceiveExpected( expected, 5, "GetReferenceOffset classic" )

        except IOError as e :
            self.dbg << "ignoring classic %r" % e
            #--- Felix' new LWA5 CANopen modules do it like this:
            request  = cSMPMessage( self.request_id,
                                    eCmdCode.GET_CONFIG_EXT,
                                    smp_types.cUInt16( configuration_code=0x7D48 ) )
            expected = cSMPMessage( self.response_id,
                                    eCmdCode.GET_CONFIG_EXT,
                                    smp_types.cUInt16( configuration_code=0x7D48 ),
                                    smp_types.cUInt8( data_type=eDataType.DT_FLOAT ),
                                    smp_types.cFloat( reference_offset=smp_types.ANY ) )

            self.iface.Send( request )

            response = self.ReceiveExpected( expected, 5, "GetReferenceOffset LWA5" )

        self.dbg << "GetReferenceOffset response = %r" % response
        return response.reference_offset


    def GetNomCurrent(self):
        request = cSMPMessage( self.request_id, eCmdCode.GET_CONFIG, eParamList.PARAM_NOM_CURRENT )
        self.iface.FlushInput()
        self.iface.Send( request )

        expected = cSMPMessage( self.response_id,
                                eCmdCode.GET_CONFIG,
                                eParamList.PARAM_NOM_CURRENT,
                                smp_types.cInt32( nominal_current=smp_types.ANY ) )

        try:
            response = self.ReceiveExpected( expected, 5, "GetNomCurrent classic" )

        except IOError as e :
            self.dbg << "ignoring classic %r" % e
            #--- Felix' new LWA5 CANopen modules do it like this:
            request  = cSMPMessage( self.request_id,
                                    eCmdCode.GET_CONFIG_EXT,
                                    smp_types.cUInt16( configuration_code=0x7D23 ) )
            expected = cSMPMessage( self.response_id,
                                    eCmdCode.GET_CONFIG_EXT,
                                    smp_types.cUInt16( configuration_code=0x7D23 ),
                                    smp_types.cUInt8( data_type=eDataType.DT_UINT16 ),
                                    smp_types.cUInt16( nominal_current=smp_types.ANY ) )

            self.iface.Send( request )

            response = self.ReceiveExpected( expected, 5, "GetNomCurrent LWA5" )

        self.dbg << "GetNomCurrent response = %r" % response
        return response.nominal_current

    def GetPos(self, retries=3):
        request = cSMPMessage( self.request_id, eCmdCode.GET_STATE, smp_types.cUInt32( period=0 ), 1 )
        while (retries>0):
            try:
                self.iface.FlushInput()
                self.iface.Send( request )

                expected = cSMPMessage( self.response_id,
                                               eCmdCode.GET_STATE,
                                               smp_types.cInt32( pos=smp_types.ANY ),
                                               smp_types.cUInt8( state=smp_types.ANY ),
                                               smp_types.cUInt8( error=smp_types.ANY ) )
                response = self.ReceiveExpected( expected, 5, "GetPos"  )
                self.dbg << "GetPos response = %r" % response
                self.last_get_state_response = response
                return response.pos
            except (ValueError,IOError):
                retries -= 1
                if retries == 0:
                    raise # reraise


    def SendGetState( self, period=250, pos=True, vel=False, cur=False, off=False ):
        '''Send a eCmdCode.GET_STATE request, but do not receive any responses
        \param period - the period of the automatic sending of the module. We assume an integer unit system here and expect ms
        \param pos - Flag, if True then position is requested
        \param vel - Flag, if True then velocity is requested
        \param cur - Flag, if True then current is requested
        \param off - Flag, if True then the automatic sending of the module is turned off
        '''
        if ( off ):
            request = cSMPMessage( self.request_id, eCmdCode.GET_STATE )
            self.iface.Send( request )
            return

        mode = 0
        if ( pos ):
            mode |= 1
        if ( vel ):
            mode |= 2
        if ( cur ):
            mode |= 4

        request = cSMPMessage( self.request_id,
                                      eCmdCode.GET_STATE,
                                      smp_types.cUInt32( period=period ),
                                      smp_types.cUInt8( mode=mode ) )
        self.iface.Send( request )


    def ReceiveGetState( self, pos=True, vel=False, cur=False, retries=3 ):
        '''Try to receive a eCmdCode.GET_STATE response up to \a retries times.
        \param pos - Flag, if True then position is expected in the response
        \param vel - Flag, if True then velocity is expected in the response
        \param cur - Flag, if True then current is expected in the response
        \param retries - Number of retries

        \return The response as a cSMPMessage. The requested data is
                available in named parameters pos, vel, cur, state, error
        '''
        response = cSMPMessage( self.response_id,
                                       eCmdCode.GET_STATE )
        if ( pos ):
            response.Add( smp_types.cInt32( pos=smp_types.ANY ) )
        if ( vel ):
            response.Add( smp_types.cInt32( vel=smp_types.ANY ) )
        if ( cur ):
            response.Add( smp_types.cUInt32( cur=smp_types.ANY ) )

        response.Add( smp_types.cUInt8( state=smp_types.ANY ) )
        response.Add( smp_types.cUInt8( error=smp_types.ANY ) )

        while (retries>0):
            try:
                response = self.iface.Receive( response )
                self.dbg << "GetPos response = %r" % response
                self.last_get_state_response = response
                return response
            except (ValueError,IOError):
                retries -= 1
                if retries == 0:
                    raise # reraise

    def SetReferenceOffset( self, reference_offset ):
        '''Set reference offset.
        Warning: the response is not read, so if you want to read other
        responses later on you must read or discard the response first!

        PROFI right required
        '''
        request = cSMPMessage( self.request_id,
                               eCmdCode.SET_CONFIG_EXT,
                               smp_types.cUInt16( eParamList.PARAM_OFFSET_REFERENCE ),
                               eDataType.DT_INT32,
                               smp_types.cInt32( reference_offset=reference_offset ) )
        self.iface.Send( request )
        #TODO: check response

    def Reference( self ):
        '''Send CMD_ACK and CMD_Reference.
        Warning: the responses are not read, so if you want to read other
        responses later on you must read or discard the responses first!
        '''
        self.CmdAck()
        request = cSMPMessage( self.request_id, eCmdCode.CMD_REFERENCE )
        self.iface.Send( request )
        #TODO: check response

    def SetCommMode( self, comm_mode ):
        #--- classic CANopen modules do it like this:
        request  = cSMPMessage( self.request_id,
                                eCmdCode.SET_CONFIG,
                                smp_types.cUInt8( eParamList.PARAM_COMMINTERFACE_MAIN ),
                                smp_types.cUInt8( comm_mode=comm_mode ),
                                smp_types.cUInt8( dummy=0 ) ) # firmare up to and including 0.62 fails without this dummy
        expected = cSMPMessage( self.response_id,
                                eCmdCode.SET_CONFIG,
                                smp_types.ok,
                                smp_types.cUInt8( eParamList.PARAM_COMMINTERFACE_MAIN ) )
        self.iface.Send( request )
        try:
            self.ReceiveExpected( expected, 10, "SetCommMode classic" )

        except IOError as e :
            self.dbg << "ignoring classic %r" % e
            #--- Felix' new LWA5 CANopen modules do it like this:
            request  = cSMPMessage( self.request_id,
                                    eCmdCode.SET_CONFIG_EXT,
                                    smp_types.cUInt16( configuration_code=0x7D87 ),
                                    smp_types.cUInt8( data_type=eDataType.DT_ENUM ),
                                    smp_types.cUInt8( comm_mode=comm_mode ) )
            expected = cSMPMessage( self.response_id,
                                    eCmdCode.SET_CONFIG_EXT,
                                    smp_types.ok,
                                    smp_types.cUInt16( configuration_code=0x7d87 ) )

            self.iface.Send( request )

            self.ReceiveExpected( expected, 10, "SetCommMode LWA5" )

    def Disconnect( self ):
        '''Send CMD_Disconnect and try some passwords for that.
        Warning: the response is not read, so if you want to read other
        responses later on you must read or discard the response first!
        '''
        for password in [ "44", "Start!" ]:
            request = cSMPMessage( self.request_id,
                                          eCmdCode.CMD_DISCONNECT,
                                          password )
            self.iface.Send( request )
            #TODO: check response

    def Reboot( self ):
        request  = cSMPMessage( self.request_id,
                                eCmdCode.CMD_REBOOT )
        expected = cSMPMessage( self.response_id,
                                eCmdCode.CMD_REBOOT,
                                smp_types.ok )
        self.iface.Send( request )
        self.ReceiveExpected( expected, 10, "Reboot" )

    def GetConfigSectConfig( self ):
        '''Read the eeprom bytes from the module.
        \return the eeprom data structure as a string
        '''
        request = cSMPMessage( self.request_id, eCmdCode.GET_CONFIG, eParamList.SECT_CONFIG )
        self.iface.FlushInput()
        self.iface.Send( request )

        expected = cSMPMessage( self.response_id,
                                       eCmdCode.GET_CONFIG,
                                       eParamList.SECT_CONFIG,
                                       smp_types.cString( eeprom_bytes=smp_types.ANY, size=252 ) )
        response = self.ReceiveExpected( expected, 5, "GetConfigSectConfig" ) #FIXME: migth fail due to mismatch
        self.dbg << "GetConfigSectConfig response = %r" % response
        return response.eeprom_bytes

    def GetConfigInfo(self):
        '''Read the config info
        \return struct in same format as canopen.GetModuleInfo()
        \warning content of struct is slightly differen since in SMP not all info is available
        '''
        request = cSMPMessage( self.request_id, eCmdCode.GET_CONFIG)
        expected = cSMPMessage( self.response_id,
                                eCmdCode.GET_CONFIG,
                                smp_types.cString( modultype=smp_types.ANY, size=8 ),
                                smp_types.cUInt32( reference_number=smp_types.ANY ),
                                smp_types.cUInt16( fw_ver=smp_types.ANY ),
                                smp_types.cUInt16( protocol_ver=smp_types.ANY ),
                                smp_types.cUInt16( hardware_ver=smp_types.ANY ),
                                smp_types.cString( fw_info=smp_types.ANY, size=24))
                                #smp_types.cString( fw_date_time=smp_types.ANY, size=24))
        self.iface.FlushInput()
        self.iface.Send( request )
        response = self.ReceiveExpected( expected, 5, "GetConfigInfo" )
        self.dbg.var( "response response.fw_info" )
        s = pyschunk.tools.util.Struct()
        s.vendor_id       = "?" # unavailable in SMP
        s.revision_number = response.fw_ver
        s.serial_number   = response.reference_number

        s.manufacturer_device_name = response.modultype
        s.manufacturer_hardware_version = response.hardware_ver
        s.manufacturer_software_version_no = response.fw_info
        s.manufacturer_software_version_build = "9999" # unavailable in SMP
        #if ( type( s.manufacturer_software_version ) is int ):
        #    s.manufacturer_software_version = chr( s.manufacturer_software_version & 0xff ) + chr( (s.manufacturer_software_version>>8) & 0xff ) + chr( (s.manufacturer_software_version>>16) & 0xff ) + chr( (s.manufacturer_software_version>>24) & 0xff )

        #CANopen: 54 Build:1065 Date:2011-11-11 14:35:32
        #SMP: 2014-09-09 13:27:37 PTAD
        mo = re.match( "([0-9-]+) ([0-9:]+)\x00(.*)", response.fw_info )
        if ( mo is None ):
            raise IOError("Could not decode manufacturer_software_version from %r" % response.fw_info )
        s.manufacturer_software_version_date = mo.group(1)
        s.manufacturer_software_version_time = mo.group(2)
        s.product_code                       = mo.group(3)
        #65 Build:2765 Date:2014-09-09 13:27:37
        s.manufacturer_software_version = "%s Build:%s Date:%s %s" % (response.fw_ver, s.manufacturer_software_version_build, s.manufacturer_software_version_date, s.manufacturer_software_version_time)

        self.dbg << "GetConfigInfo response=%r" % (response)
        self.dbg.var( "s" )

        # this here reports:
        #vendor_id='?'
        # product_code='PTAD'
        # revision_number=0
        # serial_number=0
        # manufacturer_device_name='????????'
        # manufacturer_hardware_version=611
        # manufacturer_software_version_time='13:27:37',
        # manufacturer_software_version_date='2014-09-09',
        # manufacturer_software_version_build='?'
        # manufacturer_software_version_no='2014-09-09 13:27:37\x00PTAD'
        # manufacturer_software_version=65 Build:9999 Date:2014-09-09 13:27:37

        #COT_GetManufacturerDetails reports:
        #   vendor_id                     = 0x00000332
        #   product_code                  = 1414546497 = 0x54504441 = "TPDA"
        #   revision_number               = 65
        #   serial_number                 = 6560
        #   manufacturer_device_name      = SCHUNK PTAD
        #   manufacturer_hardware_version = 6.11
        #   manufacturer_software_version = 65 Build:2765 Date:2014-09-09 13:27:37
        return s

    def GetTemperature( self, retries_send=2, retries_receive=3 ):
        request  = cSMPMessage( self.request_id,
                                eCmdCode.GET_TEMPERATURE )
        expected = cSMPMessage( self.response_id,
                                eCmdCode.GET_TEMPERATURE,
                                smp_types.cFloat( temperature=smp_types.ANY ) )
        retries_s = retries_send
        while (retries_s>0):
            try:
                self.iface.FlushInput()
                self.iface.Send( request )

                response = self.ReceiveExpected( expected, retries_receive, "GetTemperature" )
                self.dbg << "GetTemperature response = %r" % response
                return response.temperature
            except (ValueError,IOError):
                if retries_s == 1:
                    raise # reraise
            retries_s -= 1
        raise IOError( "Could not receive temperature after %d send tries with %d receive tries" % (retries_send,retries_receive) )

    def ChangeUser(self, password):
        request = cSMPMessage( self.request_id,
                               eCmdCode.CHANGE_USER,
                               password )
        expected = cSMPMessage( self.response_id,
                                eCmdCode.CHANGE_USER,
                                smp_types.ok,
                                smp_types.cUInt8( user=smp_types.ANY ) )
        self.iface.Send( request )
        response = self.ReceiveExpected( expected, 10, "ChangeUser" )
        return response.user

    def AssertUser(self, desired_minimum_user, passwords ):
        '''Change user using passwords from \a passwords until at least user level \a desired_minimum_user is returned
        '''
        user = smptools.eUserType.USER_GUEST #@UndefinedVariable
        for pw in passwords.split(","):
            user = self.ChangeUser(pw)
            if ( user >= desired_minimum_user ):
                return user

        raise smptools.ApplicationError( "Could not change user level to %r with given passwords" % (desired_minimum_user) )

    def IsOK(self):
        '''Dummy for compatibility with cCANopenDrive
        '''
        return True

    def GetState(self):
        '''For for compatibility with cCANopenDrive
        '''
        if ( self.last_get_state_response is None ): # TODO: or if self.last_get_state_response is too old
            self.GetPos()

        result  = tr( "Status: referenziert = ", "State: referenced = " ) + "%-4s" % (JaNein(self.last_get_state_response.state & 0x01) )
        result += tr( " Fehler = ", "Error = " ) + "%-4s" % ( JaNein(self.last_get_state_response.state & 0x10) )
        if ( self.last_get_state_response.state & 0x10 ):
            result += " (0x%02x)" % (self.last_get_state_response.error)
        return result

    def WaitForCommutationSearchCompleted(self):
        print( "WaitForCommutationSearchCompleted() for SMP modules not implemented yet" )
        return

if __name__ == '__main__':
    # for quick testing:
    import sys
    options = pyschunk.tools.util.Struct()
    options.interface = "canesd0"
    options.baudrate = 1000000
    options.debug_level = 0
    options.debug_output_send = sys.stderr
    options.debug_output_receive = sys.stderr

    d = cSMPModule( options, module_id=6)
    d.CmdAck()
    info = d.GetConfigInfo()
    print( "info=%r" % info )


