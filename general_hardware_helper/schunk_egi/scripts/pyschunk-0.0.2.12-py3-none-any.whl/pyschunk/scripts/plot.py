#!/usr/bin/env python
# we need python windows since in cygwin subprocesses cannot be executed with access to stdin and stdout while threads (tkinter) are used

# *** PYTHON MODULE/SCRIPT TEMPLATE *** THINGS TO ADJUST ARE MARKED ***

'''
plot.py:      This is a python script. It can be run directly by calling
              "plot.py" or by calling "python -m plot". To be able
              to use it interactively start with "python -i -m plot".
Brief:        plots the *.gpd data in the file given as command line
              parameter with gnuplot. Gnuplot needs an xserver to display
              the plot. The DISPLAY variable must be set.
Author:       Dirk Osswald <dirk_osswald@web.de>
Date:         2008-01-23
CVS-revision: $Id$
'''

##########################################################################
# import needed modules:
import sys, os, string, subprocess, tempfile, time, re  # @UnusedImport

import pyschunk.tools.util
from pickle import UnpicklingError
from tkinter import *                  # @UnusedWildImport
#import Dialog
from tkinter import filedialog as tkFileDialog
from tkinter import messagebox as tkMessageBox
from idlelib import tooltip as ToolTip
ToolTip.ToolTip = ToolTip.Hovertip     # FIXME: remove this ugly hack!
import fnmatch
try:
    from TkinterDnD2 import *
except ImportError:
    print( "Drag & Drop not available")

    # generate a fake TkinterDnD object:
    TkinterDnD = pyschunk.tools.util.Struct()
    TkinterDnD.Tk = Tk
    Frame.drop_target_register = lambda s, x : False
    Frame.dnd_bind = lambda s, e, cb : False
    DND_FILES = ""

OS=sys.platform

# debugging stuff
from pyschunk.tools.dbg import tDBG
dbg = tDBG( description="pyschunk.scripts.plot")
#
##########################################################################

##########################################################################
# additional classes and functions

class SpinboxColored( Spinbox ):
    def __init__(self, master, **kw):
        self.values = kw["values"]
        self.colors = kw.pop("colors")
        self.textvariable = kw["textvariable"]
        kw["command"] = self._command

        self.value_to_color = dict()
        for (v,c) in zip( self.values, self.colors ):
            self.value_to_color[ v ] = c

        Spinbox.__init__( self, master, kw )
        self._command()

    def _command(self,event=None):
        self.config( bg=self.value_to_color[ self.textvariable.get() ] )

def GetUniqueStableList( iterable ):
    '''Return a list with the members of \a iterable uniquified in the same order as in \a iterable
    \remark set( iterable ) would to same but would \b not keep the order
    '''
    result = []
    for e in iterable:
        if not e in result:
            result.append(e)
    return result


def SaveSettings( settings, root_geometry, plotwindow_x, plotwindow_y, plotwindow_w, plotwindow_h, initialdir=None, do_close=True ):
    '''Save settings persistenly
    '''
    if ( root_geometry ):
        settings[ "root.geometry" ] = root_geometry
    if ( plotwindow_x ):
        settings[ "plotwindow_x" ] = plotwindow_x
        settings[ "plotwindow_y" ] = plotwindow_y
        settings[ "plotwindow_w" ] = plotwindow_w
        settings[ "plotwindow_h" ] = plotwindow_h

    if ( initialdir ):
        settings[ "initialdir" ] = initialdir

    if ( do_close ):
        settings.close()
    else:
        settings.sync()


def GetPlotWindowGeometry():
    '''return a tuple (x,y,w,h,id) of the current plot window dimensions,
    or throw Attribute error if window cannot be found
    '''
    try:
        display = os.environ.get( "DISPLAY")
        if ( display is None ):
            display = ":0.0"
        if ( "linux" in OS  or  "cygwin" in OS ):
            out = subprocess.Popen(['xwininfo', '-display', display, '-name', 'gnuplot/plot.py %d' % os.getpid()], stdout=subprocess.PIPE, stderr=subprocess.PIPE).communicate()[0]
        else:
            out = subprocess.Popen(['C:\\cygwin64\\bin\\xwininfo', '-display', display, '-name', 'gnuplot/plot.py %d' % os.getpid()], stdout=subprocess.PIPE, stderr=subprocess.PIPE).communicate()[0]
        plotwindow_x = int(re.search(b"Absolute upper-left X: *([0-9]+)", out ).group(1)) -4
        plotwindow_y = int(re.search(b"Absolute upper-left Y: *([0-9]+)", out ).group(1)) -23
        # gnuplot cannot handle negative x/y pos as expected, so limit to range [0..]
        if plotwindow_x < 0:
            plotwindow_x = 0
        if plotwindow_y < 0:
            plotwindow_y = 0
        plotwindow_w = int(re.search(b"Width: *([0-9]+)", out ).group(1))
        plotwindow_h = int(re.search(b"Height: *([0-9]+)", out ).group(1)) -13
        plotwindow_id = re.search(b"Window id: (0x[0-9a-fA-F]+)", out ).group(1)
        dbg << "GetPlotWindowGeometry:\n"
        dbg.var( "plotwindow_x plotwindow_y plotwindow_w plotwindow_h plotwindow_id" )
        return (plotwindow_x, plotwindow_y, plotwindow_w, plotwindow_h, plotwindow_id)
    except FileNotFoundError as e:
        # happens e.g. in case that xwininfo is not installed / cannot be found
        # So raise an AttributeError in turn which is expected by the callers
        raise AttributeError( "Could not get information from existing window. Maybe xwininfo is missing. Original error: %s" % (str(e)) )

class cGPD(object):
    '''Class for handling GnuPlotData objects
    '''
    def __init__(self, input_name ):
        ''' open and parse input_name, create the dat file, but not the dem file
        '''
        self.input_name = input_name

        # open the input file with the combined gnuplot + data:
        self.gpd = open( self.input_name, "r" )
        self.dat = open( self.DATFilename(), "w" )

        lines = self.gpd.readlines()
        self.gpd.close()

        # parse the input from self.gpd:
        #   fill in self.plots and self.additional
        #   create self.additional
        colums = []
        self.plots  = []
        self.additional = []
        self.y1label = self.y1label_orig = ""
        self.y2label = self.y2label_orig = ""
        rex_y1 = re.compile( "# +set +ylabel +['\"]([^'\"]*)['\"]" )
        rex_y2 = re.compile( "# +set +y2label +['\"]([^'\"]*)['\"]" )
        for l in lines:
            # remove trailing \r \n
            while len(l)>0 and l[-1] in [ "\r", "\n" ]:
                l = l[:-1]

            if ( len(l)>0 and l[0] == "#" ):

                mob_y1 = rex_y1.match( l[1:] )
                mob_y2 = rex_y2.match( l[1:] )

                # parse lines like: (old style gpd files)
                # ## def 0 0  ventil 1 lines   ventil 2 lines  chuck open/closed lines sensor 0 linespoints sensor 1 linespoints sensor 2 linespoints sensor 3 linespoints sensor 6 linespoints sensor 7 linespoints
                if ( l[1:7] == "# def " ):
                    plotdef = string.split( l[7:] )[2:]
                    for  i in range( 0, len(plotdef), 3 ):
                        colums.append( (plotdef[i] + ": " + plotdef[i+1],plotdef[i+2]) )

                # parse lines like:
                # ## plot using 1:2 with lines title 'a signal'
                # or
                # ## plot using 1:($2-$3) with linespoints title 'calculated differential signal'
                elif ( l[1:8] == "# plot " ):
                    self.plots.append( l[8:] )

                # parse lines like:
                # ## set ylabel 'logged values'
                # ## set y2label 'logged values'
                elif ( mob_y1 ):
                    self.y1label = self.y1label_orig = mob_y1.group(1)
                elif ( mob_y2 ):
                    self.y2label = self.y2label_orig = mob_y2.group(1)


                # parse lines with additional gnuplot commands like:
                # ## set xlabel...
                # or
                # ## set grid
                elif ( l[1:3] == "# " ):
                    self.additional.append( l[3:] + '\n' )
            else:
                # normal data line
                self.dat.write( l + '\n' )

        # finally translate old style plot definitions to new style and add to self.plots
        for (c,(t,style)) in enumerate( colums ):
            self.plots.append( "using 1:%d with %s title '%s'" % (c+2, style, t ) )

        self.dat.close()
        dbg.var( "self.plots" )
        dbg.var( "self.additional" )


    def DEMWrite(self, plots, terminal="x11 noenhanced ", terminaloptions="" ):
        '''Create a unique gnuplot dem file with the actual gnuplot commands.
        plots is a list of plot commands like self.plot
        A unique dem file is generated so that multiple plots can be generated concurrently
        The dem file object is returned.

        The noenhanced option lets names with underscores appear correctly instead of subscript
        '''
        # \remark: for debugging the temporary files mode "w+" does not work. So you have to set to delete=False then
        dem = tempfile.NamedTemporaryFile( "w", prefix="plot_py", suffix=".dem" )#, delete=False ) # FIXed: remove delete=False
        dbg.var( "dem.name" )
        dbg.output.flush()

        dem.write( "set terminal %s %s\n" % (terminal,terminaloptions) )
        if ( not "x11" in terminal ):
            dem.write( "set output '%s.%s'\n" % (self.input_name, terminal) )

        for a in self.additional:
            dem.write( "%s\n" % a )

        if ( self.y1label != "" ):
            dem.write( 'set  ylabel "%s"\n' % self.y1label )
        if ( self.y2label != "" ):
            dem.write( 'set y2label "%s"\n' % self.y2label )

        dem.write( "plot " )
        sep = ""
        filename = self.DATFilename()
        for p in plots:
            dem.write( "%s'%s' %s" % (sep, filename, p ) )
            sep = ", "
            filename = "" # reuse previous file. Makes plot lines much shorter

        dem.write( "\n" )
        dem.flush()
        # dem MUST not be closed here, since it is destroed on close! The tempfile stuff will automagically delete it on close/exit
        return dem

    def DATFilename(self):
        return self.input_name + ".dat"

#    def DEMFilename(self):
#        return self.input_name + ".dem"

    def GetPlotTitles(self):
        '''return list of titles of self.plots
        '''
        titles = []
        for p in self.plots:
            if ( "title" in p ):
                tre = re.compile("title *['\"]([^'\"]*)['\"]")
                tmo = tre.search( p )
                if ( tmo ):
                    titles.append( tmo.group(1) )
                else:
                    titles.append( p )
            else:
                titles.append( p )
        return titles

    def GetPlotUnits(self):
        '''return list of units of self.plots
        '''
        units = []
        for p in self.plots:
            if ( "title" in p ):
                tre = re.compile("title *['\"][^'\"\[]*(\[[^'\"\]]*\])['\"]")
                tmo = tre.search( p )
                if ( tmo ):
                    units.append( tmo.group(1) )
                else:
                    units.append( "" )
            else:
                units.append( "" )
        return units

    def GetTitle(self):
        '''return common title of plot
        '''
        rex = re.compile( "set +title +['\"]([^'\"]*)['\"]")
        for l in self.additional:
            rmo = rex.search( l )
            if ( rmo ):
                return rmo.group(1)
        return ""

    def SetTitle(self, newtitle ):
        '''set the title in the data for the DEM file, but
        do not save to DEM file, nor to original gpd file
        '''
        old_additional = self.additional
        self.additional = []
        replaced = False
        rex = re.compile( "set +title +['\"]([^'\"]*)['\"]" )
        for l in old_additional:
            rmo = rex.search( l )
            if ( rmo ):
                self.additional.append('set title "%s"\n' % newtitle )
                replaced = True
            else:
                self.additional.append(l)

        if (not replaced):
            self.additional.append('set title "%s"\n' % newtitle )

    def SaveTitle(self, newtitle):
        '''Save \a newtitle as new title to the gpd file
        '''
        now = time.localtime()
        date = "%4d-%02d-%02d %02d:%02d:%02d" % (now.tm_year, now.tm_mon, now.tm_mday, now.tm_hour, now.tm_min, now.tm_sec)
        self.gpd = open( self.input_name, "a" )
        self.gpd.write( "# Appended by plot.py on %s:\n" % date )
        self.gpd.write( "## set title \"%s\"" % newtitle )
        self.gpd.close()


    def DeleteFiles(self):
        dbg << "cGPD::DeleteFiles, deleting %r %r\n" % (self.input_name, self.DATFilename())
        os.remove( self.input_name )
        os.remove( self.DATFilename() )


#
##########################################################################

##########################################################################
# GUI stuff

class cTkPlotMenu(Menu):
    def __init__(self,master):
        Menu.__init__(self,master=master)

        self.file_menu = Menu()
        self.file_menu.add_command( label='Open...', underline=0, command=master.CBOpenFile )
        self.file_menu.add_command( label='Export as PDF...', underline=0, command=master.CBExportPDF )
        self.file_menu.add_command( label='Export as ...', underline=1, command=master.CBExportFile )
        self.file_menu.add_separator()
        self.file_menu.add_command( label='Delete file & Quit', underline=0, command=master.CBDeleteFile )
        self.file_menu.add_separator()
        self.file_menu.add_command( label='Quit', underline=0, command=master.CBQuit )
        self.add_cascade( label='File', menu=self.file_menu, underline=0 )

        self.edit_menu = Menu()
        self.edit_menu.add_command(label='Edit title...', underline=5, command=master.CBEditTitle)
        self.edit_menu.add_command(label='Edit export options...', underline=5, command=master.CBEditExportOptions)
        self.edit_menu.add_command(label='Edit plots...', underline=5, command=master.CBEditPlots)
        self.add_cascade( label='Edit', menu=self.edit_menu, underline=0 )
        master.master.config(menu=self)


class cTkPlotApplication(Frame):
    #-----------------------------------------------------------------
    ## Constructor of cTkPlotApplication
    def __init__(self, gpdfilename, master=None, plot_selection="all", settings=None ):
        Frame.__init__(self, master, class_="cTkPlotApplication" )
        if ( dbg.GetFlag() ):
            self.after( 1000, self.FlushOutput )
        self.grid(sticky=N+W+E)
        #self.columnconfigure(0, weight=1)
        #self.rowconfigure(0, weight=0)
        #self.rowconfigure(2, weight=1)
        self.gnuplot_process = None
        if ( gpdfilename ):
            self.initialdir = os.path.dirname(gpdfilename)
        elif ("initialdir" in settings  and  settings["initialdir"]):
            self.initialdir = settings["initialdir"]
        else:
            self.initialdir = os.path.dirname( os.getcwd() )

        # list of pairs of file types to load: (typedescription, suffix)
        self.loadfiletypes=[("GNUplot data", ".gpd")]

        # list of pairs of file types to export to: (typedescription, suffix)
        self.exportfiletypes=[("Portable Document Format", ".pdf"), ("PNG", ".png"), ("Enhanced Meta File", ".emf")]

        # list of pairs of terminal options of terminal types to export to: (suffix, gnuplot-terminal-options)
        self.export_terminal_options = {
                                        "pdf" : "pdf size 29.7cm,21.0cm",
                                        "png" : "png size 1024,768",
                                        "emf" : "emf",
                                        }
        self.settings = settings
        self.plotwindow_x = self.settings.setdefault( "plotwindow_x", None )
        self.plotwindow_y = self.settings.setdefault( "plotwindow_y", None )
        self.plotwindow_w = self.settings.setdefault( "plotwindow_w", None )
        self.plotwindow_h = self.settings.setdefault( "plotwindow_h", None )

        # create all subwidgets
        self.bt_replot = None
        self.CreateCommonWidgets()
        self.CBOpenFile( gpdfilename, plot_selection )

        self.master.protocol("WM_DELETE_WINDOW", self.CBQuit )
        #dbg << "set master geometry to %r\n" % self.settings.setdefault( "root.geometry", "-0+0" )
        #geometry = self.settings.setdefault( "root.geometry", "-0+0" )
        #if ( geometry != "-0+0" ):
        #    print( "geometry=%r" % geometry )
        self.master.geometry(  ) # geometry ) # setting no geometry at all yields new windws in slightly different positions, like we want!
        self.master.geometry("") # see http://stackoverflow.com/questions/8997497/what-controls-automated-window-resizing-in-python-tkinter

        self.drop_target_register( DND_FILES )
        self.dnd_bind('<<Drop>>', self.CBDrop)

    def CBDrop(self, event):
        '''Callback for Drag & Drop Drop action
        '''
        dbg << f"CBDrop: {event.data}"
        self.CBOpenFile( event.data )


    def CBQuit(self):
        '''Callback called when quitting application by file->quit or ALT-F4 or WM_DELETE_WINDOW
        '''
        dbg << "cTkPlotApplication::CBQuit called\n"
        self.UpdatePlotWindowGeometrySetting()
        SaveSettings( self.settings, self.master.geometry(), self.plotwindow_x, self.plotwindow_y, self.plotwindow_w, self.plotwindow_h, initialdir=self.initialdir, do_close=True )
        Frame.quit(self)

    def CBEditTitle(self):
        self.tl_edit_title = Toplevel()
        self.tl_edit_title.label = Label(self.tl_edit_title, text="Edit the title of the plot")
        self.tl_edit_title.label.pack()
        self.tl_edit_title.text = Text(self.tl_edit_title)
        title = self.gpd.GetTitle().replace("\\n","\n")
        self.tl_edit_title.text.insert( 'end', title )
        self.tl_edit_title.text.pack()
        ToolTip.ToolTip(self.tl_edit_title.text, "Edit the title, use CTRL-Return for OK" )
        self.tl_edit_title.ok = Button(self.tl_edit_title, text="OK", command=self.CBChangeTitle )
        self.tl_edit_title.ok.pack()
        self.tl_edit_title.text.bind('<Control-Key-Return>', lambda event : self.tl_edit_title.ok.invoke() )  # @UnusedVariable
        self.tl_edit_title.cancel = Button( self.tl_edit_title, text="Cancel", command=self.tl_edit_title.destroy )
        self.tl_edit_title.cancel.pack()

    def CBEditExportOptions(self):
        self.tl_edit_export_options = Toplevel()
        self.tl_edit_export_options.label = Label(self.tl_edit_export_options, text="Edit the export terminal options. (Python dictionary of SUFFIX: OPTIONS entries)")
        self.tl_edit_export_options.label.pack()
        self.tl_edit_export_options.text = Text(self.tl_edit_export_options)
        self.tl_edit_export_options.text.insert( 'end', repr( self.export_terminal_options ) )
        self.tl_edit_export_options.text.pack()
        ToolTip.ToolTip(self.tl_edit_export_options.text, "Edit the export options (must be a valid python expression forming a dictionary), use CTRL-Return for OK" )
        self.tl_edit_export_options.ok = Button(self.tl_edit_export_options, text="OK", command=self.CBChangeExportTerminalOptions )
        self.tl_edit_export_options.ok.pack()
        self.tl_edit_export_options.text.bind('<Control-Key-Return>', lambda event : self.tl_edit_export_options.ok.invoke() )  # @UnusedVariable
        self.tl_edit_export_options.cancel = Button( self.tl_edit_export_options, text="Cancel", command=self.tl_edit_export_options.destroy )
        self.tl_edit_export_options.cancel.pack()

    def CBEditPlots(self):
        self.tl_edit_plots = Toplevel()
        self.tl_edit_plots.label = Label(self.tl_edit_plots, text="Edit the plots:")
        self.tl_edit_plots.label.pack()
        self.tl_edit_plots.text = Text(self.tl_edit_plots )
        for l in self.gpd.plots:
            self.tl_edit_plots.text.insert( 'end', l + "\n" )
        self.tl_edit_plots.text.pack(fill=BOTH, expand=1)
        ToolTip.ToolTip(self.tl_edit_plots.text, "Edit the plots. Use CTRL-Return for OK" )
        self.tl_edit_plots.ok = Button(self.tl_edit_plots, text="OK", command=self.CBChangePlots )
        self.tl_edit_plots.ok.pack()
        self.tl_edit_plots.text.bind('<Control-Key-Return>', lambda event : self.tl_edit_plots.ok.invoke() )  # @UnusedVariable
        self.tl_edit_plots.cancel = Button( self.tl_edit_plots, text="Cancel", command=self.tl_edit_plots.destroy )
        self.tl_edit_plots.cancel.pack()

    def CBChangeTitle(self):
        # get title from top level window text edit, translate \n to \\n for gnuplot:
        newtitle = self.tl_edit_title.text.get(At(0,0),"end").replace('\n', '\\n')
        # delete last unwanted \\n:
        if (newtitle[-2:] == '\\n'):
            newtitle = newtitle[:-2]
        dbg.var("newtitle")
        self.gpd.SetTitle( newtitle )
        self.gnuplot_process.stdin.write( b'set title "%s" ; replot\n' % newtitle)
        self.tl_edit_title.destroy()
        self.gpd.SaveTitle( newtitle )

    def CBChangeExportTerminalOptions(self):
        self.export_terminal_options = eval( self.tl_edit_export_options.text.get(At(0,0),"end" ) )
        self.tl_edit_export_options.destroy()

    def CBChangePlots(self):
        self.gpd.plots = [ l for l in self.tl_edit_plots.text.get(At(0,0),"end" ).split("\n") ]

        self.tl_edit_plots.destroy()
        self.CBCBPlot()

    #-----------------------------------------------------------------
    ## Create the GUI widgets:
    def CreateCommonWidgets(self):
        row = 0
        #---------------------
        # menu
        self.mymenu = cTkPlotMenu( master=self )
        row += 1
        #---------------------

        #---------------------
        # text selector
        self.text_selector = Entry(master=self)
        self.text_selector.grid( row=row, sticky=N+W+E )
        ToolTip.ToolTip(self.text_selector,  'Enter a comma separated list of expressions to enable, disable or toggle the plots to use\n' +
                                             'E.g. enter "+A,-B,C" + Return to:\n' +
                                             '  + enable all plots containing "A" in the title\n' +
                                             '  - disable all plots with "B"\n' +
                                             '    toggle all plots with "C"\n' +
                                             'Use CTRL-Return to set and replot' )
        row += 1
        self.text_selector.bind('<Key-Return>', self.CBTextSelector )
        self.text_selector.bind('<Control-Key-Return>', self.CBTextSelectorReplot )
        #---------------------

        self.ivar_plot_selector = []
        self.cb_plot_selector   = []
        self.xaxis_plot_selector   = []
        self.yaxis_plot_selector   = []

    def CreatePlotWidgets(self, plot_selection="all"):
        row = 2
        column = 0
        maxrow = 0
        #---------------------
        # checkbuttons and stuff
        for cpps in self.cb_plot_selector:
            cpps.grid_forget()
        for cpps in self.xaxis_plot_selector:
            cpps.grid_forget()
        for cpps in self.yaxis_plot_selector:
            cpps.grid_forget()
        del self.cb_plot_selector
        del self.xaxis_plot_selector
        del self.yaxis_plot_selector
        self.cb_plot_selector = []
        self.xaxis_plot_selector = []
        self.yaxis_plot_selector = []

        #for ips in self.ivar_plot_selector:
        #    del self.ivar_plot_selector[0]
        del self.ivar_plot_selector
        self.ivar_plot_selector = []

        if ( plot_selection ):
            plot_selection_indices  = pyschunk.tools.util.RangeDefToList( plot_selection )
        else:
            plot_selection_indices  = range(0,len(self.gpd.GetPlotTitles()))
        for (i,(u,t)) in enumerate( zip( self.gpd.GetPlotUnits(), self.gpd.GetPlotTitles() ) ):  # @UnusedVariable

            # in case an axes definition is part of the gpd input file we should use these as default:
            x_defaults = {1:"x-bottom", 2:"x-top"}
            y_defaults = {1:"y-left", 2:"y-right"}
            mo = re.search( "axes\s+x([12])y([12])", self.gpd.plots[i] )
            x = 1
            y = 1
            if ( mo ):
                x = int(mo.group(1))
                y = int(mo.group(2))
            x_default = x_defaults[ x ]
            y_default = y_defaults[ y ]

            (default_selected,default_xaxis,default_yaxis) = self.settings.setdefault( "plot." + t, (1,x_default,y_default) )
            self.ivar_plot_selector.append( IntVar(value=default_selected) )
            if (i not in plot_selection_indices ):
                self.ivar_plot_selector[i].set(0)
            cb = Checkbutton(master=self, text=t, variable=self.ivar_plot_selector[i] )#, command=self.CBCBPlot )
            ToolTip.ToolTip(cb, 'Enable or disable this plot.\n\nUse CTRL-Button1 to toggle and replot.\n\nUse CTRL-Shift-Button1 to invert the selection of all plots.' )

            # the replot callback must be called delayed since else the current change of the checkbutton is not regarded
            cb.bind('<Control-Button-1>', self.CBCBPlotDelayed )
            cb.bind('<Control-Shift-Button-1>', self.CBInvert )
            self.cb_plot_selector.append( cb )
            self.cb_plot_selector[ i ].grid( row=row, column=column, sticky=NW )

            #xaxis = Spinbox(master=self, from_=1, to=2, width=1)
            xspinval = StringVar()
            xaxis = SpinboxColored(master=self, values=["x-bottom", "x-top"], colors=["#ffc0c0", "#c0ffc0"], width=8, textvariable=xspinval)
            xspinval.set( default_xaxis )
            xaxis._command()
            self.xaxis_plot_selector.append( xaxis )
            ToolTip.ToolTip(xaxis, 'Select which x axis to use for this plot.' )
            self.xaxis_plot_selector[ i ].grid( row=row, column=column+1, sticky=NW )

            yspinval = StringVar()
            yaxis = SpinboxColored(master=self, values=["y-left", "y-right"], colors=["#ffc0c0", "#c0ffc0"], width=8, textvariable=yspinval)
            yspinval.set( default_yaxis )
            yaxis._command()
            ToolTip.ToolTip(yaxis, 'Select which y axis to use for this plot.' )
            self.yaxis_plot_selector.append( yaxis )
            self.yaxis_plot_selector[ i ].grid( row=row, column=column+2, sticky=NW )

            row += 1
            if (row > 30):
                maxrow = row
                row = 2
                column += 3
                self.text_selector.grid_configure( columnspan=column+1 )
                ###self.mymenu.grid_configure( columnspan=column+1 )
        #---------------------
        if (self.bt_replot):
            self.bt_replot.destroy()
        self.bt_replot = Button(self, text="Replot", command=self.CBCBPlot )
        self.bt_replot.grid( row=max(row,maxrow), column=0, columnspan=1+column )

    def FlushOutput(self):
        '''flush stdout and stderr. Seems to be necessary to
        see error messages and stack traces while the program is
        running
        '''
        sys.stdout.flush()
        sys.stderr.flush()

        self.after( 1000, self.FlushOutput )


    def CBTextSelectorReplot(self,event=None):
        self.CBTextSelector(event)
        self.CBCBPlotDelayed(event)

    def CBTextSelector(self,event=None):  # @UnusedVariable
        for text in self.text_selector.get().split(","):
            action=2
            dbg.var("text")
            if ( text[0] == '+'):
                action=1
                text = text[1:]
            elif ( text[0] == '-' ):
                action=0
                text = text[1:]
            for (i,t) in zip(self.ivar_plot_selector,self.gpd.GetPlotTitles()):
                if ( not text in t ):
                    continue
                dbg << "action %d on plot %s\n" % (action, t) # pylint: disable-msg=W0104
                if (action==2):
                    i.set(1-i.get())
                else:
                    i.set(action)

    def CBInvert(self,event=None):
        for i in self.ivar_plot_selector:
            i.set(1-i.get())
        self.CBCBPlotDelayed(event)

    def CBCBPlotDelayed(self, event=None):
        self.after( 200, self.CBCBPlot, event )

    def UpdatePlotWindowGeometrySetting(self):
        # try to get current plot window position:
        try:
            (self.plotwindow_x, self.plotwindow_y, self.plotwindow_w, self.plotwindow_h, plotwindow_id) = GetPlotWindowGeometry()  # @UnusedVariable
        except AttributeError:
            pass

    def CBCBPlot(self, event=None):  # @UnusedVariable
        self.UpdatePlotWindowGeometrySetting()
        plots = []
        units_y1 = []
        units_y2 = []
        has_x2 = False
        has_y2 = False
        for (selected,p,xaxis,yaxis,plot_title,plot_unit) in zip(self.ivar_plot_selector,
                                                                 self.gpd.plots,
                                                                 self.xaxis_plot_selector,
                                                                 self.yaxis_plot_selector,
                                                                 self.gpd.GetPlotTitles(),
                                                                 self.gpd.GetPlotUnits()):
            if ( selected.get() ):
                if ( xaxis.get() == "x-bottom" ):
                    x = 1
                else:
                    x = 2
                    has_x2 = True
                if ( yaxis.get() == "y-left" ):
                    y = 1
                    units_y1.append(plot_unit)
                else:
                    y = 2
                    has_y2 = True
                    units_y2.append(plot_unit)
                axes = " axes x%dy%d" % ( x,y )

                mo = re.match( "(.*)axes\s+x[12]y[12](.*)", p )
                if ( mo ):
                    dbg << "modifying p=%r" % p
                    p = mo.group(1) + " " + mo.group( 2 )
                    dbg << " to p=%r\n" % p
                plots.append(p + axes)

            # save selection and axis mapping to settings
            self.settings[ "plot." + str(plot_title) ] = (selected.get(),xaxis.get(),yaxis.get())
        # finally sync settings to file so that other plot.py started in parallel use the new settings right away
        # (master geometry is invalid on first call, so dont save it)
        SaveSettings( self.settings, None, self.plotwindow_x, self.plotwindow_y, self.plotwindow_w, self.plotwindow_h, initialdir=self.initialdir, do_close=False )

        if ( has_x2 ):
            if ( "set x2tics\n" not in self.gpd.additional ):
                self.gpd.additional.append( "set x2tics\n" )
            if ( "set x2tics out\n" not in self.gpd.additional ):
                self.gpd.additional.append( "set x2tics out\n" )
        else:
            if ( "set x2tics out\n" in self.gpd.additional ):
                self.gpd.additional.remove( "set x2tics out\n" )
            if ( "set x2tics\n" in self.gpd.additional ):
                self.gpd.additional.remove( "set x2tics\n" )

        if ( has_y2 ):
            if ( "set y2tics\n" not in self.gpd.additional ):
                self.gpd.additional.append( "set y2tics\n" )
            if ( "set y2tics out\n" not in self.gpd.additional ):
                self.gpd.additional.append( "set y2tics out\n" )
            if ( "set ytics in\n" not in self.gpd.additional ):
                self.gpd.additional.append( "set ytics in\n" )
            units = GetUniqueStableList( units_y2 )
            label = self.gpd.y2label_orig
            sep = "\\n"
            for u in units:
                if ( u == "" ):
                    continue
                label += sep + u
                sep = ", "
            self.gpd.y2label = label
        else:
            if ( "set y2tics\n" in self.gpd.additional ):
                self.gpd.additional.remove( "set y2tics\n" )
            if ( "set y2tics out\n" in self.gpd.additional ):
                self.gpd.additional.remove( "set y2tics out\n" )
            if ( "set y2tics in\n" in self.gpd.additional ):
                self.gpd.additional.remove( "set y2tics in\n" )

        units = GetUniqueStableList( units_y1 )
        label = self.gpd.y1label_orig
        dbg.var("units label")
        sep = "\\n"
        for u in units:
            if ( u == "" ):
                continue
            label += sep + u
            sep = ", "
            dbg.var("u")
        self.gpd.y1label = label

        #dbg.var( "plots" )
        if ( self.plotwindow_x ):
            self.demfile = self.gpd.DEMWrite( plots, terminaloptions='title "gnuplot/plot.py %d" size %d,%d position %d,%d' % (os.getpid(), self.plotwindow_w, self.plotwindow_h, self.plotwindow_x, self.plotwindow_y) )
        else:
            self.demfile = self.gpd.DEMWrite( plots, terminaloptions='title "gnuplot/plot.py %d"' % (os.getpid()) )


        if ( self.gnuplot_process ):
            dbg << "killing old gnuplot process %d\n" % self.gnuplot_process.pid # pylint: disable-msg=W0104
            try:
                self.gnuplot_process.stdin.write( b"exit\n" )
                self.gnuplot_process = None
            except IOError as e:
                dbg << "Ignoring error while killing old gnuplot process: %s\n" % str(e) # pylint: disable-msg=W0104

            ## does not work on windows:
            #os.kill( self.gnuplot_process.pid, 15 )
            #os.waitpid(self.gnuplot_process.pid, 0)

        dbg << "starting new gnuplot process\n" # pylint: disable-msg=W0104
        #self.gnuplot_process = subprocess.Popen( ["gnuplot", self.demfile.name, "-"],
        # use the cygwin gnuplot with x11 terminal:
        env = os.environ.copy()
        if ( not "DISPLAY" in env ):
            env["DISPLAY"] = ":0.0"
            dbg << "Setting DISPLAY to default %s\n" % env["DISPLAY"] # pylint: disable-msg=W0104

        # necessary when calling from windows environment like cmd.exe, eclipse, ...
        env["PATH"] = "/usr/local/src/py-dist/py/bin:/usr/local/bin:/usr/bin:/bin:/usr/X11R6/bin:/home/Osswald2/bin:."

        ## does not work when called from plot.bat: (gnuplot process is started, but cannot create x11 window
        if ( "linux" in OS  or  "cygwin" in OS ):
            gnuplot_cmd = ["gnuplot", self.demfile.name, "-"]
        else:
            # does not longer work since its a symlink managed by alternatives:
            #gnuplot_cmd = "C:\\cygwin64\\bin\\gnuplot.exe " + pyschunk.tools.util.WinpathToCygpath(self.demfile.name) + " -"

            # does only work when cygwin gnuplot-x11 is installed:
            gnuplot_cmd = "C:\\cygwin64\\bin\\gnuplot-x11.exe " + pyschunk.tools.util.WinpathToCygpath(self.demfile.name) + " -"

            # mobaxterm gnuplot:
            #gnuplot_cmd = "C:\\Users\\r001483\\DOCUME~1\\MOBAXT~1\\slash\\bin\\gnuplot.exe " + pyschunk.tools.util.WinpathToCygpath(self.demfile.name) + " -"

        #gnuplot_cmd = "C:\Program Files\gnuplot\bin\wgnuplot.exe " + self.demfile.name + " -"

        # call via bash:
        #gnuplot_cmd = "D:\\Programme\\cygwin\\bin\\bash -l -c gnuplot " + pyschunk.tools.util.WinpathToCygpath(self.demfile.name) + " -"

        dbg << "calling \"%s\"\n" % (gnuplot_cmd) # pylint: disable-msg=W0104
        self.gnuplot_process = subprocess.Popen( gnuplot_cmd,
                                                 stdin=subprocess.PIPE, # stdout=subprocess.PIPE,
                                                 env=env )
        dbg << "started new gnuplot process with pid %d\n" % self.gnuplot_process.pid # pylint: disable-msg=W0104

        ## will fail on cygwin:
        #self.gnuplot_process = subprocess.Popen(["d:\\Programme\\cygwin\\bin\gnuplot.exe", self.demfile.name] )#, shell=True)
        ## will fail on cygwin:
        #(self.gnuplot_stdin,self.gnuplot_stdout) = os.popen2("gnuplot " + self.demfile.name + " -" )#, "w" )
        #self.gnuplot_stdin.write( b"set title 'bla' ; replot \n" )

    def CBOpenFile(self, gpdfilename=None, plot_selection="all"):
        if ( not gpdfilename ):
            gpdfilename = tkFileDialog.askopenfilename(initialdir=self.initialdir, filetypes=self.loadfiletypes, title="Select a gnuplot data file *.gpd")
        if gpdfilename=="": return "No file selected"

        self.initialdir = os.path.dirname(gpdfilename)

        self.gpd = cGPD( gpdfilename )
        self.CreatePlotWidgets(plot_selection)
        self.CBCBPlot()
        self.master.title("plot.py: %s" % (gpdfilename) )

    def CBExportPDF(self):
        pdffilename = self.gpd.input_name.replace( ".gpd", "" ) + ".pdf"
        return self.CBExportFile( pdffilename )

    def CBExportFile(self, filename="" ):
        if (filename == ""  or  os.path.exists(filename)):
            if (filename==""):
                filename = tkFileDialog.asksaveasfilename( initialdir=self.initialdir,
                                                           initialfile=self.gpd.input_name.replace(".gpd",".pdf"),
                                                           filetypes=self.exportfiletypes,
                                                           title="Enter filename with correct extension:" )
            else:
                filename = tkFileDialog.asksaveasfilename( initialdir=self.initialdir,
                                                           initialfile=filename,
                                                           filetypes=self.exportfiletypes,
                                                           title="File exists! Confirm to overwrite or enter new filename with correct extension:" )
            # overwriting is already queried!

        if filename=="": return

        self.initialdir = os.path.dirname(filename)

        terminal_options = self.export_terminal_options[ filename[-3:] ]
        cyg_filename = subprocess.Popen(["cygpath", "-u", filename ], stdout=subprocess.PIPE).communicate()[0]
        while cyg_filename[-1] in ['\r','\n']:
            cyg_filename = cyg_filename[:-1]
        cmd = "set terminal " + terminal_options + " ; set output '" + cyg_filename + "' ; replot ; set output ; set terminal x11\n"
        dbg << "exporting via gnuplot command <%s>\n" % repr(cmd) # pylint: disable-msg=W0104
        self.gnuplot_process.stdin.write( bytes( cmd, "ascii" ) )
        dbg << 'exported file to "%s"\n' % filename

    def CBDeleteFile(self):
        if tkMessageBox.askyesno("Delete file and Quit", "Do you really want to delete the file %r and quit?" % self.gpd.input_name ):
            dbg << "deleting\n"
            try:
                self.gpd.DeleteFiles()
            except Exception as e:
                if ( not tkMessageBox.askokcancel( "Deleting of file failed", f":\n{e!r}\nPress OK to quit anyway or cancel quitting" ) ):
                    return
            self.CBQuit()
        else:
            dbg << "not deleting\n"

#
##########################################################################

def IsExe( p ):
    '''Determine if p is a (windows) exe file
    '''
    if ( not ("win" in OS) or p.endswith( ".py" ) ):
        return False

    if ( not os.path.isfile( p ) ):
        p = p + ".exe"
    if ( not os.path.isfile( p ) ):
        return False

    import stat
    # source https://bytes.com/topic/python/answers/577007-need-simple-way-determine-if-file-executable
    return ( os.stat( p )[stat.ST_MODE] & (stat.S_IXUSR|stat.S_IXGRP|stat.S_IXOTH) )


def Watch( options ):
    ###
    # Create the command line including command and command line arguments
    # to start the subprocess.
    # Use our command line arguments for that, but these have to be modified:
    # - The first argument ("script name") must be handled especially:
    #   - in case the plot.py python script was called directly, then
    #     sys.argv[0] will be just that: the path to the script. Good.
    #   - in case the plot.py python script was called via a wrapper, e.g.
    #     a windows executable generated by pip on installation of
    #     the pyschunk*.whl wheel, then sys.argv[0] will be the path to
    #     that wrapper, but without exe extension!
    if ( IsExe( sys.argv[0] ) ):
        cmd = sys.argv[0]
    else:
        cmd = '"' + sys.executable + '" ' + sys.argv[0]

    for a in sys.argv[1:]:
        if not a in ( "-w", "--watch" ):
            cmd += " " + a
    #
    ###

    path_to_watch = "."

    print( "OK, watching directory %r for new or changed *.gpd files" % path_to_watch )
    sys.stdout.flush()

    def GetGPDFiles():
        """
        Return dictionary of filename->modificationtime entries for all *.gpd files in path_to_watch
        """
        gpds = fnmatch.filter( os.listdir(path_to_watch), '*.gpd' )

        return dict( [ (gpd,os.stat(gpd).st_mtime) for gpd in gpds ] )

    before = GetGPDFiles()
    while True:
        time.sleep (3)
        after = GetGPDFiles()
        added_or_changed = [f for f in after if not f in before] + [f for f in after if ( (f in before) and (after[f] > before[f]) )]
        #removed = [f for f in before if not f in after]
        if added_or_changed:
            for f in added_or_changed:
                dbg << "detected new or changed GPD file %r\n" % f
                # wait until miniterm.py has finally written all of the file
                # TODO: instead of waiting a fixed time check until file size no longer changes
                time.sleep( 3 )
                dbg << "calling Popen %r with shell=True\n" % ( cmd + " " + f)
                subprocess.Popen( cmd + " " + f , shell=True)

        #if removed: print( "Removed: ", ", ".join (removed) )
        before = after

##########################################################################
# the main function
def main():
    global __doc__  # @ReservedAssignment

    #----------------------------
    # handle command line options
    parser = pyschunk.tools.util.tMyOptionParser( usage = __file__ + "\n" + __doc__ + "\nusage: %prog [options] FILE.gpd",
                                           version = __file__ + " version: $Id$" )

    parser.add_option( "-l", "--list",
                       dest="listonly", default=False, action="store_true",
                       help="only list the plots contained in the file, do not plot.")

    parser.add_option( "-s", "--select",
                       dest="selection", default="all", type="string",
                       help='Select the plots by index. Use e.g. "1", "1,2,4", "3-6". The default is "all".')

    parser.add_option( "-t", "--terminal",
                       dest="terminal", default="x11", type="string",
                       help='Select the gnuplot terminal to use, like "pdf" or "png" or "emf". Default is "x11" for interactive X11 display')

    # *** place your options here: (this is just an example)
    parser.add_option( "-g", "--gui",
                       dest="withgui", default=False, action="store_true",
                       help="show a simple gui to select the data to plot.")

    parser.add_option( "-w", "--watch",
                       dest="watch", default=False, action="store_true",
                       help="watch the current directory for new *.gpd files and start a new plot.py for each one.")

    parser.add_option( "-f",
                       dest="file", default=None, metavar="FILE",
                       help="Read the actual gpd file name from FILE.")

    (options, args) = parser.parse_args()
    # enable or disable debug messages  here
    dbg.SetFlag( options.debug )

    dbg << "options = " << options << "\n" # pylint: disable-msg=W0104
    dbg << "args    = " << args << "\n" # pylint: disable-msg=W0104

    if ( options.watch ):
        Watch( options )

    if ( len(args) < 1 ):
        if ( options.file ):
            f = open( options.file, "r" )
            gpdfilename = eval( "r"+f.readline() )  # eval to strip of ""
            f.close()
        else:
            options.withgui = True
            gpdfilename = None
            #sys.stderr.write( "You must provide a filename with the data to plot in gpd format\n" )
            #sys.exit(1)

    elif ( len(args) > 1 ):
        sys.stderr.write( "Ignoring additional args: %s\n" % repr(args[1:]) )
        gpdfilename = args[0]
    else:
        gpdfilename = args[0]
    dbg.var( "gpdfilename" )
    #
    #----------------------------


    #----------------------------
    # now for some real work:

    if ( options.listonly ):
        # just list the plots
        gpd = cGPD( gpdfilename )
        for (i,p) in enumerate(gpd.GetPlotTitles()):
            print( "%2d: %s" % (i,p) )
        return

    try:
        settings = pyschunk.tools.util.GetPersistantDict( ".plot4", cdbg = dbg )
    except UnpicklingError as e:
        print( f"Could not read settings: {e}. Try to delete the ~/.plot3 file and retry" )
        sys.exit(1)

    if ( options.withgui ):
        # The GUI stuff
        root = TkinterDnD.Tk()
        app = cTkPlotApplication( gpdfilename=gpdfilename, master=root, plot_selection=options.selection, settings=settings )
        app.mainloop()
        return

    gpd = cGPD( gpdfilename )
    plots = []
    plots_to_use = pyschunk.tools.util.RangeDefToList( options.selection )
    for (i,p) in enumerate(gpd.plots):
        if ( i in plots_to_use ):
            plots.append( gpd.plots[i] )
    dbg.var( "plots" )

    if ( options.terminal=="x11" ):
        if ( "plotwindow_x" in settings ):
            demfile = gpd.DEMWrite( plots, terminaloptions='persist title "gnuplot/plot.py %d" size %d,%d position %d,%d' % (os.getpid(), settings[ "plotwindow_w" ], settings[ "plotwindow_h" ], settings[ "plotwindow_x" ], settings[ "plotwindow_y" ]) )
        else:
            demfile = gpd.DEMWrite( plots, terminaloptions='persist title "gnuplot/plot.py %d"' % (os.getpid()) )
    else:
        demfile = gpd.DEMWrite( plots, options.terminal )

###
    #os.execl( "gnuplot", input_name + ".dem", "-" )

    if ( options.terminal == "x11" ):
        # interactive with input from stdin
        os.system( "gnuplot " +  demfile.name + " -" )
        try:
            (plotwindow_x, plotwindow_y, plotwindow_w, plotwindow_h, plotwindow_id) = GetPlotWindowGeometry()
            SaveSettings( settings, None, plotwindow_x, plotwindow_y, plotwindow_w, plotwindow_h, do_close=True )
            os.system( "xkill -id %s" % (plotwindow_id) )
        except AttributeError:
            dbg << "could not get plot window pos\n"
            pass
    else:
        os.system( "gnuplot " +  demfile.name )
        #os.system( '"C:\\Program Files\\gnuplot\\bin\\wgnuplot.exe" ' +  demfile.name )
    dbg << "after os.system\n"
    #
    #----------------------------

# end of main
######################################################################

if __name__ == "__main__":
    #import pdb
    #pdb.runcall( main )
    #main()

    from pyschunk.tools import attach_to_debugger
    attach_to_debugger.AttachToDebugger( main )


## end of file  ***
##########################################################################
##########################################################################

######################################################################
# some usefull editing settings for emacs:
#
#;;; Local Variables: ***
#;;; mode:python ***
#;;; End: ***
#
######################################################################
