'''
Created on 01.06.2016

@author: DiplMe2
'''
import pyschunk.smpcom.smpmodule
import pyschunk.smpcom.smp_message
import pyschunk.smpcom.smp_codes
import pyschunk.smpcom.smptools
import pyschunk.smpcom.smp_message_id


def ScanBus(options, return_first = False):
    """
    Scans the bus for available CAN IDs and returns a list with the available ones

    \param options - interface options
    \param return_first - if set: only the first found member id get returned
    """
    scan_variable = 0
    drive_ids=[]

    try:
        """The sending process fails if there are no modules on the bus.
        The receiving process fails if there are members on the bus but the member hasn't the current id."""

        searched_drive = pyschunk.smpcom.smpmodule.cSMPModule( options, scan_variable, timeout=0.001 )#eingetragener Bug: timeout hier bewirkt nichts
        searched_drive.iface._prop_SetTimeout(0.001)#very important to set the timeout
        searched_drive.request_id  = pyschunk.smpcom.smp_message_id.cSMPMessageID()
        searched_drive.request_id.is_module_id  = True
        searched_drive.request_id.from_module   = False
        searched_drive.request_id.is_normal     = True
        searched_drive.response_id = pyschunk.smpcom.smp_message_id.cSMPMessageID()
        searched_drive.response_id.is_module_id = True
        searched_drive.response_id.from_module  = True
        searched_drive.response_id.is_normal    = True

        #check if there are members
        searched_drive.request_id.module_id = scan_variable
        request = pyschunk.smpcom.smp_message.cSMPMessage( searched_drive.request_id, pyschunk.smpcom.smp_codes.eCmdCode.GET_CONFIG)#Es kann auch jeder beliebige andere Befehl gesendet werden
        searched_drive.iface.Send( request )

        #check for the ids of the members
        for i in range(256):  # @UnusedVariable

            scan_variable = i

            try:
                #looks a bit confusing but manipulating the existing cSMPModule object is much much faster then initializing a new one for every module id (can id)

                # set up default request and response IDs
                searched_drive.request_id.module_id     = scan_variable

                searched_drive.response_id.module_id    = scan_variable
                searched_drive.module_id = scan_variable


                #adding can id to the existing interface
                can_id = searched_drive.response_id.GetByte(0) << 8 | searched_drive.response_id.GetByte(1)
                try:
                    searched_drive.iface.cif.canIdAdd( can_id )
                except:
                    #can id was already added
                    pass

#                 searched_drive = pyschunk.smpcom.smpmodule.cSMPModule( options, scan_variable, timeout=0.001 )#much slower then manipulating the existing one

                searched_drive.iface._prop_SetTimeout(0.05)
                searched_drive.AssertUser( pyschunk.smpcom.smptools.eUserType.USER_PROFI, options.passwords ) #@UndefinedVariable

                print( "Found member with ID %r"%scan_variable )

                drive_ids.append(scan_variable)

                if return_first == True:
                    break

            except IOError:
                #no member with this id
                pass

    except IOError:
        print( "No members on bus" )

    return drive_ids
