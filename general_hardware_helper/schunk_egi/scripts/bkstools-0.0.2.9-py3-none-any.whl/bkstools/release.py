# -*- coding: latin-1 -*-
#######################################################################
#
## \file
#  \section bkstools_release_py_general General file information
#
#    \author   Dirk Osswald
#    \date     2018-11-19
#
#  \brief
#    Definition and documentation of the project name and the release
#    name ("version") of the package
#
#  \section bkstools_release_py_copyright Copyright
#
#  Copyright (c) 2018 SCHUNK GmbH & Co. KG
#
#  <HR>
#  \internal
#
#    \subsection bkstools_release_py_details SVN related, detailed file specific information:
#      $LastChangedBy: DirkOsswald $
#      $LastChangedDate: 2018-10-16 14:11:19 +0200 (Tue, 16 Oct 2018) $
#      \par SVN file revision:
#        $Id$
#
#  \subsection bkstools_release_py_changelog Changelog of this file:
#      \include release.py.log
#
#######################################################################

#######################################################################
## \anchor bkstools_release_py_python_vars
#  \name   Python specific variables
#
#  Some definitions that describe the module for python.
#
#  @{

__doc__       = """Definition and documentation of the project name and the release name ("version") for bkstools"""  # @ReservedAssignment
__author__    = "Dirk Osswald: dirk.osswald@de.schunk.com"
__url__       = "http://www.schunk.com"
__version__   = "$Id$"
__copyright__ = "Copyright (c) 2018 SCHUNK GmbH & Co. KG"

#  end of doxygen name group bkstools_release_py_python_vars
#  @}
######################################################################

######################################################################
# Define some variables

## \brief Name of the software "SCHUNK Python Modules" project.
#
#  \anchor project_name_bkstools
#  The name of the project
#
#    \internal
#    \remark
#    - This name is extracted by the makefile and then used by doxygen:
#      - As name of the project within the generated documentation.
#      - As base name of the generated install directory and pdf files.
#    - The name should \b NOT contain spaces!
#
PROJECT_NAME = "bkstools"

## \brief Release name of the whole software project (a.k.a. as the \e "version" of the project).
#
#    \anchor project_release_bkstools
#    The release name of the project.
#
#    A suffix of "-dev" indicates a work in progress, i.e. a not yet finished release.
#    A suffix of "-a", "-b", ... indicates a bugfix release.
#
#    From newest to oldest the releases have the following names and features:
#
#    - \b 0.0.2.9 2021-08-09
#      - first release to use new pyschunk after splitting off pyschunk_build_tools
#      - prepared for release to customer
#        - made package generation work for windows and linux
#        - Scripts are now actually installed and directly callable after proper package installation
#        - clean-up of code, README.md and integrated documentation
#        - corrected all shebang lines to make calling work on Windows/Cygwin and Linux
#        - refactored / renamed to get a more consistent naming scheme
#          - bkstools/* -> bkstools/bks_lib/*
#          - bkstools/bksmodule -> bkstools/bks_lib/bks_module
#          - bkstools/scripts/egi* -> bkstools/scripts/bks*
#        - Added demo_simple example. Added demo scripts to py2exe generation.
#        - Added bks_grip script to make gripping available from command line
#        - Enabled bks_move to perform relative movements and include pauses in movement sequences
#
#    - \b 0.0.2.8 2021-08-04
#      - big speed up of egi_status by caching egi.fieldbus_type and reading all of plc_sync_input and plc_sync_output only once per callback
#      - in branch plc_handshake_upgrade
#        now using new bits repeat_command_toggle and command_received_toggle
#      - improved handling of error response ABP_ERR_UNSUP_CMD in egi_status. now error is reported in statusline, not on console as backtrace
#      - egi_status: re-reading of outputs from gripper can now be switched off
#
#    - \b 0.0.2.7 2020-05-07
#      - corrected bit definitions for grip_workpiece_with_position according to latest changes in spec
#      - corrected/completed definitions for new/changed status bits now_part/workpiece_detected, pre_gripping, workpiece_lost, wrong_workpiece_detected according to latest changes in spec
#
#    - \b 0.0.2.6 2020-03-10
#      - added --debugjson command line parameter to simplify debugging of json communication
#      - moved BKS.session object to BKS._session and added BKS.session_get and BKS.session.post to
#        make adding of debug outputs in one place simpler
#      - reduced communication by caching values, e.g. build_info which was read multiple times
#      - adjusted internal_params.anybus_state to internal_params.comm_state as indicated by the firmware
#      - improved recording to gpd in egi
#        - made recording of system_state_application_state and system_state_motion_engine_state and their proper decoding work again
#        - added support to record and properly decode internal_params.comm_state (anybus_state)
#        - pauses in recording, e.g. due to reset or loss of access rights are now properly shown in plot
#      - added -p command line parameter to egi_get_error_messages to be able to cyclically update error messages
#      - added -nostrip command line parameter to egi_get_error_messages to be able to turn off automatic stripping of spaces of error messages
#      - corrected usage of control_dword and status_dword bits for Ethernet/IP grippers in egi.py and for users of BKSModule
#      - added debug.Debug() and debug.Error() functions which print to stderr instead of stdout to simplify debuggung
#      - added support for EGL-C with Modbus by determining fieldbus_type from gripper/info.json
#
#    - \b 0.0.2.5 2020-02-12
#      - continuing development based on python3.7 on trunk, merged all changes from python3.7 branch
#      - incorporated changed parameter names from BKS firmware since 2020-02-06
#
#    - \b 0.0.1.5: 2019-12-12
#      - corrected requirements in setup.py for python and pyschunk
#      - final (?) release of BKSTools using python2.7
#
#    - \b 0.0.2.4: 2019-12-12
#      - made get request failed error messages appear only once for each parameter index. Avoids cluttered output for release firmware when run with operator rights
#
#    - \b 0.0.2.3: 2019-12-03
#      - fixed error when accessing an EGL-C with egi_status which used fieldbus_type paramter, which does not exist on EGL-C
#
#    - \b 0.0.2.2: 2019-12-02
#      - Changed shebang line to make it work with python3. Now "python3win" must be somewhere in the path.
#      - changed type of display for reserved dword in plc_input_data from unsigned to signed for Thomas' EGL-C
#
#    - \b 0.0.2.1: 2019-11-19
#      - merged R23743, R23773, R23937 from trunk
#      - made generation of exes with py2exe work with python3.7
#
#    - \b 0.0.1.4: 2019-11-18
#      - refactored attach_to_debugger to pyschunk for easy reuse
#      - made egi_status work with newest changes on byte order for PROFINET/ EthernNet/IP controlword / statusword
#
#    - \b 0.0.1.3: 2019-10-28
#      - egi_ref now waits for a reference movement to end. Allows to use other scripts directly afterwards, e.g. in shell or batch scripts
#      - added new aliases for fieldbus_input/output_frame for EGL-C (modified for Ethernet/IP)
#
#    - \b 0.0.2.0: 2019-10-18
#      - ported all code to Python3.7
#
#    - \b 0.0.1.2: 2019-09-24
#      - improved distinguishing Ethernet/IP (and other busses with reversed byte order) by using the dataformat field of the info.json response
#      - renamed parameters according to new naming scheme
#
#    - \b 0.0.1.1: 2019-09-16
#      - BKSTools now supports bloody Ethernet/IP bricks which use little endian for Ints and floats in the JSON data
#
#    - \b 0.0.1.0: 2019-09-02
#      - auto generated enum changes according to current scheme used in release 2 of EGI
#        - renamed hsm_enums.EGI_Statemachine to hsm_enums.application_state_machine accordingly
#      - added minor support for EGL-C which uses a HMS custom Profinet brick with same synchronous data ADIs but different names
#      - egi_status:
#        - The Entry widgets for non writable data (like acutal_position, ... error_code) are now readonly
#        - cursor keys in Entry widget does not jog anymore
#        - to unfocus from an Entry widget use Esc key or klick on a readonly Entry
#
#    - \b 0.0.0.9: 2019-07-26
#      - refactored demo stuff into new demo sub-package
#      - added bks_module with more convenience functions
#      - moved PLCReorder() into bks module for easy reuse
#      - catching more insufficient read / write exceptions. Needed to operate with current user == OPERATOR, e.g. in release builds.
#      - errors setting desired_acceleration is silently ignored in egi_jog and egi_move for easy use with release builds and current_user = operator
#      - removed setting of desired current since no longer possible
#      - added proper handling of ControlledFromAnotherChannel errors from gripper, mainly in egi_jog ad egi_status
#      - egi_jog now aligns shown values better for better readability
#      - egi_status now has a status line to show errors (like ControlledFromAnotherChannel)
#      - added bks_gui with common gui stuff. For now there is just a new common base class cAppWithExceptionHandler
#        that simplifys establishing a common exception handling
#
#    - \b 0.0.0.8: 2019-06-04
#      - moved uint32_to_int32() and int32_to_uint32() to bks.py for easy reuse
#      - bugfix to send array parameters with one request instead of separate requests for each array element
#        required to work around bug EGI-6151 https://schunk.polarion.com/polarion/#/project/3199_EGI/workitem?id=EGI-6151
#
#    - \b 0.0.0.7: 2019-05-22
#      - adjusted order of error code and warning code in cyclic plc data according to bug EGI-5911
#      - corrected display of negative positions
#
#    - \b 0.0.0.6: 2019-05-20
#      - egi_status.py
#        - now works with with old as well as with new cyclic data (which is no longer stored using structured data but arrays of dwords instead)
#      - correced bug in bks.BKS.get_value() when working with arrays
#
#    - \b 0.0.0.5: 2019-05-10
#      - increased timetout for webinterface read ot 0.75, since there were timeouts with 0.5
#      - egi.py
#        - gpd output can now use absolute or relative time (via command line or interactively)
#        - gpd title can be entered interactively along with the s command while running
#        - german umlaut in title will now be translated to something that gnpulot can display
#      - egi_status.py
#        - added control bit setup area to prepare multiple bits to be set/cleared at once
#        - added Control-Click handling to actual control bits to be able to set all control bits with a single click
#        - title bar now shows the firmware version, date and actual user
#
#    - \b 0.0.0.4: 2019-03-28
#      - corrected helptext of demo_egi_aussen_innengreifen.py
#      - improved egi_status jog mode bits can now be controlled by shortcut cursor left/right
#      - egi_status status_bits are now disabled and do not set their corresponding command bits when clicked
#      - corrected usage of get and post calls to use a requests Session object now.
#        This should allow the reuse of TCP connections and should thus increase
#        performance and avoid the 10048 error
#      - unified bks.requests timeout handling to use a long connect timeout and a short read timeout
#      - egi.py improvements:
#        - improved gpd output for error_code and warning_code which is now inserted as label at bottom
#        - added output of application state machine and motion engine state decoded as labels at bottom
#        - no more error and exit on timeout, instead try to reconnect
#        - special handling for state of internal state machines
#        - absolute time and time of day is now saved to output as well for easy correlation to other data sources (but not shown as plot in gpd)
#        - the time of a record is now taken after all data has been collected. This avoids largely inacurate timestamps on disconnect/reconnect
#        - you can now switch between CSV an GPD output interactively
#        - you can now reprint the help interactively
#        - made output of CSV format work at all
#        - made output mode for x seconds (instead of continuous with a recording windows of x seconds) work at all
#        - added --speparator and --use_comma command line options for easy import into german EXCEL
#        - added timestamp output in interactive mode for events like disconnect/reconnect, saving of file
#
#
#    - \b 0.0.0.3: 2019-03-20
#      - added support for structured parameters
#      - added support for reading enum names via JSON from gripper
#      - improved support for arrays
#      - moved Str2Value to bks module for better reusability
#      - egi_jog.py
#        - now supports fast_stop via F12 or Pause
#        - displays the anybus_state, the is_supervised_by_plc and the error_code
#        - no more auto acknowledge when jogging. Errors have to be acknowledged by pressing Q
#      - added egi_status.py to emulate or observe a PLC connected via Profinet
#      - added egi_tst.py for quick internal testing
#      - egi.py
#        - added support for reading/writing of (parts of) arrays and structs
#        - improved help text accordingly
#      - updated hsm_enums.py with newest values from firmware
#      - adapted parameter names used by egi_jog and egi_status to newest checked in version of firmware with official support for structured parameters
#      - char array parameters are now returned as string again
#      - errors due to insufficient write rights are now signaled by InsufficientWriteRights exception
#      - The IP or name of the device connected to is now displayed in title bar of egi_jog and egi_status GUI
#      - updated hsm_enums from firmware
#      - corrected handling of setting string parameters
#      - corrected dependencies since requestes package is required
#      - corrected setting of default velocity and acceleration in egi_jog due to new minimal feasible values for these
#      - corrected handling of missing enum descriptions. Now "?" is printed instead of raising ValueError.
#      - corrected handling of insufficient read rights in egi_jog
#      - added egi_ping.py to measure ping response time. But this is very inaccurate and should be done by a real PLC
#      - added demo_egi_aussen_innengreife.py to simplify tracing of bug https://schunk.polarion.com/polarion/redirect/project/3199_EGI/workitem?id=EGI-5454
#      - improved egi_jog.py, now firmware version and current user are displayed as well as the warning code
#      - improved egi.py
#        - recording of the last X seconds can now be triggered interactively
#        - control_dword and status_dword are now separated into their bits on output for easy interpretation
#
#    - \b 0.0.0.2: 2018-12-20
#      - improved egi script to handle new command line parameters --period, --cycles, --gpd, --gpdtitle
#      - host to connect to can now be set via environment variable BKS_HOST
#      - made attach_to_debugger work only if environment variable PYDBG is set
#      - made -v option output version of pyschunk and frozen-state as well
#      - moved MultilineFormatter for argparse from BKSTools to pyschunk since its usefull in other projects as well
#      - added egi_jog.py
#      - added egi_get_error_messages.py
#      - improved attach_to_debugger to not try to enable debugging when run as a py2exe generated exe
#      - egi.py -l can now cope with inaccessible parameter values due ot insufficient rights
#      - added support for setting string values
#      - improved egi_jog for better interactivity:
#        - commands with parameters are shown while parameter value is entered
#        - automatic "," to "." conversion
#        - smaller fonts
#        - acknowledge is now on Key "Q"
#        - CTRL-M/V/A/C is can now be used to enter the desired_X parameter only without invoking an actual movement
#        - Parameter value entering regards backspace in the expected way
#        - Parameter value entering can ba canceled by Esc
#
#    - \b 0.0.0.1: 2018-11-30
#      - Initial "release" of the code for Stefan Schulz
#      - Scripts egi, egi_move and egi_ref are working
#
PROJECT_RELEASE = "0.0.2.9"

## \brief Date of the release of the software project.
#
#    \anchor project_date_bkstools
#    The date of the release of the project.
#
PROJECT_DATE = "2021-08-09"
