# -*- coding: iso-8859-1 -*-
#-------------------------------------------------------------------------------
# esd gmbh
#
#
#
#
#-------------------------------------------------------------------------------
# import pyQt            # spaeter vielleicht mal
import sys
import re
import time
import struct
import pyschunk.release
import os
import platform

try:
    # Without importing readline we have the following weired behaviour in windows shells:
    # Input read with "raw_input" will miss the last character entered by the user.
    # But by importing readline (and disabling its startup message) raw_input works as
    # expected. Donnowhy.
    import readline
    readline._issued = True
except ImportError:
    pass

# functions
"""

"""

# Baudrates
CANOPEN_1000kBd = 0
CANOPEN_666kBd = 1
CANOPEN_500kBd = 2
CANOPEN_333kBd = 3
CANOPEN_250kBd = 4
CANOPEN_166kBd = 5
CANOPEN_125kBd = 6
CANOPEN_100kBd = 7
CANOPEN_66kBd = 8
CANOPEN_50kBd = 9
CANOPEN_33kBd = 10
CANOPEN_20kBd = 11
CANOPEN_12kBd = 12
CANOPEN_10kBd = 13

# Baudrates
Baudrate =\
{\
    CANOPEN_1000kBd : "1000 kBd",\
    CANOPEN_666kBd : "666.6 kBd",\
    CANOPEN_500kBd : "500 kBd",\
    CANOPEN_333kBd : "333.3 kBd",\
    CANOPEN_250kBd : "250 kBd",\
    CANOPEN_166kBd : "166.6 kBd",\
    CANOPEN_125kBd : "125 kBd",\
    CANOPEN_100kBd : "100 kBd",\
    CANOPEN_66kBd : "66.6 kBd",\
    CANOPEN_50kBd : "50 kBd",\
    CANOPEN_33kBd : "33 kBd",\
    CANOPEN_20kBd : "20 kBd",\
    CANOPEN_12kBd : "12.5 kBd",\
    CANOPEN_10kBd : "10 kBd",\
}\

baudrate_codes = {
    1000000: CANOPEN_1000kBd,
    666000:  CANOPEN_666kBd,
    500000: CANOPEN_500kBd,
    333000: CANOPEN_333kBd,
    250000: CANOPEN_250kBd,
    166000: CANOPEN_166kBd,
    125000: CANOPEN_125kBd,
    100000: CANOPEN_100kBd,
    66000: CANOPEN_66kBd,
    50000: CANOPEN_50kBd,
    33000: CANOPEN_33kBd,
    20000: CANOPEN_20kBd,
    12000: CANOPEN_12kBd,
    10000: CANOPEN_10kBd
}

def GetBaudrateCode( baudrate ):
    return baudrate_codes[ baudrate ]

def print2lines():
    print()
    print()

def print3lines():
    print()
    print()
    print()

def print4lines():
    print()
    print()
    print()

def print5lines():
    print()
    print()
    print()

def l2c(l):
    '''\return the 32 bit value \a l as 4 bytes with high byte first (big endian/motorola format)
    '''
    d0 = (l >> 24) & 0xFF
    d1 = (l >> 16) & 0xFF
    d2 = (l >> 8) & 0xFF
    d3 = (l >> 0) & 0xFF
    return d0, d1, d2, d3

def l2cr(l):
    '''\return the 32 bit value \a l as 4 bytes with low byte first (little endian/intel format)
    '''
    d0 = (l >> 24) & 0xFF
    d1 = (l >> 16) & 0xFF
    d2 = (l >> 8) & 0xFF
    d3 = (l >> 0) & 0xFF
    return d3,d2,d1,d0

def c2l(d0, d1, d2, d3):
    '''\return the 4 bytes \a d0,d1,d2,d3 with high byte first (big endian/motorola format) as 32 bit value
    '''
    l = ((d0 & 0xFF) << 24) + ((d1 & 0xFF) << 16) + ((d2 & 0xFF) << 8) + ((d3 & 0xFF))
    return l

def c2lr(d3, d2, d1, d0):
    '''\return the 4 bytes \a d3,d2,d1,d0 with low byte first (little endian/intel format) as 32 bit value
    '''
    l = ((d0 & 0xFF) << 24) + ((d1 & 0xFF) << 16) + ((d2 & 0xFF) << 8) + ((d3 & 0xFF))
    return l

def w2c(w):
    '''\return the 16 bit value \a w as 2 bytes with high byte first (big endian/motorola format)
    '''
    d0 = (w >> 8) & 0xFF
    d1 = (w >> 0) & 0xFF
    return d0, d1

def w2cr(w):
    '''\return the 16 bit value \a w as 2 bytes with low byte first (little endian/intel format)
    '''
    d0 = (w >> 8) & 0xFF
    d1 = (w >> 0) & 0xFF
    return d1, d0

def c2w(d0, d1):
    '''\return the 2 bytes \a d0,d1 with high byte first (big endian/motorola format) as 16 bit unsigned value
    '''
    w = ((d0 & 0xFF) << 8) + (d1 & 0xFF)
    return w

def c2wr(d1, d0):
    '''\return the 2 bytes \a d0,d1 with with low byte first (little endian/intel format) as 16 bit unsigned value
    '''
    w = ((d0 & 0xFF) << 8) + (d1 & 0xFF)
    return w

def c2i16(d0, d1):
    '''\return the 2 bytes \a d0,d1 with high byte first (big endian/motorola format) as 16 bit signded value
    '''
    w = ((d0 & 0xFF) << 8) + (d1 & 0xFF)
    if ( w > 0x7fff ):
        w = -(0x10000 - w);
    return w

def c2i16r(d1, d0):
    '''\return the 2 bytes \a d0,d1 with with low byte first (little endian/intel format) as 16 bit signed value
    '''
    w = ((d0 & 0xFF) << 8) + (d1 & 0xFF)
    if ( w > 0x7fff ):
        w = -(0x10000 - w);
    return w


def c2i32(d0, d1, d2, d3):
    '''\return the e bytes \a d0,d1,d2,d3 with high byte first (big endian/motorola format) as 32 bit signded value
    '''
    dw = ((d0 & 0xFF) << 24) + ((d1 & 0xFF) << 16) + ((d2 & 0xFF) << 8) + (d3 & 0xFF)
    if ( dw > 0x7fffffff ):
        dw = -(0x100000000 - dw);
    return int(dw)

def c2i32r(d0, d1, d2, d3):
    '''\return the 4 bytes \a d0,d1,d2,d3 with with low byte first (little endian/intel format) as 32 bit signed value
    '''
    dw = ((d3 & 0xFF) << 24) + ((d2 & 0xFF) << 16) + ((d1 & 0xFF) << 8) + (d0 & 0xFF)
    if ( dw > 0x7fffffff ):
        dw = -(0x100000000 - dw);
    return int(dw)


def c2f(d0, d1, d2, d3):
    '''\return the 4 bytes \a d0,d1,d2,d3 with low byte first (little endian/intel format) as 32 bit float value
    '''
    return struct.unpack('f', bytes( (d0,d1,d2,d3) ) )[0]

def f2c( f ):
    '''\return the float \a f as a list of 4 bytes \a d0,d1,d2,d3 with low byte first (little endian/intel format)
    '''
    return [ b for b in struct.pack('f', f) ]

def f2i32( f ):
    '''\return the float \a f as a int32
    '''
    return struct.unpack( "i", struct.pack('f', f) )[0]

def i322f(i32):
    '''\return the 32 bits in \a i32 (little endian/intel format) as 32 bit float value
    '''
    return struct.unpack('f', bytes( (i32 & 0xff, (i32>>8)& 0xff, (i32>>16)& 0xff, (i32>>24)& 0xff) ) )[0]


def s2c(l):
    d0 = (l >> 8) & 0xFF
    d1 = (l >> 0) & 0xFF
    d2 = d3 = 0
    return d0, d1, d2, d3

def c2s(d0, d1):
    s = ((d0 & 0xFF) << 8) + ((d1 & 0xFF))
    return s


def psleep(t):
    print( "Wait %fs ..." % t )
    time.sleep(t)

def sleep(t):
    time.sleep(t)






def file_dict(name, sep="="):
    f = open(name, 'r')
    c = f.read()
    f.close()
    regex = '((\w+)\s*%s[ \t\f\v]*(("[^"]*")|(\S*))[^\n]*\n)' % sep
    result = dict([(x[1], x[2].strip('"').strip()) for x in re.findall(regex, c)])
    return result

"""
if len(sys.argv) == 2:
    print file_to_dict(sys.argv[1],"[:=]")
"""



def base10toN(num, n):
    """Change a  to a base-n number.
    Up to base-36 is supported without special notation."""
    num_rep = {10:'a',
         11:'b',
         12:'c',
         13:'d',
         14:'e',
         15:'f',
         16:'g',
         17:'h',
         18:'i',
         19:'j',
         20:'k',
         21:'l',
         22:'m',
         23:'n',
         24:'o',
         25:'p',
         26:'q',
         27:'r',
         28:'s',
         29:'t',
         30:'u',
         31:'v',
         32:'w',
         33:'x',
         34:'y',
         35:'z'}
    new_num_string = ''
    current = num
    while current != 0:
        remainder = current % n
        if 36 > remainder > 9:
            remainder_string = num_rep[remainder]
        elif remainder >= 36:
            remainder_string = '(' + str(remainder) + ')'
        else:
            remainder_string = str(remainder)
        new_num_string = remainder_string + new_num_string
        current = current // n
    return new_num_string



def baseconvert(n, base):
    """convert positive decimal integer n to equivalent in another base (2-36)"""

    digits = "0123456789abcdefghijklmnopqrstuvwxyz"

    try:
        n = int(n)
        base = int(base)
    except:
        return ""

    if n < 0 or base < 2 or base > 36:
        return ""

    s = ""
    while 1:
        r = n % base
        s = digits[r] + s
        n = n // base
        if n == 0:
            break

    return s




def q(cond, on_true, on_false):
    from inspect import isfunction

    if cond:
        if not isfunction(on_true): return on_true
        else: return on_true
    else:
        if not isfunction(on_false): return on_false
        else: return on_false


def GetEnvironmentOrDefault( name, default ):
    '''Try to read an environment variable named \a name.
    If available return its value, if not return \a default
    '''
    if ( name in os.environ ):
        return os.environ[name]
    return default


from optparse import OptionParser, Values
class cCANOptionParser(OptionParser):
    '''OptionParser with some default options already set:
    -d LEVEL | --debug LEVEL set debug level to LEVEL
    -v | --version print version and exit
    '''
    def ShowVersion(self, option, opt, value, parser):  # @UnusedVariable
        print(self.version)
        print("%s: v-%s (%s)" % (pyschunk.release.PROJECT_NAME, pyschunk.release.PROJECT_RELEASE, pyschunk.release.PROJECT_DATE))
        print("Python version: %s" % (platform.python_version()) )
        print("Python compiler: %s" % (platform.python_compiler()) )
        print("Platform: %s" % (platform.platform() ) )

        sys.exit()

    # use this as default_nodes in CTor to suppress interactive querying for node numbers
    DONT_QUERY_NODES=-1

    def __init__(self, usage = "", version = "", default_nodes=None, passwords_default="", passwords_help="", logger=None ):
        '''CTor, create a cCANOptionParser instance.

        usage has the usual meaning and version is the string that is printed
        when -v | --version option is set
        '''
        OptionParser.__init__( self, usage )
        self.version = version
        if ( logger is None ):
            import pyschunk.tools.mylogger
            self.logger = pyschunk.tools.mylogger.getLogger( __name__ )
        else:
            self.logger = logger

        # add common options:
        self.add_option( "-n", "--nodes",
                         dest="nodes", type=str, metavar="NODENUMBERS", default=default_nodes,
                         help='Node numbers to listen to. Examples: "3", "3,4,5", "3-5". Use "0" to scan for all nodes available. Will be queried interactively if not given on command line.' )
        self.add_option( "-d", "--debug",
                         dest="debug_level", default=0, type=int, metavar="LEVEL",
                         help="Enable printing of debug messages of level LEVEL or lower. Default is 0, no debug messages.")
        self.add_option( "-v", "--version",
                         action="callback", callback=self.ShowVersion,
                         help="Print the version and exit.")
        self.add_option( "-b", "--baud", "--baudrate",
                         dest="baudrate", default=GetEnvironmentOrDefault( "COT_BAUDRATE", 500000), type=int, metavar="BAUDRATE",
                         help="CAN baudrate to use in bit/s. If not given the value of the COT_BAUDRATE environment variable is used. If that is not given then the default value of 500000 is used." )
        self.add_option( "-N", "--net",
                         dest="net", default=GetEnvironmentOrDefault( "COT_NET", 0), type=int, metavar="NET",
                         help="Use the ESD CAN net number NET. If not given the value of the COT_NET environment variable is used. If that is not given then the default value of 0 is used." )
        self.add_option( "--nq", "--noqueryend",
                         dest="no_query_end", default=GetEnvironmentOrDefault( "COT_NOQUERYEND", False), action="store_true",
                         help="Do not query for return key in the end. (For direct command line use). If not given then the availability of the COT_NOQUERYEND environment variable is checked." )
        self.add_option( "--force_first_sdo_server",
                         dest="force_first_sdo_server", default=GetEnvironmentOrDefault( "COT_FORCE_FIRST_SDO_SERVER", False), action="store_true",
                         help="Force use of the primary SDO server, even im the secondary is available. If not given then the availability of the COT_FORCE_FIRST_SDO_SERVER environment variable is checked." )
        if ( passwords_help != "" ):
            self.add_option( "--password",
                             dest="passwords", default=passwords_default, type=str, metavar="PASSWORDS",
                             help=passwords_help )

    def parse_args(self, args=None, values=None):
        '''Overloaded parse_args.
        \return (options,args) according to command line args or \a args \a values
        - Additionally the call will be logged
        - Additionally options.baudrate_code will be set
        - If no nodes are given then these are queried from stdin
        - Additionally options.user_set_option will be a dictionary for all options values
          to indicate which option was actually given from the user (and not from the default value)

        '''
        if ( self.logger ):
            if ( args is None ):
                the_args = sys.argv
            else:
                the_args = args
            self.logger.info( "Parsing args %r" % (the_args))

        (user_set_values, forget) = OptionParser.parse_args(self, args=args, values=Values())  # @UnusedVariable
        #if ( args is None ):
        #    args = sys.argv[1:]
        (options, args) = OptionParser.parse_args(self, args, values)

        options.baudrate_code = baudrate_codes[ options.baudrate ]

        if ( self.has_option( "--EGI") and options.egi ):
            # set dummy node number to 1 for EGI
            options.nodes = 1

        if ( self.has_option("-n") and options.nodes is None ):
            print("Please specify the node numbers of the nodes to access. Use:")
            print('- a single number ("3"),')
            print('- a comma separated list of numbers ("3,4,5")')
            print('- or a range of numbers ("3-5")')
            print('- or "0" to scan for all nodes')
            if ( self.has_option( "--EGI") ):
                print('- or "e" or "E" to show debug messages of an EGI')

            sys.stdout.flush()
            sys.stderr.flush()
            options.nodes = input('--> ').strip()

            if ( self.has_option( "--EGI") and options.nodes in [ "e", "E", "egi", "EGI" ] ):
                options.egi = True
                options.nodes = 1

        if ( str(options.nodes) == "0" ):
            # search for nodes
            print("Scanning for nodes...")
            try:
                from pyschunk.canopen import esdcanopen
                sdo = esdcanopen.SDO( options.net, options.baudrate_code, force_first_sdo_server=options.force_first_sdo_server ) # (net,baudrate,RxQS,RxTO,TxQS,TxTO)

                node_nos = sdo.ScanForNodes( list(range(1, 128)), 0x6041, 0 )
                print("Found nodes: %r" % node_nos)
                options.nodes= str(node_nos)[1:-1].replace(" ","")
            finally:
                try:
                    del sdo.cif
                except:
                    pass
                try:
                    del sdo
                except:
                    pass

        if ( type( options.nodes ) == str ):
            options.nodes = options.nodes.lstrip( "=" )

        if ( not options.no_query_end ):
            import pyschunk.tools.util
            pyschunk.tools.util.EnableConfirmExit()

        options.logfile = None
        if ( self.has_option( "-l" ) ):
            self.parse_args_logfile( options )

        # If a password contains chars like "`" then python3win or bash or cmd
        # cannot handle these properly, therefore the user can replace them
        # with "\\\\x60". The code below evaluates that back to a normal string.
        if ( "passwords" in options.__dict__ and r"\x" in options.passwords ):
            options.passwords = eval( '"' + options.passwords + '"' )

        # for compatibility with smpcom.cSMPComOptionParser:
        options.debug_output=sys.stderr
        options.debug_output_receive=sys.stderr
        options.debug_output_send=sys.stderr
        options.do_show_version = False
        options.interface = "canesd%d" % options.net
        options.savestettings = False

        options.user_set_option = dict()
        for k in list(options.__dict__.keys()):
            options.user_set_option[k] = k in user_set_values.__dict__

        return (options,args)


    def parse_args_logfile( self, options ):
        '''additional parsing for handling logfile
        '''
        if ( options.logfilename != "" ):
            if ( "{date}" in options.logfilename ):
                now = time.time()
                date = time.strftime( "%Y-%m-%d_%H-%M", time.localtime( now ) )
                options.logfilename = options.logfilename.replace( "{date}", date )
            if ( options.logfilename.startswith( "+" ) ):
                options.logfile = open( options.logfilename[1:], "a", 1 ) # append data, line buffered
            else:
                options.logfile = open( options.logfilename, "w", 1 ) #(re)create file, line buffered


    def add_option_logfile( self ):
        '''Add an option to specify a filename for a log file, see also the helptext below.
        If called then the self.parse_args() will handle the logfilename and recreate or append
        the logfile as options.logfile.
        '''
        self.add_option( "-l", "--logfile",
                         dest="logfilename", default="", type=str, metavar="FILENAME",
                         help="""Log messages to FILENAME as well as to stdout.
                         If FILENAME starts with '+' then the output will
                         be appended to the file (without the leading '+'), else the file will be (re)created.
                         If FILENAME contains '{date}' (without quotes) then that part will be replaced with the current data and time.
                         """ )

def ExplainErrorRegister( er ):
    '''Return a string explaining the 0x1001/0 error_register value \er
    '''
    result = ""
    sep = ""
    if ( er & 0x01 ):
        result = "Generic"
        sep = "+"
    if ( er & 0x02 ):
        result += sep + "Current"
        sep = "+"
    if ( er & 0x04 ):
        result += sep + "Voltage"
        sep = "+"
    if ( er & 0x08 ):
        result += sep+"Temperature"
        sep = "+"
    if ( er & 0x10 ):
        result += sep + "Communication"
        sep = "+"
    if ( er & 0x20 ):
        result += sep + "Device profile specific"
        sep = "+"
    if ( er & 0x40 ):
        result += sep + "(reserved)"
        sep = "+"
    if ( er & 0x80 ):
        result += sep + "manufacturer-specific"

    if ( result == "" ):
        result = "No"
    result += " error"
    return result

def ExplainErrorCode( ec ):
    '''Return a string describing the CANopen error code \a ec
    according to  DS301 and DS402. See also
    - file://D:/home/osswald2/SCHUNK/CANopen/doc/CiA/301_v04020005_complete#page=70
    - file://D:/home/osswald2/SCHUNK/CANopen/doc/CiA/iec61800-7-201{ed1.0}en.pdf#page=35
    '''
    if ( ec == 0x0000 ):
        return "Error reset or no error"
    elif ( ec == 0x1000 ):
        return "Generic error"
    elif ( ec == 0x0000 ):
        return "Error reset or no error"
    elif ( ec == 0x1000 ):
        return "Generic error"
    elif ( ec == 0x2000 ):
        return "Current � generic error"
    elif ( ec == 0x2100 ):
        return "Current, CANopen device input side � generic"
    elif ( ec == 0x2200 ):
        return "Current inside the CANopen device � generic"
    elif ( ec == 0x2300 ):
        return "Current, CANopen device output side � generic"
    elif ( ec == 0x3000 ):
        return "Voltage � generic error"
    elif ( ec == 0x3100 ):
        return "Mains voltage � generic"
    elif ( ec == 0x3200 ):
        return "Voltage inside the CANopen device � generic"
    elif ( ec == 0x3300 ):
        return "Output voltage � generic"
    elif ( ec == 0x4000 ):
        return "Temperature � generic error"
    elif ( ec == 0x4100 ):
        return "Ambient temperature � generic"
    elif ( ec == 0x4200 ):
        return "Device temperature � generic"
    elif ( ec == 0x5000 ):
        return "CANopen device hardware � generic error"
    elif ( ec == 0x6000 ):
        return "CANopen device software � generic error"
    elif ( ec == 0x6100 ):
        return "Internal software � generic"
    elif ( ec == 0x6200 ):
        return "User software � generic"
    elif ( ec == 0x6300 ):
        return "Data set � generic"
    elif ( ec == 0x7000 ):
        return "Additional modules � generic error"
    elif ( ec == 0x8000 ):
        return "Monitoring � generic error"
    elif ( ec == 0x8100 ):
        return "Communication � generic"
    elif ( ec == 0x8110 ):
        return "CAN overrun (objects lost)"
    elif ( ec == 0x8120 ):
        return "CAN in error passive mode"
    elif ( ec == 0x8130 ):
        return "Life guard error or heartbeat error"
    elif ( ec == 0x8140 ):
        return "recovered from bus off"
    elif ( ec == 0x8150 ):
        return "CAN-ID collision"

    elif ( ec == 0x8200 ):
        return "Protocol error - generic"
    elif ( ec == 0x8210 ):
        return "PDO not processed due to length error"
    elif ( ec == 0x8220 ):
        return "PDO length exceeded"
    elif ( ec == 0x8230 ):
        return "DAM MPDO not processed, destination object not available"
    elif ( ec == 0x8240 ):
        return "Unexpected SYNC data length"
    elif ( ec == 0x8250 ):
        return "RPDO timeout"
    elif ( ec == 0x9000 ):
        return "External error � generic error"
    elif ( ec == 0xF000 ):
        return "Additional functions � generic error"
    elif ( ec == 0xFF00 ):
        return "Device specific � generic error"

    elif ( ec == 0x2110 ):
        return "Short circuit/earth leakage (input)"
    elif ( ec == 0x2120 ):
        return "Earth leakage (input)"
    elif ( ec == 0x2121 ):
        return "Earth leakage phase L1"
    elif ( ec == 0x2122 ):
        return "Earth leakage phase L2"
    elif ( ec == 0x2123 ):
        return "Earth leakage phase L3"
    elif ( ec == 0x2130 ):
        return "Short circuit (input)"
    elif ( ec == 0x2131 ):
        return "Short circuit phases L1-L2"
    elif ( ec == 0x2132 ):
        return "Short circuit phases L2-L3"
    elif ( ec == 0x2133 ):
        return "Short circuit phases L3-L1"
    elif ( ec == 0x2211 ):
        return "Internal current no.1"
    elif ( ec == 0x2212 ):
        return "Internal current no.2"
    elif ( ec == 0x2213 ):
        return "Over-current in ramp function"
    elif ( ec == 0x2214 ):
        return "Over-current in the sequence"
    elif ( ec == 0x2220 ):
        return "Continuous over current (device internal)"
    elif ( ec == 0x2221 ):
        return "Continuous over current no.1"
    elif ( ec == 0x2222 ):
        return "Continuous over current no.2"
    elif ( ec == 0x2230 ):
        return "Short circuit/earth leakage (device internal)"
    elif ( ec == 0x2240 ):
        return "Earth leakage (device internal)"
    elif ( ec == 0x2250 ):
        return "Short circuit (device internal)"
    elif ( ec == 0x2310 ):
        return "Continuous over current"
    elif ( ec == 0x2311 ):
        return "Continuous over current no.1"
    elif ( ec == 0x2312 ):
        return "Continuous over current no.2"
    elif ( ec == 0x2320 ):
        return "Short circuit/earth leakage (motor-side)"
    elif ( ec == 0x2330 ):
        return "Earth leakage (motor-side)"
    elif ( ec == 0x2331 ):
        return "Earth leakage phase U"
    elif ( ec == 0x2332 ):
        return "Earth leakage phase V"
    elif ( ec == 0x2333 ):
        return "Earth leakage phase W"
    elif ( ec == 0x2340 ):
        return "Short circuit (motor-side)"
    elif ( ec == 0x2341 ):
        return "Short circuit phases U-V"
    elif ( ec == 0x2342 ):
        return "Earth leakage phase V-W"
    elif ( ec == 0x2343 ):
        return "Earth leakage phase W-U"
    elif ( ec == 0x2350 ):
        return "Load level fault (I2t, thermal state)"
    elif ( ec == 0x2351 ):
        return "Load level warning (I2t, thermal state)"
    elif ( ec == 0x3110 ):
        return "Mains over-voltage"
    elif ( ec == 0x3111 ):
        return "Mains over-voltage phase L1"
    elif ( ec == 0x3112 ):
        return "Mains over-voltage phase L2"
    elif ( ec == 0x3113 ):
        return "Mains over-voltage phase L3"
    elif ( ec == 0x3120 ):
        return "Mains under-voltage"
    elif ( ec == 0x3121 ):
        return "Mains under-voltage phase L1"
    elif ( ec == 0x3122 ):
        return "Mains under-voltage phase L2"

    elif ( ec == 0x3123 ):
        return "Mains under-voltage phase L3"
    elif ( ec == 0x3130 ):
        return "Phase failure"
    elif ( ec == 0x3131 ):
        return "Phase failure L1"
    elif ( ec == 0x3132 ):
        return "Phase failure L2"
    elif ( ec == 0x3133 ):
        return "Phase failure L3"
    elif ( ec == 0x3134 ):
        return "Phase sequence"
    elif ( ec == 0x3140 ):
        return "Mains frequency"
    elif ( ec == 0x3141 ):
        return "Mains frequency too great"
    elif ( ec == 0x3142 ):
        return "Mains frequency too small"
    elif ( ec == 0x3210 ):
        return "DC link over-voltage"
    elif ( ec == 0x3211 ):
        return "Over-voltage no. 1"
    elif ( ec == 0x3212 ):
        return "Over voltage no. 2"
    elif ( ec == 0x3220 ):
        return "DC link under-voltage"
    elif ( ec == 0x3221 ):
        return "Under-voltage no. 1"
    elif ( ec == 0x3222 ):
        return "Under-voltage no. 2"
    elif ( ec == 0x3230 ):
        return "Load error"
    elif ( ec == 0x3310 ):
        return "Output over-voltage"
    elif ( ec == 0x3311 ):
        return "Output over-voltage phase U"
    elif ( ec == 0x3312 ):
        return "Output over-voltage phase V"
    elif ( ec == 0x3313 ):
        return "Output over-voltage phase W"
    elif ( ec == 0x3320 ):
        return "Armature circuit"
    elif ( ec == 0x3321 ):
        return "Armature circuit interrupted"
    elif ( ec == 0x3330 ):
        return "Field circuit"
    elif ( ec == 0x3331 ):
        return "Field circuit interrupted"
    elif ( ec == 0x4110 ):
        return "Excess ambient temperature"
    elif ( ec == 0x4120 ):
        return "Too low ambient temperature"
    elif ( ec == 0x4130 ):
        return "Temperature supply air"
    elif ( ec == 0x4140 ):
        return "Temperature air outlet"
    elif ( ec == 0x4210 ):
        return "Excess temperature device"
    elif ( ec == 0x4220 ):
        return "Too low temperature device"
    elif ( ec == 0x4300 ):
        return "Temperature drive"
    elif ( ec == 0x4310 ):
        return "Excess temperature drive"
    elif ( ec == 0x4320 ):
        return "Too low temperature drive"
    elif ( ec == 0x4400 ):
        return "Temperature supply"
    elif ( ec == 0x4410 ):
        return "Excess temperature supply"
    elif ( ec == 0x4420 ):
        return "Too low temperature supply"
    elif ( ec == 0x5100 ):
        return "Supply"
    elif ( ec == 0x5110 ):
        return "Supply low voltage"
    elif ( ec == 0x5111 ):
        return "U1 = supply �15V"
    elif ( ec == 0x5112 ):
        return "U2 = supply +24 V"
    elif ( ec == 0x5113 ):
        return "U3 = supply +5 V"
    elif ( ec == 0x5114 ):
        return "U4 = manufacturer-specific"
    elif ( ec == 0x5115 ):
        return "U5 = manufacturer-specific"
    elif ( ec == 0x5116 ):
        return "U6 = manufacturer-specific"

    elif ( ec == 0x5117 ):
        return "U7 = manufacturer-specific"
    elif ( ec == 0x5118 ):
        return "U8 = manufacturer-specific"
    elif ( ec == 0x5119 ):
        return "U9 = manufacturer-specific"
    elif ( ec == 0x5120 ):
        return "Supply intermediate circuit"
    elif ( ec == 0x5200 ):
        return "Control"
    elif ( ec == 0x5210 ):
        return "Measurement circuit"
    elif ( ec == 0x5220 ):
        return "Computing circuit"
    elif ( ec == 0x5300 ):
        return "Operating unit"
    elif ( ec == 0x5400 ):
        return "Power section"
    elif ( ec == 0x5410 ):
        return "Output stages"
    elif ( ec == 0x5420 ):
        return "Chopper"
    elif ( ec == 0x5430 ):
        return "Input stages"
    elif ( ec == 0x5440 ):
        return "Contacts"
    elif ( ec == 0x5441 ):
        return "Contact 1 = manufacturer-specific"
    elif ( ec == 0x5442 ):
        return "Contact 2 = manufacturer-specific"
    elif ( ec == 0x5443 ):
        return "Contact 3 = manufacturer-specific"
    elif ( ec == 0x5444 ):
        return "Contact 4 = manufacturer-specific"
    elif ( ec == 0x5445 ):
        return "Contact 5 = manufacturer-specific"
    elif ( ec == 0x5450 ):
        return "Fuses"
    elif ( ec == 0x5451 ):
        return "S1 = l1"
    elif ( ec == 0x5452 ):
        return "S2 = l2"
    elif ( ec == 0x5453 ):
        return "S3 = l3"
    elif ( ec == 0x5454 ):
        return "S4 = manufacturer-specific"
    elif ( ec == 0x5455 ):
        return "S5 = manufacturer-specific"
    elif ( ec == 0x5456 ):
        return "S6 = manufacturer-specific"
    elif ( ec == 0x5457 ):
        return "S7 = manufacturer-specific"
    elif ( ec == 0x5458 ):
        return "S8 = manufacturer-specific"
    elif ( ec == 0x5459 ):
        return "S9 = manufacturer-specific"
    elif ( ec == 0x5500 ):
        return "Hardware memory"
    elif ( ec == 0x5510 ):
        return "RAM"
    elif ( ec == 0x5520 ):
        return "ROM/EPROM"
    elif ( ec == 0x5530 ):
        return "EEPROM"
    elif ( ec == 0x6010 ):
        return "Software reset (watchdog)"
    elif ( ec == 0x6301 ):
        return "to 630Fh        Data record no. 1 to no. 15"
    elif ( ec == 0x6310 ):
        return "Loss of parameters"
    elif ( ec == 0x6320 ):
        return "Parameter error"
    elif ( ec == 0x7100 ):
        return "Power"
    elif ( ec == 0x7110 ):
        return "Brake chopper"
    elif ( ec == 0x7111 ):
        return "Failure brake chopper"
    elif ( ec == 0x7112 ):
        return "Over current brake chopper"
    elif ( ec == 0x7113 ):
        return "Protective circuit brake chopper"
    elif ( ec == 0x7120 ):
        return "Motor"
    elif ( ec == 0x7121 ):
        return "Motor blocked"
    elif ( ec == 0x7122 ):
        return "Motor error or commutation malfunc."
    elif ( ec == 0x7123 ):
        return "Motor tilted"
    elif ( ec == 0x7200 ):
        return "Measurement circuit"
    elif ( ec == 0x7300 ):
        return "Sensor"
    elif ( ec == 0x7301 ):
        return "Tacho fault"
    elif ( ec == 0x7302 ):
        return "Tacho wrong polarity"
    elif ( ec == 0x7303 ):
        return "Resolver 1 fault"
    elif ( ec == 0x7304 ):
        return "Resolver 2 fault"
    elif ( ec == 0x7305 ):
        return "Incremental sensor 1 fault"
    elif ( ec == 0x7306 ):
        return "Incremental sensor 2 fault"
    elif ( ec == 0x7307 ):
        return "Incremental sensor 3 fault"
    elif ( ec == 0x7310 ):
        return "Speed"
    elif ( ec == 0x7320 ):
        return "Position"
    elif ( ec == 0x7400 ):
        return "Computation circuit"
    elif ( ec == 0x7500 ):
        return "Communication"
    elif ( ec == 0x7510 ):
        return "Serial interface no. 1"
    elif ( ec == 0x7520 ):
        return "Serial interface no. 2"
    elif ( ec == 0x7600 ):
        return "Data storage (external)"
    elif ( ec == 0x8300 ):
        return "Torque control"
    elif ( ec == 0x8311 ):
        return "Excess torque"
    elif ( ec == 0x8312 ):
        return "Difficult start up"
    elif ( ec == 0x8313 ):
        return "Standstill torque"
    elif ( ec == 0x8321 ):
        return "Insufficient torque"
    elif ( ec == 0x8331 ):
        return "Torque fault"
    elif ( ec == 0x8400 ):
        return "Velocity speed controller"
    elif ( ec == 0x8500 ):
        return "Position controller"
    elif ( ec == 0x8600 ):
        return "Positioning controller"
    elif ( ec == 0x8611 ):
        return "Following error"
    elif ( ec == 0x8612 ):
        return "Reference limit"
    elif ( ec == 0x8700 ):
        return "Sync controller"
    elif ( ec == 0x8800 ):
        return "Winding controller"
    elif ( ec == 0x8900 ):
        return "Process data monitoring"
    elif ( ec == 0x8A00 ):
        return "Control"
    elif ( ec == 0xF001 ):
        return "Deceleration"
    elif ( ec == 0xF002 ):
        return "Sub-synchronous run"
    elif ( ec == 0xF003 ):
        return "Stroke operation"
    elif ( ec == 0xF004 ):
        return "Control"
    elif ( 0xFF00 <= ec and ec <= 0xFFFF ):
        return "Manufacturer-specific"
    else:
        return "Unknown error code"

def CMSG_ToString( cmsg ):
    r = ""
    r += "id=0x%03x " % cmsg.id
    r += "len=%r " % cmsg.len
    r += "msg_lost=%r " % cmsg.msg_lost
    #r += "reserved=%r " % cmsg.reserved
    r += "data.c=0x[%02x,%02x,%02x,%02x,%02x,%02x,%02x,%02x]" % (cmsg.data.c[0],cmsg.data.c[1],cmsg.data.c[2],cmsg.data.c[3],cmsg.data.c[4],cmsg.data.c[5],cmsg.data.c[6],cmsg.data.c[7])
    return r