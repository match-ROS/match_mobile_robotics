#
#

import copy
from pyschunk.smpcom import smp_types
from pyschunk.smpcom import smp_message_id
from pyschunk.smpcom import smp_codes

# constructor variants for named cSMPMessage elements:
#
# v0: name is given as keyword parameter to cSMPMessage ctor.
#     --- !!! Does not work since keyword arguments are processed in undefined order!!!
#     + would be really intuitive
#   msg = cSMPMessage( mid=cSMPMessageID(),
#                      mode=cUInt16(),
#                      pos=cFloat() )
#
# v1: name is given as name parameter to element:
#     + works
#     - name has to be given as string
#     - if value is not given name has to be given as name="NAME" -> much to write
#   msg = cSMPMessage( cSMPMessageID( name="mid" ),
#                      cUInt16( name="mode" ),
#                      cFloat( name="pos" ) )
#
# v2: name is given as keyword parameter to element:
#     + works
#     + name can be given as name
#     + cSMPType objects can be created before and reused
#     - a value must always be provided
#   msg = cSMPMessage( cSMPMessageID( mid=None ),
#                      cUInt16( mode=0 ),
#                      cFloat( pos=0.0 ) )
#   or:
#   mode = cUInt16( mode=0 )
#   pos  = cFloat( pos=0.0 )
#   msg  = cSMPMessage( cSMPMessageID(), mode, pos )
#
# v3: message elements are given as (name,element) pairs:
#     + works
#     + name is known only to cSMPMessage object, not to ctor parameters
#     + more intuitive than v1-v2?
#     - name must be given as string
#     - extra parentheses needed
#   msg = cSMPMessage( ("mid",  cSMPMessageID()),
#                      ("mode", cUInt16()),
#                      ("pos",  cFloat()) )
#
# v4: message elements are not given to constructor but to Add() function one by one:
#     + works
#     + name is known only to cSMPMessage object, not to ctor of cSMPType parameters
#     + name can be given as named parameter
#     - extra function calls needed
#   msg = cSMPMessage()
#   msg.Add( mid=cSMPMessageID() )
#   msg.Add( mode=cUInt16() )
#   msg.Add( pos=cFloat() )
#
#   or
#   msg = cSMPMessage()
#   msg.Add( mid=cSMPMessageID() ).Add( mode=cUInt16() ).Add( pos=cFloat() )
#
#
# v4a: message elements are not given to constructor but to << operator one by one:
#    -- does not work (syntactially, see experimetnts/operator_keywordargs.py)
#     + name is known only to cSMPMessage object, not to ctor parameters
#     + name can be given as named parameter
#     - extra parentheses needed
#   msg = cSMPMessage() << mid=cSMPMessageID() << mode=cUInt16() << pos=cFloat()
#
# v5: message elements are not given to constructor but added one by one:
#     + works
#     + name is known only to cSMPMessage object, not to ctor of cSMPType parameters
#     + name can be given as named parameter
#     + no extra function calls needed
#   msg = cSMPMessag()
#   msg.mid  = cSMPMessageID()
#   msg.mode = cUInt16()
#   msg.pos  = cFloat()
#
#
#Solution: use v2 and v4 and v5

class cSMPMessage(object):
    ''' class for representing SMP messages
    '''

    def __init__( self, *args, **kwargs ):
        ''' Ctor taking a list of arguments and/or keyword arguments that form the SMP message to construct
        Arguments can be of type:
        - cSMPMessageId (only for first arg)
        - int (interpreted as smp_types.cUInt8)
        - float (interpreted as smp_types.cFloat)
        - or some object of the cSMPType class hierarchy
          (which can have a name that is then added as member of that name
           to the cSMPMessage object as well)

        Apart from specifying named or unnamed parameters in the constructor
        these can be added later with Add() or simply as object.NEW_NAME=value as well.
        '''
        self.named_parameters = dict() # dictionary of named parameters
        self.data = []                 # list of parameters, including message ID, but not d_len
        self.Add( *args, **kwargs )
        self.crc_calculated = None     # only used for RS232
        self.crc_read = None           # only used for RS232

        # tell our own set attribute handler that we are fully constructed,
        # so that new members get added to self.named_parameters and not to self.__dict__
        self._constructed = True

    def Clone( self ):
        ''' Clone self and return copy in new object
        '''
        # For named parameters there are multiple references to the same object
        # in self.data and self.named_parameters, so a simple copy or deepcopy
        # will not work. So construct a new message from self:
        new_msg = cSMPMessage()
        for d in self.data:
            found = False
            for (name,value) in self.named_parameters.items():
                if ( d is value ):
                    new_msg.Add( **{ name : value } )
                    found = True
                    break

            if ( not found ):
                new_msg.Add( d )
        return new_msg


    def GetFilledLength(self, peek_byte_list=None ):
        '''Return the length of the message in bytes if it were filled with all parameters.
        This includes the message id.

        \remark
        - strings of variable length are counted with length 1
        '''
        result = 0
        for d in self.data:
            if ( peek_byte_list is None ):
                remaining_peek_byte_list = None
            else:
                remaining_peek_byte_list = peek_byte_list[ result: ]
            result += d.GetFilledLength( remaining_peek_byte_list )
        return result


    def _get_d_len( self ):
        ''' get d_len property: number of parameter bytes excluding message ID and d_len itself
        '''
        if ( len( self.data ) <= 1 ):
            return 0
        return sum( map( lambda d: d.d_len, self.data[1:] ) )

    d_len = property( _get_d_len, None, None, "d_len, number of parameter bytes in self excluding message ID and d_len itself" )


    def Add( self, *args, **kwargs ):
        '''Either:
        - Add (copy of) \a arg from \a args to list of data items
        - Or add a named keyword argument from \a kwargs as named parameter to self.
          Only one keyword argument parameter may be given per call
          (since you cannot determine the user given order of keyword arguments)

        \a arg can be of type
        - smp_message_id.cSMPMessageId (only first element for self.data)
        - int (interpreted as smp_types.cUInt8)
        - float (interpreted as smp_types.cFloat)
        - or some object of the cSMPType class hierarchy

        \return self (to allow calls like msg.Add( mid=cSMPMessageID() ).Add( mode=cUInt16() ).Add( pos=cFloat() )
        '''
        if ( len( kwargs ) > 1 ):
            raise NameError( "Only one keyword argument may be given at a time (since I cannot determine their order). Specify the name within the cSMPType object." )

        for a in args:
            self._Add( None, a )

        for (name,value) in kwargs.items():
            self._Add( name, value )

        return self


    def _Add( self, name, arg ):
        '''Internal helper function: convert \a arg to a cSMPType and add the (possibly named) parameter to self.

        - int args are converted to cUInt8
        - float args are converted to cFloat
        - string args are converted to cString (variable length)
        - if arg is already a cSMPType then a copy of arg is added to self
        - for lists and tuples self.Add is called recursively for each element
        '''
        if ( type(arg) == smp_message_id.cSMPMessageID and self.data != [] ):
            raise ValueError( "cSMPMessageID may only be given as first data element" )

        if ( type(arg) == smp_message_id.cSMPMessageID ):
            copy_of_arg = copy.copy(arg)
            self._AddcSMPType( name, copy_of_arg )
        elif ( type(arg) == int ):
            v = smp_types.cUInt8( arg )
            v.name = name
            self._AddcSMPType( name, v )
        elif ( type(arg) == float ):
            v = smp_types.cFloat( arg )
            v.name = name
            self._AddcSMPType( name, v )
        elif ( type(arg) == str ):
            v = smp_types.cString( arg )
            v.name = name
            self._AddcSMPType( name, v )
        elif ( isinstance( arg, smp_types.cSMPType ) ):
            v = copy.copy(arg )
            self._AddcSMPType( name, v )
        elif ( type(arg) in [ tuple,list ] ):
            for a in arg:
                self.Add(a)
        else:
            raise TypeError( "argument %r has invalid type %s" % (arg,type(arg)) )

        # if first 2 data elements were given as bytes instead of cSMPMessageID then
        # convert these
        if ( type(self.data[0]) != smp_message_id.cSMPMessageID  and  self.GetFilledLength() >= 2 and type( self.data[0] ) == smp_types.cUInt8 and  type( self.data[1] ) == smp_types.cUInt8 ):
            old_data = self.data
            message_id = smp_message_id.cSMPMessageID( self.data[0].value, self.data[1].value )
            self.data = []
            self._AddcSMPType( "id", message_id )
            self.data += old_data[2:]


    def _AddcSMPType( self, name, arg ):
        ''' Add cSMPType \a arg to self. If \a name is not None or \a arg has a
        name then that name is added as a member of self which references \a arg.

        - If both \a name and \a arg.name are given then these must match else a
          NameError is raised.
        - If a name is given but is already present as a member of self then
          a NameError is raised as well.
        '''
        # append arg to the list of data elements
        self.data.append( arg )

        # find the name to use (if any) from the given parameter name and from arg.name:
        if ( hasattr( arg, "name" ) and arg.name is not None ):
            if ( name is not None and name != arg.name ):
                raise NameError( "given name %r is different from arg.name %r" % (name,arg.name) )
            name = arg.name

        # check and add the name to the named parameters
        if ( name is not None ):
            if ( name in self.named_parameters ):
                raise NameError( "name %r already used as member of self" % (name) )
            self.named_parameters[name] = arg
        # make sure that the name is stored in arg as well
        arg.name = name

        # check validity of given data
        if ( self.GetFilledLength() >= 3  and  type( self.data[0] ) is not smp_message_id.cSMPMessageID ):
            raise ValueError( "First data parameter (message ID) must be a cSMPMessageID but is a %r!" % (type(self.data[0])) )
        if ( self.GetFilledLength() >= 3  and  type( self.data[1] ) is not smp_types.cUInt8 ):
            raise ValueError( "Second data parameter (command code) must be a cUInt8  but is a %r!" % (type(self.data[1])) )

        # attach default names for specific data elements
        if ( type( arg ) is smp_message_id.cSMPMessageID  and  name != "id" ):
            # add the message ID under default name "id" as well (pointing to same object)
            self.named_parameters[ "id" ] = arg

        if ( self.GetFilledLength() == 3 and type( arg ) is smp_types.cUInt8  and  name != "cmd" ):
            # add the command code under default name "cmd" as well (pointing to same object)
            self.named_parameters[ "cmd" ] = arg


    # see http://frcchang.blogspot.com/2008/03/python-note-difference-between-getattr.html
    def __getattr__(self,name):
        if ( name in self.named_parameters ):
            # for named parameters return the stored cSMPType.value, not the cSMPType itself
            return self.named_parameters[name].value
        else:
            raise AttributeError( "No such attribute named %r!" % name )


    def __setattr__(self,name,value):
        '''Internal helper: Replacement for __setattr__ that redirects
        attribute setting or adding to self.named_parameters after construction is finished.
        '''
        if ( "_constructed" not in self.__dict__ ):
            # so use base class setattr until self is fully constructed
            object.__setattr__(self, name, value)

        if ( name in self.named_parameters ):
            # for known named parameters store the value into their cSMPType.value, not into the cSMPType itself
            self.named_parameters[name].value = value
        else:
            if ( hasattr( self, name ) ):
                # self has an attribute name
                # so use base class setattr to set it
                object.__setattr__(self, name, value)
            else:
                # name is not yet known, so add it to the named parameters
                self._Add( name, value )


    def GetByteString(self):
        ''' \return self as string of bytes
        '''
        result = ""
        for d in self.data:
            if d.HasData():
                result += d.GetByteString()
        return result


    def GetByteList(self):
        ''' \return self as list of bytes
        '''
        result = []
        for d in self.data:
            if d.HasData():
                result += d.GetByteList()
        return result


    def GetName(self, element ):
        '''\return the name of the named element from self.data or "unnamed" in case element is not named.
        Will throw ValueError in case element is not in self.data.
        Element must be identical (not equal) to an element in self.data.
        '''
        for (name,value) in self.named_parameters.items():
            if ( element is value ):
                return name

        for d in self.data:
            if d is element:
                return "unnamed"

        raise ValueError( "Unknown element %r" % element )



    def FromBytes(self, *args ):
        ''' set \a self according to \a args,

        \a args can be an arbitrary argument list containing any iterable object containing bytes (string, list of ints, tuple of ints, ...)

        \return self  (in order to allow something like msg=cSMPMessage().FromBytes( "\x01\x02\0x03" )
        '''
        the_bytes = smp_types.ArgsToByteList( *args )
        if ( self.data == [] ):
            # no data in self, so just reinit from the_bytes
            self.Add( *the_bytes )
        else:
            # already data (placeholders) in self, so insert the byte into the appropriate objects

            i=0
            for d in self.data:
                # clear d before filling it with new data from the_bytes
                d.Clear()

                nb_remaining_bytes = len(the_bytes) - i
                remaining_bytes = the_bytes[i:]
                if (nb_remaining_bytes > 0 and nb_remaining_bytes < d.GetFilledLength(remaining_bytes)):
                    # there are remaining bytes but they are not enough for current object d
                    raise ValueError( "remaining %d bytes are not enough to fill placeholder parameter object of size %d bytes (parameter object number %d, named %r)" % (nb_remaining_bytes,d.GetFilledLength(remaining_bytes),i,d.name) )

                if (nb_remaining_bytes >= d.GetFilledLength(remaining_bytes)):
                    # there are remaining bytes and they are enough for current object d
                    ##if ( type( d ) is smp_types.cString ):
                    ##    d.FromBytes( *the_bytes[ i: ] )
                    ##else:
                    ##    d.FromBytes( *the_bytes[ i:i+d.GetFilledLength(remaining_bytes)] )
                    # even cString types should be able to tell the filled length...
                    d.FromBytes( *the_bytes[ i:i+d.GetFilledLength(remaining_bytes)] )
                    i += d.d_len
        return self


    def __str__(self):
        '''\return a string describing self
        '''
        try:
            d_len = int(self.d_len)
        except ValueError:
            # This can happen for messages containing cDTString elements with value ANY
            d_len = "?"

        s  = "cSMPMessage: id=%s  d_len=%r\n" % (str(map(int,self.id)),d_len)
        s += "  data="
        do_print_cmd = True
        do_print_error_code = (self.d_len == 2)
        for d in self.data[1:]:
            if ( d.value is smp_types.ANY ):
                s += " (ANY: " + "? " * d.GetFilledLength() + ") "
            elif ( type( d.value ) is list):
                s += " (one of %r: " % d.value + "? " * d.GetFilledLength() + ") "
            elif ( type( d.value ) is tuple):
                s += " (one in [%r..%r]: " % (d.value[0],d.value[1]) + "? " * d.GetFilledLength() + ") "
            else:
                for b in d.GetByteList():
                    if ( do_print_cmd ):
                        extra = " (%s)" % (smp_codes.eCmdCode.GetName( b ))
                        do_print_cmd = False
                    elif ( do_print_error_code ):
                        extra = " (%s)" % (smp_codes.eErrorCode.GetName( b ))
                        do_print_error_code = False
                    else:
                        extra = ""
                    s += " 0x%02x%s" % (b,extra)
        if ( not self.crc_read is None and not self.crc_calculated is None ):
            if ( self.crc_read == self.crc_calculated ):
                s += " CRC=0x%04x" % (self.crc_read)
            else:
                s += " CRC-read=0x%04x CRC-calculated=0x%04x!" % (self.crc_read, self.crc_calculated)
        elif ( not self.crc_read is None ):
            s += " CRC-read=0x%04x" % (self.crc_read)
        elif ( not self.crc_calculated is None ):
            s += " CRC-calculated=0x%04x" % (self.crc_calculated)
        return s


    def __repr__(self):
        '''For more informative output in failed assertions: return a string describing self
        '''
        return "\n" + self.__str__()



    def __eq__( self, other ) :
        '''Compare self with other, return True if the data bytes contained
        in self are the same as those contained in other.

        \attention self and other may differ in their named parameters!
        '''
        if ( self.d_len != other.d_len ):
            return False
        for (sb,ob) in zip(self.GetByteList(),other.GetByteList()):
            if sb != ob:
                return False
        return True


    def MatchedBy( self, other ):
        '''Test if other matches self.
        Usefull if self has parameters that are not given explicitly, but as ANY, [list of allowed values] or (min,max) range

        \return (matches,mismatch_msg) tuple where
        - \a matches is a boolean that indicates if other matches self
        - \a mismatch_msg if matches is False then this is a message string that further explains the mismatch
        '''
        has_any_cDTString = False
        for d in self.data + other.data:
            if ( type( d ) is smp_types.cDTString  and  d.value is smp_types.ANY ):
                has_any_cDTString = True
                break

        if ( not has_any_cDTString and self.d_len != other.d_len ):
            return (False,"self.d_len = %d != %d = other.d_len" % (self.d_len,other.d_len))

        # in case self.data contains multi byte elements then we have to "aggregate" bytes from other before matching:
        self_index = 0
        other_index = 0
        for se in self.data:
            if ( type( se ) is smp_types.cDTString  and  se.value is smp_types.ANY ):
                # A cDTString with value ANY must be handled differently as its d_len cannot be determined from self, instead only from other
                if ( type( other.data[ other_index ] ) is smp_types.cDTString ):
                    # other data is already a cDTString
                    oe = other.data[ other_index ]
                else:
                    obl = []
                    other_index_first = other_index
                    assert( other.data[ other_index ].d_len == 1 )
                    actual_string_len = other.data[ other_index ].value
                    while len(obl) <= actual_string_len:
                        obl += other.data[ other_index ].GetByteList() # will include the first byte with the actual string length in obl as well
                        other_index += 1

                    oe = copy.copy( se )
                    oe.FromBytes( *obl )

            else:
                obl = []
                other_index_first = other_index
                while len(obl) < se.d_len:
                    obl += other.data[ other_index ].GetByteList()
                    other_index += 1

                assert( len(obl) == se.d_len )

                oe = copy.copy( se )
                oe.FromBytes( *obl )

            (matches,mismatch_msg) = se.MatchedBy( oe )
            if ( not matches ):
                name = "unnamed"
                if ( hasattr( se, "name") ):
                    name = se.name
                return (False, "\nself.data[%d] (%r) did not match other.data[%d-%d]: %s" % (self_index,name,other_index_first,other_index-1,mismatch_msg))

            self_index += 1
        return (True,"")


    def __ne__( self, other ):
        return not self == other
