#!/usr/bin/env python
# -*- coding: latin-1 -*-
#######################################################################
#
## \file
#  \section microterm_py_general General file information
#
#    \author   Dirk Osswald
#    \date     2007-01-29
#
#  \brief
#     Very simple serial terminal
#
#     Source: pyserial the system independent serial port access module
#     An input line is read with readline and sent to the serial port on
#     return.  Commands can be edited with the cursor, delete, backspace,
#     insert keys. Previous commands, even from a previous session can be
#     reached with cursor up or CTRL-R. A history of lines is saved
#     in ~/.microtermhist and reread on the next invocation.
#
#     Input characters are sent
#     directly (only LF -> CR/LF/CRLF translation is done, if desired), received
#     characters are displayed as is (or as trough pythons repr, useful
#     for debug purposes) Baudrate and echo configuartion is done through
#     globals
#
#     Plot data sent by a node in GPD-format (Dirks GNUplot data) will
#     be automatically recorded to a file. Additionally "{date}" in the input
#     will be replaced by the current date. A new plot.py process will
#     be started for every plot received (only usefull when an X-Server is
#     running).
#
#     As communication channels the following are available:
#     -  "normal" RS232 ports
#     -  jtag_uart via the nios2-terminal program (if the jtagserial module is available).
#     -  CAN where data is sent on one ID and received on another (if the canserial module is available and an ESD CAN card, native Windows only)
#
#     Start the script with \c "-h" or \c "--help" command line option
#     to see the online help.
#
#  \section microterm_py_copyright Copyright
#
#     (C)2002-2004 Chris Liechti <cliecht@gmx.net>
#     (c)2007      Copyright (c) 2007 SCHUNK GmbH & Co. KG
#
#  <HR>
#  \internal
#
#    \subsection microterm_py_details SVN related, detailed file specific information:
#      $LastChangedBy: Osswald2 $
#      $LastChangedDate: 2016-02-23 14:09:45 +0100 (Tue, 23 Feb 2016) $
#      \par SVN file revision:
#        $Id$
#
#  \subsection microterm_py_changelog Changelog of this file:
#      \include microterm.py.log
#
#######################################################################
#

import sys

from pyschunk.tools.dbg import tDBG
import pyschunk.tools.util as util

dbg = tDBG( "-d" in sys.argv, "blue", description="pyschunk.scripts.microterm" )


# Try to import sdh.canserial: Will only work:
# - if using native windows python (not cygwin)
# - if using ESD CAN
# - if the ESD python wrapper is installed
try:
    import sdh.canserial
except ImportError:
    dbg <<  "Info: Importing python module 'sdh.canserial' failed,\n"
    dbg <<  "   CAN communication will not be available.\n"
    dbg <<  "   (Currently CAN support is only available in the \n"
    dbg <<  "    native windows python environment. Try e.g.:\n"
    dbg <<  "   /cygdrive/d/Programme/python2.5/python.exe ~/bin/microterm.py )\n"
    dbg.flush()

try:
    from sdh.jtagserial import cJTAGSerial
except ImportError:
    dbg <<  "Info: Importing python module 'jtagserial' failed,\n"
    dbg <<  "   JTAG communication will not be available.\n"
    dbg.flush()

import atexit
import os
import select

# native windows might not have a HOME environment variable
if   ( "HOME" in os.environ ):
    d = os.environ["HOME"]
elif ( "APPDATA" in os.environ ):
    d = os.environ["APPDATA"]

histfile = os.path.join(d, ".microtermhist")
dbg << "histfile=%r\n"%histfile

def myatexit(histfile):
    dbg << "This is myatexit(%r)\n" % histfile # gets never called when running from windows console
    dbg.flush()
    readline.write_history_file( histfile )
    dbg << "ok\n"
    dbg.flush()

if ( "--myreadline" in sys.argv ):
    import pyschunk.tools.myreadline as readline

    readline.read_history_file(histfile)
    atexit.register(myatexit, histfile)
    old_input = input
    input = readline.readline  # @ReservedAssignment

elif ( "--noreadline" in sys.argv ):
    histfile = None
else:
    try:
        # FIXed: this line below outputs 8 bytes 1b 5b 3f 31 30 33 34 68 which confuse latex
        # cannot be fixed internally (redirecting stdout does not help)
        # see also https://bugzilla.redhat.com/show_bug.cgi?id=593799
        # => workaround use "export TERM=dumb" in Makefile when generating online help
        import readline
        try:
            readline.read_history_file(histfile)
        except IOError:
            pass
        atexit.register(myatexit, histfile)
    except ImportError:
        dbg <<  "Info: Importing python module 'readline' failed, no command history available\n"

import serial  # @UnusedImport
import serial.tools.list_ports
import pyschunk.tools.util_thread
import getopt
import string
import time

# no longer needed to detect lost USB devices:
# try:
#     import usb.core
#     g_have_usb_core_find = True
#     # when libusb0 is used as backend then an SDHx stopped in the debugger
#     # will make the code here thinkt the device disconnected (which would
#     # still be ok, but it fails to reconnect properly ater SDHx runs again.
#     # So for the full featured auto-reconnect you need libusb-1.0.dll
# except ImportError:
#     dbg <<  "Info: Importing python module 'usb.core' failed,\n"
#     dbg <<  "  automatic USB reconnect will not be available.\n"
#     dbg.flush()
#     g_have_usb_core_find = False

try:
    persistent_settings = util.GetPersistantDict( name=".microterm3", cdbg = dbg )
except Exception:
    # can happen when the persistent dict was created with another python version
    dbg <<  "Info: Reading persistent settings failed,\n"
    dbg <<  "  no persistent data available.\n"
    dbg.flush()

######################################################################
#

import pyschunk.tools.util
prefix_keyboard = pyschunk.tools.util.GetColor("blue")
suffix_keyboard = pyschunk.tools.util.GetColor("normal")
prefix_serialin = pyschunk.tools.util.GetColor("normal")
suffix_serialin = pyschunk.tools.util.GetColor("normal")
prefix_message = pyschunk.tools.util.GetColor("green")
suffix_message = pyschunk.tools.util.GetColor("normal")
prefix_error = pyschunk.tools.util.GetColor("red")
suffix_error = pyschunk.tools.util.GetColor("normal")
prefix_warning = pyschunk.tools.util.GetColor("magenta")
suffix_warning = pyschunk.tools.util.GetColor("normal")
VT100_CLR_SCREEN = "\x1b[2J"

EXITCHARACTER = '\x04'   #ctrl+D


CONVERT_CRLF = 2
CONVERT_CR   = 1
CONVERT_LF   = 0

eModeAscii      = 0
eModeNumeric    = 1
eModeHexNumeric = 2



g_exiting = False
g_reader_thread = None
g_serialport = None

g_settings = None

def GetPrompt( settings ):
    if settings.usecan:
        return prefix_message + "CAN 0x%03x< " % (settings.id_read) + prefix_keyboard
    elif settings.usejtag:
        return prefix_message + "JTAG%s< " % (settings.jtag_processor) + prefix_keyboard
    else:
        if ( type(settings.port) == int ):
            return prefix_message + "COM%d< " % (settings.port+1) + prefix_keyboard
        else:
            return prefix_message + "%s< " % (settings.port) + prefix_keyboard

def hex2( n ):
    """Return the hexadecimal representation of an integer or long integer with 2 digits (hex2(5)->0x05)
    """
    return "0x%02x" % n

def cls():
    """Clear screen. Needed in windows console since that does not understand VT100 commands
    """
    os.system( "cls" )

class cTerminate( Exception ):
    '''Exception class to terminate reader / writer threads
    '''
    def __init__(self,args=None):
        Exception.__init__(self,args)

def NewPlotFile( plotfile, prefix ):
    if ( plotfile is not None ):
        dbg <<  "closing old file?\n"
        plotfile.close()

    now = time.localtime()
    suffix = "_%4d-%02d-%02d_%02d-%02d-%02d.gpd" % (now.tm_year, now.tm_mon, now.tm_mday, now.tm_hour, now.tm_min, now.tm_sec)
    plotfilename = prefix + suffix
    plotfile = open( plotfilename, "wb", 1 ) # 1 = line buffered. We must open in binaray mode else the '\r\n' received from the firmware will somehow be translated to '\r\r\n' in the output file!?!
    return (plotfilename, plotfile)


def reader():
    """loop forever and copy serial->console
    """
    try:
        global g_settings, g_serialport
        did_print = False

        plotfile = None

        # To catch ctrl sequences like VT100 "test presence":
        #
        #  according to http://www-user.tu-chemnitz.de/~heha/hs_freeware/terminal/terminal.htm#3
        #     query:  ESC [ 5 n     (test presence)
        #     answer: ESC [ 0 n
        #
        #   sent by dsacon32m on reset/startup:
        #     "\x1b\x5b\x35\x6e\x1b\x5b\x35\x6e\x1b\x5b\x35\x6e\x1b\x5b\x35\x6e"
        #   replied by hyperterminal:
        #     0x1b 0x5b 0x30 0x6e 0x1b 0x5b 0x30 0x6e

        #auto_reply = [ ("\x1b[5n\x1b[5n","\x1b[\x30\x1b[\x30") ]
        #auto_reply = [ ("\x1b[5n","\x1b[0n") ]
        auto_reply = [ (b"\x1b[5n",b"\x1b[0n") ]
        line = b""
        #starttime = time.time()
        time.sleep(1)
        #print( "starttime, time() = %f, %f" % (starttime,time.time()) )
        while 1:
            try:
                #data = g_serialport.read( g_settings.numeric_length )
                alldata = g_serialport.readline() # this is much less CPU intensive than above
            except IOError as e:
                sys.stdout.write( prefix_error + "Error while reading (ignored): " + str(e) + suffix_error + "\r\n" )
                sys.stdout.flush()
                time.sleep( 0.1 )
                continue
            except select.error as e:
                # happens when resizing the terminal window that we run in, so ignore it and start over
                continue

            # handle plot data
            if ( b"# combined gnuplot commands" in alldata ):
                (plotfilename,plotfile) = NewPlotFile( plotfile, g_settings.plotfileprefix )
                now = time.localtime()
                date = "%4d-%02d-%02d %02d:%02d:%02d" % (now.tm_year, now.tm_mon, now.tm_mday, now.tm_hour, now.tm_min, now.tm_sec)
                dbg << '<Starting new plotfile "%s">\n' % (plotfilename)

            if ( plotfile ):
                if ( b"{date}" in alldata ):
                    alldata = alldata.replace( b"{date}", date )
                plotfile.write( alldata )

                if ( b"# end of plot" in alldata ):
                    plotfile.close()
                    plotfile = None
                    dbg << '<plotfile finished>\n'

                if ( not g_settings.plot_show ):
                    continue

            # some output commands below cannot handle long data,
            # so forward in smaller chunks only
            i_forwarded = 0
            i_max       = len( alldata )
            while  i_forwarded < i_max:
                i_next = min( i_forwarded + 1024, i_max )
                data = alldata[i_forwarded: i_next]
                i_forwarded = i_next

                if ( len( data ) < 1 ):
                    if ( did_print ):
                        sys.stdout.write( g_settings.prompt )
                        sys.stdout.flush()
                        did_print = False
                    continue

                #print( "data =<", repr(data),"> type=", type(data) )

                if ( not did_print ):
                    sys.stdout.write( "\r\n" )
                    sys.stdout.flush()

                did_print = True


                #print( "caught %d bytes \r\n" % len(data) )
                # collect date in lines, because since SDH firmware release 0.0.1.10
                # the test presence query from the SDH is split into several data packets
                line += data
                lines = line.split( b"\r\n" )
                line = lines[-1]
                for (query,reply) in auto_reply:
                    for l in lines:
                        if (query in l):
                            #dbg <<  "tds received at %f\n" % (time.time()-starttime)  # FIX ME: removeme
                            #continue
                            dbg <<  prefix_warning + "autoreplying '%s' for '%s'\r\n" % (repr(reply), repr(query)) + suffix_warning
                            g_serialport.write( reply )
                            g_serialport.flush()
                            line = b"".join( line.split( query, 1 )) # remove query from line
                            continue

                # try to handle VT100 command to clear screen specially in
                # windows console which does not understand VT100 commands
                # (unfortunatily this does not work...)
                #if ( VT100_CLR_SCREEN in line and  "win32" in sys.platform ):
                #    cls()
                #print( "not autoreplying for data= %s" % repr(data) )


                if g_settings.repr_mode:
                    #dbg.var( "data" )
                    sys.stdout.write( prefix_serialin + repr(data)[1:-1] + suffix_serialin + "\n" )
                    sys.stdout.flush()
                else:
                    if g_settings.mode == eModeAscii:
                        sys.stdout.write( prefix_serialin + data.decode()  + suffix_serialin )
                        sys.stdout.flush()
                        if ( g_settings.input_log_file ):
                            g_settings.input_log_file.write( data )
                    else:
                        # one of the numeric modes

                        text = ""
                        # separate data into lines of length numeric_length
                        for l in [ data[ i : i+g_settings.numeric_length ] for i in range( 0, len(data), g_settings.numeric_length ) ]:

                            if g_settings.mode == eModeNumeric:
                                text = " ".join( map( str, map( ord, l ) ) )
                            if g_settings.mode == eModeHexNumeric:
                                text = " ".join( map( hex2, map( ord, data ) ) )

                            if g_settings.additional_ascii:
                                text = text.ljust( g_settings.numeric_length*5 + 3 )
                                for c in l:
                                    text += repr( c )[1:-1] + " "
                        text += "\r\n"

                        sys.stdout.write( prefix_serialin + text + suffix_serialin )
                        sys.stdout.flush()
                        if ( g_settings.input_log_file ):
                            g_settings.input_log_file.write( text )
                sys.stdout.flush()
    except KeyboardInterrupt:
        print( "reader caught KeyboardInterrupt" )
        sys.stdout.flush()
    except cTerminate as e:
        dbg << "reader: caught e=%r, terminating\n" % e
    except Exception as e:
        global g_exiting
        time.sleep(0.5)
        if (not g_exiting):
            dbg << "reader: caught e=%r, reraising\n" % e
            raise #reraise
        # when exiting e is ignored
    finally:
        dbg << "reader: finished\n"
        dbg.flush()

online_help = prefix_message + """
microterm onlinehelp:
F1 + RETURN: Show this help.
F2 + RETURN: Activate text mode:
             For "47 0x11" as input 8-9 bytes will be sent, the chars
             of the string plus linefeed chars.
F3 + RETURN: Activate numeric mode:
             For "47 0x11" as input 2 bytes will be sent, 42 and 17.
             For "256 65536" as input 5 bytes will be sent, 0,1, 0,0,1.
             I.E. little endian encoding with the fewest bytes necessary.
F4 + RETURN: Activate hex numeric mode
             For "47 11" as input 2 bytes will be sent, 71 and 17.
F5 + RETURN: Toggle additional ascii display in numeric mode
F6 + RETURN: Toggle prompt
F7 FILENAME + RETURN: save received data to file FILENAME
F7 + RETURN:          close a previously opened file
F8 FILENAME + RETURN: send data from file FILENAME
""" + suffix_message

def StringToInt( s, base=10 ):
    """return int of string s, e.g. 10 for "10" or "0xa"
    """
    if ( s[0:2] in [ "0x", "0X" ] ):
        return int( s, 16 )
    return int( s, base )


def HexStringToInt( s ):
    return StringToInt( s, 16 )


def SendFromFile( filename ):
    """send data from file filename to serial port.
    Data is sent as is with the following exceptions:
    - an empty line (2 consecutive newlines) make the sending pause until the RETURN key is pressed
    """
    try:
        input_data_file = open( filename, "r" )
    except IOError as e:
        dbg <<  "Could not open file %s: %s" % (filename, str(e) )
        sys.stdout.flush()

    lines = input_data_file.readlines()
    input_data_file.close()

    for l in lines:
        if ( l == "\n"  or l == "\r\n" ):
            time.sleep( 1.0 ) # give sdh2 time to answer previous command
            input( prefix_warning + "Press RETURN to continue sending recorded commands" + suffix_warning )
        sys.stdout.write( g_settings.prompt + l )
        sys.stdout.flush()
        g_serialport.write( l )

    time.sleep( 2.0 )
    sys.stdout.write( prefix_warning + "Sending of data from file '%s' finished" % filename + suffix_warning )
    sys.stdout.flush()

def GetLineEndOfLine( l ):
    '''Return a pair (ll,eol) where ll is the actual line content of l
    and eol is the end of line part (like '\n' or '\r\n') of l
    '''
    eol = ""
    while ( len(l) > 0  and  l[-1] in "\r\n" ):
        eol = l[-1] + eol
        l = l[:-1]

    return (l,eol)

def writer():
    """loop and copy console->serial until EOF character is found
    """
    global g_settings, g_serialport

    try:
        if ( g_settings.inputfilename ):
            inputfile = open( g_settings.inputfilename, "r" )
        def GetInput( prompt ):
            if ( g_settings.inputfilename ):
                return inputfile.readline()[:-1]
            else:
                #
                #return raw_input(prompt) # will print prompt after the input in mintty using cygwin python
                dbg << "writing prompt %r\n" % prompt
                sys.stdout.write( prompt )
                sys.stdout.flush()
                dbg << "now waiting for input \n"
                dbg.flush()
                return input() # does not work with readline on windows

#                 #old:
#                 #dbg << "writer entering raw_input\n"
#                 #return raw_input(prompt)
#                 #s = raw_input(prompt)
#                 sys.stdout.write( prompt )
#                 sys.stdout.flush()
#                 s = raw_input() # does not work with readline on windows
#                 #s = readline.readline(maxlen=maxlen)
#                 #dbg << "writer left raw_input\n"
#                 readline.write_history_file( histfile )
#                 return s

        while 1:
            l = GetInput(g_settings.prompt)
            dbg.var("l")
            while g_serialport is None:
                # the serial port could have been closed by the main thread,
                # e.g. if the USB virtual com port disappeared.
                # So wait until the main thread has opened the port again
                time.sleep(0.3)

            if ( g_settings.inputfilename and l == "" ):
                # end of file reached in inputfile
                inputfile.close()
                g_settings.inputfilename = None

            if ( l == "1~" ):
                sys.stdout.write( online_help )
                sys.stdout.flush()
                continue
            if ( l == "2~" ):
                g_settings.mode = eModeAscii
                g_settings.convert_outgoing = g_settings.convert_outgoing_last
                sys.stdout.write( prefix_message + "Text mode activated\r\n" + suffix_message )
                sys.stdout.flush()
                continue
            if ( l == "3~" ):
                g_settings.mode = eModeNumeric
                g_settings.convert_outgoing_last = g_settings.convert_outgoing
                g_settings.convert_outgoing = None
                sys.stdout.write( prefix_message + "Numeric mode activated\r\n" + suffix_message )
                sys.stdout.flush()
                continue
            if ( l == "4~" ):
                g_settings.mode = eModeHexNumeric
                g_settings.convert_outgoing_last = g_settings.convert_outgoing
                g_settings.convert_outgoing = None
                sys.stdout.write( prefix_message + "Hex numeric mode activated\r\n" + suffix_message )
                sys.stdout.flush()
                continue
            if ( l == "5~" ):
                g_settings.additional_ascii = not g_settings.additional_ascii
                sys.stdout.write( prefix_message + "Additional ASCII display is %s\r\n" % str(g_settings.additional_ascii) + suffix_message )
                sys.stdout.flush()
                continue
            if ( l == "7~" ):  # yes! F6 is "7~" !!! Thats windows for you...
                if (g_settings.prompt==""):
                    g_settings.prompt = GetPrompt( g_settings )
                    sys.stdout.write( prefix_message + "prompt is now on\r\n" )
                    sys.stdout.flush()
                else:
                    g_settings.prompt = ""
                    sys.stdout.write( prefix_message + "prompt is now off\r\n" )
                    sys.stdout.flush()
                continue
            if ( l[0:2] == "8~" ):  # yes! F7 is "8~" !!! Thats windows for you...
                ll = string.split( l )
                if ( len( ll ) == 1 ):
                    if ( g_settings.input_log_file ):
                        g_settings.input_log_file.close()
                        g_settings.input_log_file = None
                else:
                    g_settings.input_log_file = open( ll[1], "w" )
                continue

            if ( l[0:2] == "9~" ):  # yes! F8 is "9~" !!! Thats windows for you...
                ll = string.split( l )
                SendFromFile( ll[1] )
                continue
            if g_settings.echo:
                sys.stdout.write( prefix_keyboard + l + suffix_keyboard + "\r\n" )
                sys.stdout.flush()

            try:
                if g_settings.mode == eModeNumeric:
                    values = map( StringToInt, string.split( l ) )

                if g_settings.mode == eModeHexNumeric:
                    values = map( HexStringToInt, string.split( l ) )

                if g_settings.mode in [ eModeNumeric, eModeHexNumeric ]:
                    the_bytes = []
                    for v in values:
                        while v > 255:
                            the_bytes.append( v & 255 ) #lowbyte
                            v = v >> 8
                        the_bytes.append( v )
                    l = "".join( map( chr, the_bytes ) )
            except ValueError as e:
                sys.stdout.write( prefix_error + "invalid numeric input: %s" % str(e) + suffix_error + "\r\n" )
                sys.stdout.flush()
                continue


            try:
                (l,eol) = GetLineEndOfLine( l )

                if g_settings.convert_outgoing == CONVERT_CRLF:
                    eol = '\r\n'         #make it a CR+LF
                elif g_settings.convert_outgoing == CONVERT_CR:
                    eol = '\r'           #make it a CR
                elif g_settings.convert_outgoing == CONVERT_LF:
                    eol = '\n'           #make it a LF

                #dbg <<  'sending string %r\r\n' % (l)
                dbg << 'sending string %r\r\n' % (l+eol)
                g_serialport.write( bytes( l+eol, "ascii" ) )
            except IOError as e:
                dbg <<  prefix_error + "IOError: " + repr( e ) + suffix_error + "\r\n"
                if ( "Errno 13" in str(e) ):
                    # This can happen when connected to a CDC virtual COM port (like SDHx finger)
                    # on a power cycle. So try to restart:
                    pass
                else:
                    dbg <<  prefix_error + "Trying to ignore!" + suffix_error + "\r\n"

            continue

            c = getkey()  # @UndefinedVariable
            if c == EXITCHARACTER:
                break                       #exit app
            elif c == '\n':
                if g_settings.convert_outgoing == CONVERT_CRLF:
                    c = '\r\n'         #make it a CR+LF
                elif g_settings.convert_outgoing == CONVERT_CR:
                    c = '\r'           #make it a CR
                elif g_settings.convert_outgoing == CONVERT_LF:
                    c = '\n'           #make it a LF

                dbg << 'sending end of line string %r\r\n' % (c)
                g_serialport.write(c)                  #send character(s)
    except KeyboardInterrupt as e:
        print( "writer caught KeyboardInterrupt" )
        sys.stdout.flush()
        dbg << "writer: caught e=%r, terminating\n" % e
    except cTerminate as e:
        dbg << "writer: caught e=%r, terminating\n" % e
    except EOFError as e:
        dbg << "writer: caught e=%r, terminating\n" % e
    finally:
        dbg << "writer: finished\n"
        dbg.flush()


#print a short help message
def usage():

    can_options  = ""
    jtag_options = ""

    if ( "sdh.canserial" in sys.modules ):
        can_options = """--can:               use the (ESD) CAN interface instead of RS232 serial port
    --net=NET            use the ESD CAN net number NET
    --id_read=ID_READ:   use CAN ID ID_READ for receiving CAN messages (default: 43)
    --id_write=ID_WRITE: use CAN ID ID_WRITE for writing CAN messages (default: 42)"""

    if ( "sdh.jtagserial" in sys.modules ):
        jtag_options = """-j, --jtag:          use jtag_uart via nios2-terminal instead of RS232 serial port
    -i, --instance=ID:   use ID as jtag instance (see nios2-terminal --help)
    --cable=ID:          use ID as jtag cable (see nios2-terminal --help)
    --device=ID:         use ID as jtag device (see nios2-terminal --help)
    --noreadline:        do not use readline for command line history"""

    sys.stdout.write("""USAGE: %s [options]
    microterm - A simple terminal program for the serial port.

    options:
    -p, --port=PORT: RS232 port to use for communication
                     either a number, default = 0 (=COM1 / /dev/ttyS0)
                     or a device name like \"/dev/ttyUSB0\"
    -b, --baud=BAUD: baudrate, default 115200 for RS232, 1MBit for CAN
    -r, --rtscts:    enable RTS/CTS flow control (default off)
    -e, --echo:      enable local echo (default off)
    -d, --debug:     debug received data (escape nonprintable chars)
    -n, --numeric:       enable numeric mode, see online help (F1+RETURN)
    -x, --hexnumeric:    enable hex numeric mode, see online help (F1+RETURN)
    -a, --additional_ascii enable additional ascii display, see online help (F1+RETURN)
    -c, --cr:        do not send CR+LF, send CR only
    -t, --timeout=TIMEOUT: use timeout of TIMEOUT seconds, default is 0.1
    --xonxoff:   enable software flow control (default off)
    --newline:   do not send CR+LF, send LF only
    --input=FILE: send data from FILE instead of from keyboard
    --nonewline: do not add newlines, mainly usefull when using --input and --numeric or --hexnumeric
    --nocolor: do not use colored output
    --plotfileprefix=PATH: use PATH as prefix for saving plot files
    --plotshow: enable display of plot data, which will usually just be saved to a plot file
    %s
    %s
""" % (sys.argv[0], can_options, jtag_options ))
# no longer needed to detect lost USB devices
#    --idvendor: the USB vendor ID. Set this and idproduct to automatically detect USB reconnects
#    --idproduct: the USB product ID. Set this and idvendor to automatically detect USB reconnects
#                 (for SDHx use e.g. --idvendor=0x2047 --idproduct=0x03f0)




#-----------------------------------------------------------------
## \brief A Frame widget class, used to select the communication interface
#         to the RS232 like device
#
#  - creates the widgets
#  <hr>
try:
    import Tkinter

    class cTkSDHInterfaceSelectorFrame(Tkinter.Frame):
        '''A toplevel widget class, used to interactively select the communication interface of the microterm.py app on start.
        '''
        #-----------------------------------------------------------------
        ## Constructor of cTkSDHInterfaceSelectorFrame
        def __init__(self, master=None ):
            Tkinter.Frame.__init__(self, master=master, class_="cTkSDHInterfaceSelectorFrame" )

            # create all subwidgets
            self.CreateWidgets()
            self.master.protocol("WM_DELETE_WINDOW", self.CBQuit )

        #-----------------------------------------------------------------
        def RS232Callback(self ):
            global g_settings
            try:
                g_settings.port = self.available_ports[self.p.get()][0]
            except IndexError:
                self.p.set(0)
                if ( self.available_ports != [] ):
                    g_settings.port = self.available_ports[self.p.get()][0]

            g_settings.usecan = False

        def CANCallback(self ):
            global g_settings
            g_settings.usecan = True

        def OKCallback(self, event=None ):  # @UnusedVariable
            persistent_settings[ "last_port" ] = self.p.get()
            self.quit()

        def RescanCallback(self, event=None ):  # @UnusedVariable
            try:
                self.CreatePortSelectors()
            except ValueError:
                # can happen on automatic rescan when the available interfaces change right while scanning
                pass

        def CBQuit(self):
            self.quit()
            sys.exit(0)

        def CallCallback(self):
            if ( self.p.get() < 1000 ):
                self.RS232Callback()
            else:
                self.CANCallback()

        #-----------------------------------------------------------------
        ## Create the GUI widgets:
        def CreateWidgets(self):

            import pyschunk.guistuff
            pyschunk.guistuff.ci.cCI(self.master)

            last_port = persistent_settings.setdefault( "last_port", 0 )
            self.p = Tkinter.IntVar( value=last_port )
            self.all_ports = None
            self.available_ports = None
            self.rb_interfaces = []

            Tkinter.Label( self, text="Please select the communication interface to the SDH:\n" ).pack(anchor=Tkinter.N)
            #---------------------
            self.f_interfaces = Tkinter.Frame(self, borderwidth = 2, relief=Tkinter.SUNKEN)
            self.CreatePortSelectors()
            self.f_interfaces.pack( anchor=Tkinter.N )

            self.CallCallback()

            #---------------------
            f_buttons = Tkinter.Frame(self,pady=10)
            Tkinter.Label( f_buttons, text=" " ).pack(anchor=Tkinter.W,side=Tkinter.LEFT,padx=10)
            Tkinter.Button( f_buttons, text="  OK  ", command=self.OKCallback).pack(anchor=Tkinter.W,side=Tkinter.LEFT,padx=10)
            #Tkinter.Button( f_buttons, text="  Rescan  ", command=self.RescanCallback).pack(anchor=Tkinter.W,side=Tkinter.LEFT,padx=10)
            f_buttons.pack(anchor=Tkinter.S)

            self.master.bind('<Return>', self.OKCallback ) #
            self.master.bind('<Up>', self.CBUp ) #
            self.master.bind('<Down>', self.CBDown ) #

            self.after( 1000, self.RescanCallback )

        def CreatePortSelectors(self):
            self.after( 1000, self.RescanCallback )

            #available_ports = sdh.GetAvailablePorts()
            # New pyserial 2.7 has good working serial.tools.list_ports.comports()
            all_ports = list(serial.tools.list_ports.comports())
            # now all_ports is something like:
            #[('COM1', 'Kommunikationsanschluss (COM1)', 'ACPI\\PNP0501\\4&25E2FF18&0'),
            # ('COM19', 'MSP Debug Interface (COM19)', 'USB VID:PID=2047:0013'),
            # ('COM20', 'MSP Application UART1 (COM20)', 'USB VID:PID=2047:0013'),
            # ('COM9', 'SCHUNK SDHx virtual COM Port (COM9)', 'USB VID:PID=2047:03F0 SNR=019B816F2E001500'),
            # ('COM23', 'SCHUNK SDHx virtual COM Port (COM23)', 'USB VID:PID=2047:03F0 SNR=51AF0A4715002900']
            #   but also
            # ('', 'n/a', '{95C7A0A0-3094-11D7-A202-00508B9D7D5A}\\BLUETOOTHPORT\\1&30EE4AD&0&1000000000001')]
            dbg.var( "all_ports" )

            # delete invalid entries:
            to_del = []
            for (a0,a1,a2) in all_ports:
                if (len(a0) < 4):
                    print( "Ignoring invalid port (%r,%r,%r)" % (a0,a1,a2) )
                    to_del.append( (a0,a1,a2) )
            for td in to_del:
                all_ports.remove( td )

            # must be sorted
            def mycmp( a, b ):
                a0,a1,a2 = a  # @UnusedVariable
                b0,b1,b2 = b  # @UnusedVariable
                try:
                    a_port = int( a0[3:] )
                    b_port = int( b0[3:] )
                    if (a_port < b_port):
                        return -1
                    elif (a_port > b_port):
                        return 1
                    return 0 # should not happen!
                except ValueError:
                    # sometimes a0/b0 is not of the form "COMx", so try something different:
                    if ( a0 < b0 ):
                        return -1
                    elif ( a0 > b0 ):
                        return 1
                    return 0 #should not happen!

            all_ports.sort(cmp=mycmp)
            available_ports = []
            for (device_name,device_description,device_hardware) in all_ports:
                try:
                    s = serial.Serial( port=device_name )
                    s.close()
                except serial.serialutil.SerialException:
                    available_ports.append( (device_name,device_description,device_hardware,True) )
                else:
                    available_ports.append( (device_name,device_description,device_hardware,False) )
            dbg.var( "available_ports" )

            if ( self.available_ports == available_ports  and self.all_ports == self.all_ports ):
                #dbg << "No changed ports detected\n"
                return
            #dbg << "changed ports detected\n"
            self.available_ports = available_ports
            self.all_ports = all_ports

            for rb_interface in self.rb_interfaces:
                rb_interface.pack_forget()
                rb_interface.destroy()
            self.rb_interfaces = []

            i = 0
            self.p_values=[]
            if ( available_ports == [] ):
                rb_interface = Tkinter.Label( text="No interface available (yet)! Plug-in or power up now!", fg="red" )
                rb_interface.pack(anchor=Tkinter.W)
                self.rb_interfaces.append( rb_interface )

            for (device_name,device_description,device_hardware,occupied) in available_ports:
                if (occupied):
                    state = Tkinter.DISABLED
                    hint = "  (used by another application / insufficient rights)"
                else:
                    state = Tkinter.NORMAL
                    hint = ""
                rb_interface = Tkinter.Radiobutton(self.f_interfaces, state=state, text="%r : %s %s" % (device_name,device_description,hint), variable=self.p, value=i, command=self.RS232Callback)
                rb_interface.pack(anchor=Tkinter.W)
                self.rb_interfaces.append( rb_interface )
                self.p_values.append( i )
                i += 1
            if ( "sdh.canserial" in sys.modules ):
                rb_interface = Tkinter.Radiobutton(self.f_interfaces, text="CAN", variable=self.p, value=1000, command=self.CANCallback)
                rb_interface.pack(anchor=Tkinter.W)
                self.rb_interfaces.append( rb_interface )
                self.p_values.append( 1000 )

            self.pack_propagate(True)

        def CBUp(self,event=None):  # @UnusedVariable
            p0 = self.p.get()
            p1 = self.p_values[0]
            for p in self.p_values:
                if ( p == p0 ):
                    self.p.set( p1 )
                    self.CallCallback()
                    return
                p1 = p

        def CBDown(self,event=None):  # @UnusedVariable
            p0 = self.p.get()
            found = False
            for p in self.p_values:
                if found:
                    self.p.set( p )
                    self.CallCallback()
                    return
                if ( p == p0 ):
                    found = True

except ImportError:
    pass


def Exit( val=1, wait_for_key=("win32" in sys.platform) ):
    '''if wait_for_key is False then just call exit. If True then loop until a key is pressed then exit.
    On cygwin/linux wait_for_key defaults to False, on windows it defaults to True.
    (This is usefull to be able to view error messages of python when called on windows)
    '''
    global g_exiting, g_reader_thread, g_serialport
    g_exiting = True
    if ( not g_reader_thread is None ):
        g_serialport.close() # needed to terminate subprocesses (like nios-terminal for JTAG communication)
        #dbg << "closed\r\n"
        time.sleep(0.1)
        if ( g_reader_thread.isAlive() ):
            g_reader_thread.join(1.0)
            #dbg << "joined\r\n"
        #else:
        #    dbg << "already dead\r\n"
        #if ( g_reader_thread.isAlive() ):
        #    dbg << "still alive!\r\n"
        #else:
        #    dbg << "really dead!\r\n"


    if ( wait_for_key ):
        sys.stderr.write( "\nThis program can now be savely closed (CTRL-C)\n" )
        sys.stderr.flush()
        try:
            while True:
                input()
                time.sleep(0.1)
        except KeyboardInterrupt:
            # catch CTRL-C, so no error msg & stacktrace is shown
            pass
    sys.exit(val)


# no longer needed to detect lost USB devices:
# def SetUSBVendorProduct( settings ):
#     if ( not (settings.idVendor is None or settings.idProduct is None) ):
#         # Vendor and procut manully set by user, so leave alone
#         dbg << "USB Vendor / Product Id manully set, leaving alone\n"
#         return settings
#
#
#     # no USB Vendor or product was set.
#     # Check if we connect to a COM port at all
#     if ( settings.usecan ):
#         dbg << "Not using COM port at all\n"
#         return settings
#
#     # Its a COM port at least, so try to detect if its a virutal COM port via USB:
#     try:
#         if ( type(settings.port) == int ):
#             portname = "(COM%d)" % (settings.port+1)
#         else:
#             portname = "(%s)" % settings.port
#
#         import wmi
#         c = wmi.WMI()
#         wql = "Select * From Win32_USBControllerDevice"
#         for item in c.query(wql):
#             if ( portname in item.Dependent.Caption ):
#                 dbg << "Found usb com port %r in USB controller devices, item.Dependent.DeviceID=%r\n" % (portname,item.Dependent.DeviceID)
#                 # e.g.: item.Dependent.DeviceID == u'USB\\VID_2047&PID_03F0\\019B816F2E001500'
#                 mob = re.match( "USB\\\\VID_(....)&PID_(....)", item.Dependent.DeviceID )
#                 if ( mob is None ):
#                     sys.stderr.write( "Warning: Could not decode VID/PID from item.Dependent.DeviceID %r\n" % item.Dependent.DeviceID )
#                     break
#                 settings.idVendor  = eval( "0x%s" % mob.groups()[0] )
#                 settings.idProduct = eval( "0x%s" % mob.groups()[1] )
#                 dbg.var( "settings.idVendor settings.idProduct" )
#     except ImportError:
#         sys.stderr.write( "Warning: Could not import wmi\n" )
#         sys.stderr.write( "  => No automatic reconnect for USB devices will be available.\n" )
#     return settings

def GetSettings():
    #initialize with defaults
    settings = util.Struct(  port  = 0,
                             baudrate_rs232 = 115200,
                             baudrate_can   = 1000000,
                             baudrate       = None,
                             echo = 0,
                             rtscts = 0,
                             xonxoff = 0,
                             repr_mode = 0,
                             timeout   = 0.1,  # 0.5 is too long to make "terminal presence detection" work for DSACON32, since we are now using readline() instead of read()
                             usecan = False,
                             id_read = 43,
                             id_write = 42,
                             net = 0,
                             usejtag = False,
                             jtag_options = [],
                             jtag_processor = "",
                             mode = eModeAscii,
                             additional_ascii = False,
                             convert_outgoing = CONVERT_CRLF,
                             convert_outgoing_last = None,
                             prompt = None,
                             input_log_file = None,
                             inputfilename = None,
                             numeric_length = 8,
                             # no longer needed to detect lost USB devices:
                             #idVendor = None,
                             #idProduct = None,
                             plotfileprefix = "plot",
                             plot_show = False,
                             debug_flag = False,
                             )

    channel_set_by_user = False

    #parse command line options
    try:
        can_short_options  = ""
        can_long_options   = [ "can", "id_read=", "id_write=", "net=" ]
        jtag_short_options = "ji:"
        jtag_long_options  = [ "jtag", "instance=", "cable=", "device=" ]
        opts, args = getopt.getopt(sys.argv[1:],  # @UnusedVariable
                                   "hp:b:rednxact:o" + can_short_options + jtag_short_options,
                                   ["help", "port=", "baud=", "rtscts", "echo",
                                    "debug", "numeric", "hexnumeric", "additional_ascii",
                                    "cr", "timeout=", "noprompt", "xonxoff", "newline", "input=", "nonewline", "nocolor",
                                    "noreadline",
                                    # no longer needed to detect lost USB devices
                                    #"idvendor=", "idproduct=",
                                    "plotfileprefix=", "plotshow"]
                                    + can_long_options
                                    + jtag_long_options
                                   )
    except getopt.GetoptError:
        # print help information and exit:
        usage()
        Exit(2)

    for o, a in opts:
        if o in ["-h", "--help"]:       #help text
            usage()
            Exit(0)
        elif o in ["-p", "--port"]:     #specified port
            try:
                settings.port = int(a)
            except ValueError:
                settings.port = a
            channel_set_by_user = True
        elif o in ["-b", "--baud"]:     #specified baudrate
            try:
                settings.baudrate = int(a)
            except ValueError:
                raise ValueError("Baudrate must be a integer number, not %r" % a)
        elif o in ["-r", "--rtscts"]:
            settings.rtscts = 1
        elif o in ["--xonxoff"]:
            settings.xonxoff = 1
        elif o in ["-e", "--echo"]:
            settings.echo = 1
        elif o in ["-c", "--cr"]:
            settings.convert_outgoing = CONVERT_CR
        elif o in ["--newline"]:
            settings.convert_outgoing = CONVERT_LF
        elif o in ["-d", "--debug"]:
            dbg.SetFlag( True )
            settings.repr_mode = 1
        elif o in ["-n", "--numeric"]:
            dbg << "mode = -n\n"
            settings.mode = eModeNumeric
        elif o in ["-x", "--hexnumeric"]:
            settings.mode = eModeHexNumeric
        elif o in ["-a", "--additional_ascii" ]:
            settings.additional_ascii = True
        elif o in ["-t", "--timeout" ]:
            settings.timeout = float(a)
        elif o in ["-o", "--noprompt" ]:
            settings.prompt=""
        elif o in ["--input" ]:
            settings.inputfilename = a
        elif o in ["--nonewline" ]:
            settings.convert_outgoing = None
        elif ("sdh.canserial" in sys.modules  and  o in ["--can"]):
            settings.usecan = True
            channel_set_by_user = True
        elif ("sdh.canserial" in sys.modules  and   o in ["--net"]):
            settings.net = eval(a)
        elif ("sdh.canserial" in sys.modules  and   o in ["--id_read"]):
            settings.id_read = eval(a)
        elif ("sdh.canserial" in sys.modules  and  o in ["--id_write"]):
            settings.id_write = eval(a)
        elif ("sdh.jtagserial" in sys.modules  and   o in ["-j", "--jtag"]):
            settings.usejtag = True
            channel_set_by_user = True
        elif ("sdh.jtagserial" in sys.modules  and  o in ["-i", "--instance"]):
            settings.jtag_options.append( "--instance=" + a )
            if ( a in [ 0, "0" ] ):
                settings.jtag_processor = "-LLC"
            elif ( a in [ 1, "1" ] ):
                settings.jtag_processor = "-HLC"
            else:
                settings.jtag_processor = "-?"
        elif ("sdh.jtagserial" in sys.modules  and   o in ["--device"]):
            settings.jtag_options.append( "--device=" + a )
        elif ("sdh.jtagserial" in sys.modules  and   o in ["--cable"]):
            settings.jtag_options.append( "--cable=" + a )
        elif ( o in "--nocolor" ):
            dbg << "before\n"
            global prefix_keyboard, suffix_keyboard, prefix_serialin, suffix_serialin, prefix_message, suffix_message, prefix_error, suffix_error, prefix_warning, suffix_warning
            prefix_keyboard=suffix_keyboard=prefix_serialin=suffix_serialin=prefix_message=suffix_message=prefix_error=suffix_error=prefix_warning=suffix_warning = ""
            dbg.SetColor(None)
            dbg << "after\n"
        # no longer needed to detect lost USB devices
        #elif ( o in "--idvendor" ):
        #    settings.idVendor = eval( a )
        #elif ( o in "--idproduct" ):
        #    settings.idProduct = eval( a )
        elif ( o in "--plotfileprefix" ):
            settings.plotfileprefix = a
        elif ( o in "--plotshow" ):
            settings.plot_show = True

    settings.convert_outgoing_last = settings.convert_outgoing

    if ( not channel_set_by_user ):
        if "Tkinter" in sys.modules:
            root = Tkinter.Tk()
            ##try:
            ##    root.wm_iconbitmap(GetIconPath())
            ##except tkinter.TclError,e:
            ##    dbg << "Ignoring tkinter.TclError %r\n" % e
            ##    pass # ignore error
            global g_settings
            g_settings = settings
            app = cTkSDHInterfaceSelectorFrame( master=root )
            app.master.title("microterm interface selector" )
            app.pack()
            #app.mainloop()
            root.mainloop()
            try:
                root.destroy()
            except Tkinter.TclError:
                # happens when user cancelled the selection
                raise cTerminate()
            channel_set_by_user = True
            settings = g_settings
        else:
            sys.stderr.write( "Std. Python module Tkinter not available, no interactive interface selection available.\n" )

        if ( not channel_set_by_user ):
            sys.stderr.write( "  You can specifiy the interface to use with command line options.\n" )
            sys.stderr.write( "  Use -h or --help to see the online help.\n" )
            sys.stderr.write( "  Using default (RS232, port 0 = COM1).\n\n" )

    # no longer needed
    #settings = SetUSBVendorProduct( settings )
    # but now the port must be a device name as returned by serial.tools.list_ports.comports(), so:
    if ( type( settings.port ) is int ):
        settings.port = "COM%d" % (settings.port+1)

    if ( settings.prompt is None ):
        settings.prompt = GetPrompt( settings )

    return settings

#--------------------------------------------------------------------

def OpenPort( settings ):
    #open the port
    try:
        if ( settings.usecan ):
            if ( settings.baudrate is None ):
                settings.baudrate = settings.baudrate_can
            serialport = sdh.canserial.tCANSerial( settings.id_read, settings.id_write, settings.baudrate, settings.net )
            serialport._return_on_less = True
            sys.stderr.write( "Using ESD CAN net %d, id_read = 0x%03x, id_write = 0x%03x, baudrate = %d\n" % (settings.net, settings.id_read, settings.id_write, settings.baudrate) )
            sys.stdout.flush()
        elif ( settings.usejtag ):
            serialport = cJTAGSerial( settings.jtag_options )
        else:
            if ( settings.baudrate is None ):
                settings.baudrate = settings.baudrate_rs232
            serialport = serial.Serial(settings.port, settings.baudrate, rtscts=settings.rtscts, xonxoff=settings.xonxoff, timeout=settings.timeout)
    except Exception as e:
        sys.stderr.write("Could not open port\r\n")
        sys.stderr.write("  Exception: %s\r\n" % str(e) )
        sys.stdout.flush()
        raise
        Exit(1)
    dbg << "Opened serialport %r\n" % serialport
    dbg.var("settings")
    sys.stderr.write("--- microterm --- type Ctrl-D to quit\r\n")
    sys.stderr.flush()
    return serialport
#--------------------------------------------------------------------

def USBDeviceAvailable( settings ):
    # The approach here is slower (since serial.tools.list_ports.comports() might take up to 0.3s)
    # but is able to detect each port individually
    for (n,d,a) in serial.tools.list_ports.comports():  # @UnusedVariable
        if ( n == settings.port ):
            return True
    return False
    # The approch below:
    # will return True if any device with the specified vendor/product ID is found => not helpful
    #if ( g_have_usb_core_find and settings.idVendor and settings.idProduct ):
    #    return not usb.core.find(idVendor=settings.idVendor, idProduct=settings.idProduct) is None
    #return True

def StartReader():
    #start serial->console thread
    reader_thread = pyschunk.tools.util_thread.ThreadWithExc(target=reader, name="Reader")
    #reader_thread.setDaemon(1)
    reader_thread.start()
    return reader_thread

def StartWriter():
    writer_thread = pyschunk.tools.util_thread.ThreadWithExc(target=writer, name="Writer")
    #writer_thread.setDaemon(1)
    writer_thread.start()
    return writer_thread

def StartThreads():
    return (StartReader(), StartWriter())


def main():
    global g_settings, g_serialport
    t_reader = t_writer = None
    try:
        g_settings = GetSettings()
        g_serialport = OpenPort( g_settings )

        (t_reader,t_writer) = StartThreads()
        #and enter console->serial loop

        while not t_writer.isAlive():
            # wait until writer is alive
            pass

        while t_writer.isAlive():
            if ( USBDeviceAvailable( g_settings ) ):
                # usb device still available, do nothing here (leave reader/writer threads alone)
                time.sleep(0.5)
            else:
                # usb device is gone, try to recover:
                sys.stderr.write("\r\n!!! USB COM Port disconnected, Waiting for reconnect ...\r\n")
                sys.stderr.flush()

                # Reader thread must be restarted:
                t_reader.raiseExceptionToTerminate( cTerminate )
                t_reader.join()
                t_reader = None

                # Now close the port
                g_serialport.close()
                g_serialport = None
                time.sleep(0.5)

                # Wait until the port is available again:
                while ( not USBDeviceAvailable( g_settings ) ):
                    time.sleep(0.3)

                sys.stderr.write("USB COM Port available again, reconnecting...\r\n")
                sys.stderr.flush()
                # when restarting SDHx in debugger it might take some time
                # until the serialport is fully operational again. So wait
                # some time first then try and retry if required
                time.sleep( 1.0 )
                while g_serialport is None:
                    try:
                        serialport = OpenPort( g_settings )
                        g_serialport = serialport
                    except serial.SerialException:
                        time.sleep( 0.2 )
                    except ValueError:
                        time.sleep( 0.2 )
                t_reader = StartReader()

    except EOFError:
        pass
    except KeyboardInterrupt:
        print( "main caught KeyboardInterrupt" )
        sys.stdout.flush()
        pass
    except cTerminate:
        pass
    finally:
        dbg << "main: finished\n"
        dbg.flush()
        if ( t_reader ):
            dbg << "main: terminating reader\n"
            t_reader.raiseExceptionToTerminate( cTerminate )
            t_reader.join()
            t_reader = None
            dbg << " OK\n"
        if ( t_writer ):
            dbg << "main: terminating writer\n"
            t_writer.raiseExceptionToTerminate( cTerminate )
            t_writer.join()
            t_writer = None
            dbg << " OK\n"

    sys.stderr.write("\r\n--- exit ---\r\n")

if __name__ == '__main__':
    #try:
    #    print( "in main" )
    #    while True:
    #        time.sleep(1)
    #except KeyboardInterrupt:
    #    print( "caught KeyboardInterrupt" )
    #except SystemExit:
    #    print( "caught SystemExit" )
    main()
