'''
Created on 01.08.2013

@author: Osswald2
'''

def ToRange( v, vmin, vmax ):
    if ( v < vmin ):
        return vmin
    if ( v > vmax ):
        return vmax
    return v

