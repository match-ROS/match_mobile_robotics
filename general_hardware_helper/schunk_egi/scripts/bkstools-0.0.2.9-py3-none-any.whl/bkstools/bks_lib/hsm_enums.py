# -*- coding: latin-1 -*-
# @date: 2021-08-03 09:43
# @author: hsm2dot.exe 0.0.2.11 2021-06-17

import pyschunk.tools.util

# Enum for state id to state name mapping for SD_card
SD_card = pyschunk.tools.util.enum()
SD_card.Top_State    = 0
SD_card.Initializing = 1
SD_card.Running      = 2
SD_card.Idle         = 3
SD_card.Read         = 4
SD_card.Write        = 5
SD_card.Failure      = 6

# Enum for state id to state name mapping for application_state_machine
application_state_machine = pyschunk.tools.util.enum()
application_state_machine.Top_State                                 = 0
application_state_machine.Boot                                      = 1
application_state_machine.Error                                     = 2
application_state_machine.Pre_Operational                           = 3
application_state_machine.Operational                               = 4
application_state_machine.Prepare_for_Shutdown                      = 5
application_state_machine.Ready_for_Shutdown                        = 6
application_state_machine.Wait_Format                               = 7
application_state_machine.Boot_Start                                = 11
application_state_machine.Boot_Initialize_Parameters                = 12
application_state_machine.Factory_Reset                             = 29
application_state_machine.Normal_Operation_Mode                     = 30
application_state_machine.Wait_modules_shut_down_for_firmware_flash = 31
application_state_machine.Wait_Web_Content_Erased                   = 32
application_state_machine.Execute_Grip_Test                         = 40

# Enum for state id to state name mapping for motion_engine
motion_engine = pyschunk.tools.util.enum()
motion_engine.Top_State                                              = 0x00
motion_engine.Fast_Stop                                              = 0x01
motion_engine.Stop                                                   = 0x02
motion_engine.Controlled_Stop                                        = 0x04
motion_engine.Release_Brake                                          = 0x05
motion_engine.Reference                                              = 0x10
motion_engine.Jog_Mode                                               = 0x11
motion_engine.Move_to_position                                       = 0x12
motion_engine.Move_speed_controlled_grip                             = 0x13
motion_engine.Release_Work_Piece                                     = 0x14
motion_engine.Brake_Test                                             = 0x15
motion_engine.Move_relative                                          = 0x16
motion_engine.Move_grip_workpiece_with_position                      = 0x17
motion_engine.Move_grip_workpiece_with_position_move                 = 0x18
motion_engine.Move_grip_workpiece_with_position_grip                 = 0x19
motion_engine.Zero_vector_search                                     = 0x1B
motion_engine.Move_to_relative_position                              = 0x1E
motion_engine.Motor_supported_holding                                = 0x20
motion_engine.Brake_supported_holding                                = 0x21
motion_engine.No_workpiece_detected                                  = 0x22
motion_engine.Motor_supported_position_holding                       = 0x23
motion_engine.No_workpiece_detected_motor_supported_position_holding = 0x24
motion_engine.Wrong_workpiece_detected_brake_supported_holding       = 0x25
motion_engine.Workpiece_lost                                         = 0x26
motion_engine.Wrong_workpiece_detected_motor_supported_holding       = 0x27
motion_engine.Workpiece_lost_motor_supported_position_holding        = 0x28
motion_engine.Motor_supported_pre_gripping                           = 0x29
motion_engine.Stopped_States                                         = 0x30
motion_engine.Holding_States                                         = 0x31
motion_engine.Reference_moves                                        = 0x32
motion_engine.Measure                                                = 0x33
motion_engine.Brake_supported_holdings                               = 0x34
motion_engine.Motor_supported_holdings                               = 0x35
motion_engine.Motor_supported_workpiece_holdings                     = 0x36
motion_engine.Motor_supported_position_holdings                      = 0x37
motion_engine.Stopped_States_Drive_Disabled                          = 0x38
motion_engine.Moves                                                  = 0x39
motion_engine.Move_with_current_control                              = 0xE0
motion_engine.Move_with_speed_control                                = 0xE1
motion_engine.Move_with_field_oriented_vector                        = 0xE2
motion_engine.Move_with_rotating_vector                              = 0xE3

# Enum for state id to state name mapping for error_handler
error_handler = pyschunk.tools.util.enum()
error_handler.Top_State     = 0
error_handler.Wait_Setup    = 1
error_handler.Operate       = 2
error_handler.Stop          = 3
error_handler.Idle          = 20
error_handler.Wait_Read     = 21
error_handler.Wait_Written  = 22
error_handler.Factory_Reset = 23

# Enum for state id to state name mapping for HMS_Application_Statemachine
HMS_Application_Statemachine = pyschunk.tools.util.enum()
HMS_Application_Statemachine.Top_State                      = 0
HMS_Application_Statemachine.Appl_Init                      = 10
HMS_Application_Statemachine.Appl_Waitcom                   = 20
HMS_Application_Statemachine.Appl_Run                       = 30
HMS_Application_Statemachine.Appl_Run_Wait_for_Network_Type = 31
HMS_Application_Statemachine.Appl_Run_Normal_Mode           = 32
HMS_Application_Statemachine.Appl_Shutdown                  = 40
HMS_Application_Statemachine.Appl_ABCCReset                 = 50
HMS_Application_Statemachine.Appl_DevReset                  = 60
HMS_Application_Statemachine.Appl_Halt                      = 70
