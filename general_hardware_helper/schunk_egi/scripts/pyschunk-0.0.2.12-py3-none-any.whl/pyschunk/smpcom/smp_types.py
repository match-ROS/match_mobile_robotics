'''
Created on 08.12.2009

@author: Osswald2
'''

import sys
import struct
from . import smp_codes

def ArgsToByteList( *args ):
    ''' \return a list of bytes according to \a args
    '''
    the_bytes = []
    for a in args:
        if ( type(a) == str ):
            the_bytes += list(map( ord, a ))
        elif ( type(a) in [list, tuple] ):
            the_bytes += a
        elif ( type(a) is int ): # on Linux the type is long...
            the_bytes.append(a)
        else:
            raise TypeError( "invalid type %r in *args" % type(a) )
    return the_bytes


def ArgsToByteString( *args ):
    ''' \return a bytes object according to \a args
    '''
    the_bytes = b""
    for a in args:
        if ( type(a) == str ):
            the_bytes += bytes( a, encoding="ascii" ) # FIXME: this might be wrong if a contains non ascii "bytes"
        elif ( type(a) in [bytes] ):
            the_bytes += a
        elif ( type(a) in [list, tuple] ):
            the_bytes += bytes( a )
        elif ( type(a) in [int] ):
            the_bytes += bytes( (a,) )
        else:
            raise TypeError( "invalid type %r in *args" % type(a) )
    return the_bytes


class cANY(object):
    def __init__(self):
        pass


    def __str__(self):
        '''return a string describing self
        '''
        return "ANY"


    def __repr__(self):
        '''For more informative output in failed assertions: return a string describing self
        '''
        return "'ANY'"


ANY = cANY()


class cSMPType(object):
    ''' base class for smp data object classes
    '''
    def __init__(self, format_string, *args, **kwargs ):
        self.format_string = format_string

        if ( len(args) == 0 ):
            if ( kwargs == {} ):
                self.name = None
                self.Clear()
            elif ( len( kwargs ) == 1 ):
                self.name = list(kwargs.keys())[0]
                self.Check( list(kwargs.values())[0] )
            else:
                raise KeyError( "additional kwargs %r present" % (kwargs) )

        elif ( len(args) == 1 ):
            if ( kwargs != {} ):
                raise KeyError( "value given in args, but additional kwargs %r present" % (kwargs) )
            self.name = None
            self.Check(args[0])
        else:
            raise KeyError( "more than one args present" )


    def Check(self, arg=None ):
        # generic check: do nothing but save arg
        self.value = arg
        if ( arg is ANY or arg is None ):
            pass
        elif ( type( arg ) is list ):
            for a in arg:
                self.DoCheck( a )
        elif ( type( arg ) is tuple ):
            if ( len( arg ) != 2 ):
                raise ValueError( "for argument values of type tuple the tuple lenght must be exactly 2 (min,max), not %d" % (len(arg)) )

            if ( arg[0] > arg[1] ):
                raise ValueError( "for argument values of type tuple the first element must not be larger than the second on (min,max)" )

            for a in arg:
                self.DoCheck( a )
        else:
            self.DoCheck(arg)


    def Clear(self):
        '''clear the value so that the object does not contain data any more
        '''
        self.Check(None)


    def HasData(self):
        '''\return True if self holds actual data bytes
        '''
        return not (self.value is None)


    # get or set d_len property:
    def _get_d_len( self ):
        if ( not self.HasData() ):
            return 0
        else:
            return struct.calcsize( self.format_string )

    def _set_d_len( self, v ):
        raise AttributeError( "setting of d_len not allowed" )

    def _del_d_len( self ):
        pass

    d_len = property( _get_d_len, _set_d_len, _del_d_len, "d_len, actual number of bytes in self" )


    def GetFilledLength( self, peek_byte_list=None ):
        '''Return the length of the object in bytes if it were filled with data
        '''
        return struct.calcsize( self.format_string )


    def GetByteString(self):
        ''' \return self as string of bytes
        '''
        if ( not self.HasData() ):
            raise ValueError( "No data to get bytes from!" )
        if ( self.value is ANY ):
            raise ValueError( "Cannot get byte string of ANY!" )
        if ( type( self.value ) in (list,tuple) ):
            raise ValueError( "Cannot get byte string of list or tuple parameters!" )

        return struct.pack( self.format_string, self.value )

    def GetByteList(self):
        ''' \return self as list of bytes
        '''
        return list( self.GetByteString() )


    def FromBytes(self, *args ):
        ''' set \a self.value according to \a args

        \a args can be an arbitrary argument list containing any iterable object containing bytes (string, list of ints, tuple of ints, ...)

        \return self  (in order to allow something like msg=cSMPMessage().FromBytes( "\x01\x02\0x03" )
        '''
        bytestring = ArgsToByteString( *args )
        arg = struct.unpack( self.format_string, bytestring )[0]
        self.value = arg
        self.Check(arg)
        return self


    def __eq__(self,other):
        if ( type(self) != type(other) ):
            return False
        return self.GetByteList() == other.GetByteList()


    def __ne__( self, other ):
        return not self == other


    def MatchedBy( self, other ):
        '''Test if other matches self.
        Usefull if self has parameters that are not given explicitly, but as ANY, [list of allowed values] or (min,max) range

        \return (matches,mismatch_msg) tuple where
        - \a matches is a boolean that indicates if other matches self
        - \a mismatch_msg if matches is False then this is a message string that further explains the mismatch
        '''
        if ( self.name != other.name and not self.name is None and not other.name is None ):
            return (False, "%s.name fields do not match: %r != %r" % (self.__class__,self.name,other.name))
        if ( self.value is ANY ):
            return (True,"")
        if ( self.name ):
            name = " (" + self.name + ")"
        else:
            name = ""
        if ( type( self.value ) is list ):
            if ( other.value in self.value ):
                return (True,"")
            else:
                return (False, "The %s value%s %r is not in the list of expected values %r" % (self.__class__,name,other.value,self.value))
        if ( type( self.value ) is tuple ):
            if ( self.value[0] <= other.value and other.value <= self.value[1] ):
                return (True,"")
            else:
                return (False, "The %s value%s %r is not in the expected range [%r..%r]" % (self.__class__,name,other.value,self.value[0],self.value[1]))

        if ( self.__eq__( other ) ):
            return (True,"")
        return (False,"\n  %s != %s" % (self, other))


class cUInt8(cSMPType):
    '''Class to represent unsigned int 8 data (8bit)

    - If the object has the name "cmd" then its string representation will
      contain the human readable interpretation of the command code as string.
    - If the object has the name "error" then its string representation will
      contain the human readable interpretation of the error code as string.
    '''
    def __init__( self,  *args, **kwargs ):
        cSMPType.__init__( self, "<B", *args, **kwargs )

    def DoCheck( self, arg ):
        if ( arg < 0 ):
            raise ValueError( "negative cUInt8 given!" )
        if ( arg > 0xff ):
            raise ValueError( "cUInt8=0x%x > 0xff given!" % arg )

    def __str__(self):
        if ( self.name is None ):
            return "cUInt8(value=0x%02x=%d)" % (self.value,self.value)
        else:
            if ( self.name == "cmd" ):
                return "cUInt8(value=0x%02x=%d=%r, name=%r)" % (self.value,self.value,smp_codes.eCmdCode.GetName(self.value),self.name)
            elif ( self.name == "error" ):
                return "cUInt8(value=0x%02x=%d=%r, name=%r)" % (self.value,self.value,smp_codes.eErrorCode.GetName(self.value),self.name)
            else:
                return "cUInt8(value=0x%02x=%d, name=%r)" % (self.value,self.value,self.name)


class cUInt16(cSMPType):
    '''Class to represent unsigned int 16 data (16bit)
    '''
    def __init__( self, *args, **kwargs ):
        cSMPType.__init__( self, "<H", *args, **kwargs )

    def DoCheck(self,arg):
        if ( arg < 0 ):
            raise ValueError( "negative cUInt16 given!" )
        if ( arg > 0xffff ):
            raise ValueError( "cUInt16 > 0xffff given!" )

    def __str__(self):
        if ( self.name is None ):
            return "cUInt16(value=0x%04x=%d)" % (self.value,self.value)
        else:
            return "cUInt16(value=0x%04x=%d, name=%r)" % (self.value,self.value,self.name)


class cUInt32(cSMPType):
    '''Class to represent unsigned int 32 data (32bit)
    '''
    def __init__( self, *args, **kwargs ):
        cSMPType.__init__( self, "<I", *args, **kwargs )

    def DoCheck(self,arg):
        if ( arg < 0 ):
            raise ValueError( "negative cUInt32 given!" )
        if ( arg > 0xffffffff ):
            raise ValueError( "cUInt32 > 0xffffffff given!" )

    def __str__(self):
        if ( self.name is None ):
            return "cUInt32(value=0x%08x=%d)" % (self.value,self.value)
        else:
            return "cUInt32(value=0x%08x=%d, name=%r)" % (self.value,self.value,self.name)


class cInt16(cSMPType):
    '''Class to represent signed int 16 data (16bit)
    '''
    def __init__( self, *args, **kwargs ):
        cSMPType.__init__( self, "<h", *args, **kwargs )

    def DoCheck(self,arg):
        if ( arg < -0x8000):
            raise ValueError( "cInt16 < 0x8000!" )
        if ( arg > 0x7fff ):
            raise ValueError( "cInt16 > 0x7fff given!" )

    def __str__(self):
        if ( self.name is None ):
            return "cInt16(value=0x%04x=%d)" % (self.value,self.value)
        else:
            return "cInt16(value=0x%04x=%d, name=%r)" % (self.value,self.value,self.name)


class cInt32(cSMPType):
    '''Class to represent signed int 32 data (32bit)
    '''
    def __init__( self, *args, **kwargs ):
        cSMPType.__init__( self, "<i", *args, **kwargs )

    def DoCheck(self,arg):
        if ( arg < -0x80000000):
            raise ValueError( "cInt32 < 0x80000000!" )
        if ( arg > 0x7fffffff ):
            raise ValueError( "cInt32 > 0x7fffffff given!" )

    def __str__(self):
        if ( self.name is None ):
            return "cInt32(value=0x%08x=%d)" % (self.value,self.value)
        else:
            return "cInt32(value=0x%08x=%d, name=%r)" % (self.value,self.value,self.name)


class cFloat(cSMPType):
    '''Class to represent float data (32bit)
    '''
    def __init__( self, *args, **kwargs ):
        cSMPType.__init__( self, "<f", *args, **kwargs )

    def DoCheck(self,arg):
        # FIXME: add check here
        pass

    def __str__(self):
        if ( self.name is None ):
            return "cFloat(value=%f)" % (self.value)
        else:
            return "cFloat(value=%f, name=%r)" % (self.value,self.name)


class cString(cSMPType):
    '''Class to represent char[] data (strings) of fixed or variable length
    '''
    def __init__( self,  *args, **kwargs ):
        ''' CTor for cString objects, intended as element of a cSMPMessage

        If 2 arguments are given then the second one specifies a fixed size
        for the string.
        If a keword argument "size" is given then it specifies a fixed size
        for the string.
        '''
        if ( "size" in kwargs ):
            self.size = kwargs["size"]
            del kwargs["size"]
        elif ( len(args) > 1 ):
            self.size = args[1]
            args = (args[0],) + args[2:]
        else:
            self.size = None

        if ( self.size ):
            # fixed length string
            cSMPType.__init__( self, "%ds" % self.size, *args, **kwargs  )
        else:
            # variable length string
            cSMPType.__init__( self, "s", *args, **kwargs  )

    def DoCheck( self, arg ):
        if ( self.size ):
            # fixed length string
            if ( len( arg ) > self.size ):
                sys.stderr.write( "Warning: smp_types.cString.DoCheck() truncating given string %r due to given fixed length %d!\n" % (arg, self.size) )
                self.value = arg[:self.size] # truncate
            else:
                self.value = arg + ("\x00"*(self.size-len(arg))) # append null bytes
        else:
            # variable length string
            self.value = arg
        if ( type(self.value) not in [ str, type(None) ] ):
            raise ValueError( "other type than str or None given" )

    # get d_len property:
    def _get_d_len( self ):
        '''\return actual length of object in bytes

        (overloaded version of d_len since default implementation works for fixed length strings only)
        '''
        if ( self.size ):
            # fixed length string
            return cSMPType._get_d_len( self )
        if ( not self.HasData() ):
            return 0
        else:
            return len( self.value )

    d_len = property( _get_d_len, cSMPType._set_d_len, cSMPType._del_d_len, "d_len, number of bytes in self" )


    def GetFilledLength( self, peek_byte_list=None ):
        '''Return the length of the object in bytes if it were filled with data

        (Overloaded version of GetFilledLength since default implementation works for fixed length strings only)
        '''
        if ( self.size ):
            # fixed length string
            return cSMPType.GetFilledLength(self)

        # variable length string
        if ( peek_byte_list is None ):
            return 1 # ANOTE: we do not know the actual filled length here since that is variable!

        return len(peek_byte_list) # ANOTE: we use the length of the peek byte list since we do not know the actual filled length here since that is variable!


    def GetByteString(self):
        '''overloaded variant to handle variable length strings

        \return self as string of bytes
        '''
        if ( self.size ):
            # fixed length string
            return cSMPType.GetByteString(self)
        else:
            # variable length string
            if ( not self.HasData() ):
                raise ValueError( "No data to get bytes from!" )
            return [ ord( c ) for c in self.value ]

    def FromBytes(self, *args ):
        '''overloaded variant to handle variable length strings

        set \a self.value according to \a args

        \a args can be an arbitrary argument list containing any iterable object containing bytes (string, list of ints, tuple of ints, ...)

        \return self  (in order to allow something like msg=cSMPMessage().FromBytes( "\x01\x02\0x03" )
        '''
        bytestring = ArgsToByteString( *args )
        if ( self.size ):
            # fixed length string
            arg = struct.unpack( self.format_string, bytestring )[0]
        else:
            # variable length string
            arg = bytestring

        self.value = arg
        self.Check(arg)
        return self


class cDTString(cString):
    '''Class to represent DT_STRING data (strings with length prefix byte) of variable length
    '''
    def __init__( self,  *args, **kwargs ):
        ''' CTor for cDTString objects, intended as element of a cSMPMessage
        The length byte must NOT be included in the args or kwargs!
        '''
        if ( len( args ) > 1 ):
            raise KeyError( "more than one args present" )
        if ( "size" in kwargs ):
            raise KeyError( "additional kwarg size invalid for cDTString objects" )
        cString.__init__(self, *args, **kwargs)
        if ( self.value is None ):
            self.value = ""
        if ( not type( self.value ) is cANY ):
            self.value = chr(len(self.value)) + self.value

    # get d_len property:
    def _get_d_len( self ):
        '''\return actual length of object in bytes

        (overloaded version of d_len since default implementation works for fixed length strings only)
        '''
        if ( type( self.value ) is cANY ):
            raise ValueError( "Cannot determine d_len of cDTString with value ANY" )

        return super( cDTString, self ).d_len

    d_len = property( _get_d_len, cSMPType._set_d_len, cSMPType._del_d_len, "d_len, number of bytes in self" )

    def SetString( self, s ):
        '''Set self.value to a valid DT_STRING with content \a s.
        \a s is given without the length prefix byte while self.value will contain
        that byte
        '''
        self.value = chr(len(s)) + s


    def GetString( self ):
        '''Get the actual string content from self.value,
        i.e. strip of the length prefix byte from self.value.
        '''
        return self.value[1:]


    def FromBytes(self, *args ):
        '''overloaded variant to handle variable length strings
        The length byte MUST be included in the args or kwargs!

        set \a self.value according to \a args

        \a args can be an arbitrary argument list containing any iterable object containing bytes (string, list of ints, tuple of ints, ...)

        \return self  (in order to allow something like msg=cSMPMessage().FromBytes( "\x01\x02\0x03" )
        '''
        self.value = ArgsToByteString( *args )
        str_len = ord(self.value[0])
        if ( str_len != len(self.value)-1 ):
            raise ValueError( "given string length in byte 0 (%d) does not match length of string (%d)!" % (str_len, len(self.value)-1 ) )
        return self


    def GetFilledLength( self, peek_byte_list=None ):
        '''Return the length of the object in bytes if it were filled with data

        (Overloaded version of GetFilledLength since default implementation works for cString only)

        \remark if self.value is cANY (i.e. we represent any possible string), then
        GetFilledLength() return value depends on the peek_byte_list:
        - if peek_byte_list is None or empty then 1 is returned, representing the
          minimum length of a cDTString consisting just of the length byte.
          (This is somewhat hackish, but works (e.g. it will yield a no-match
          as desired by the caller when trying to match a received message to an
          expected one.
        - if peek_byte_list contains bytes then these are used to determine the
          length. This might raise a ValueError exception in case the data is
          inconsistent.
        '''
        # variable length string
        if ( peek_byte_list is None ):
            if ( type( self.value ) is cANY ):
                return 1 # at least one length byte
            return len( self.value )

        if ( len( peek_byte_list ) == 0 ):
            # Still return 1 although the peek_byte_list cannot contain a valid cDTString
            return 1

        nb_dt_string_bytes = peek_byte_list[0]
        if ( nb_dt_string_bytes > len( peek_byte_list[1:] ) ):
            raise ValueError( "less bytes in peek_byte_list (%d) than indicated by the DT_STRING length byte (%d)" % (len( peek_byte_list[1:] ), nb_dt_string_bytes ) )
        return nb_dt_string_bytes+1


ok = cUInt16().FromBytes( ord("O"), ord("K") )
