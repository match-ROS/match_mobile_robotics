#!/usr/bin/env python
# -*- coding: latin-1 -*-
# Created on 2021-08-06
#
# @author: Dirk Osswald
'''
Simple basic control (move, grip, release) of a SCHUNK BKS gripper (like EGI)|n
|n
Example usage:|n
-  %(prog)s -H 10.49.57.13
'''


import time
from bkstools.bks_lib.bks_base import BKSBase, eCmdCode
from bkstools.bks_lib.debug import Print, Var, ApplicationError, g_logmethod  # @UnusedImport
from bkstools.bks_lib import bks_options


def main():
    #--- create a command line option parser and parse the command line:
    parser = bks_options.cBKSTools_OptionParser( prog=__file__,
                                                 description = __doc__,
                                                 fileversion = __file__ )
    args = parser.parse_args()

    #--- Create a BKSBase object to interact with the gripper:
    bksb = BKSBase( args.host )

    # Remarks:
    # - The bksb object just created queried the gripper for all its available
    #   parameters on construction. These parameters are avaialbe as
    #   properties of the bksb object (i.e. they can be accessed like normal member variables)
    # - E.g. the actual position of the gripper is available now
    #   as `bksb.actual_pos`. When the script accesses this property
    #   then actually a http get request is sent to gripper and the JSON
    #   response is parsed, converted accordingly and returned.
    # - For writable parameters like the `bksb.command_code` a http post
    #   request is generated when the script sets that property.

    #--- Prepare gripper: Acknowledge any pending error:
    bksb.command_code = eCmdCode.CMD_ACK
    time.sleep(0.1)

    #--- Perform a reference movement if necessary:
    if ( (bksb.plc_sync_input[0] & bksb.sw_referenced) == 0 ):
        input( "\nPress return to start a reference movement.\nWARNING: This will close the gripper, keep your fingers out of reach!" )

        bksb.command_code = eCmdCode.CMD_REFERENCE
        time.sleep(0.1)

        #--- Query the statusword until the referenced-bit is set:
        while ((bksb.plc_sync_input[0] & bksb.sw_referenced) == 0):
            time.sleep(0.1)
    else:
        print( f"Gripper already referenced." )

    print( f"Actual position is {bksb.actual_pos:.1f} mm." )

    #--- Open gripper by moving to an absolute postion:
    bksb.set_pos = 30.0 # target position at 30 mm (distance between fingers)
    bksb.set_vel = 50.0 # target velocity limited to 50 mm/s
    input( f"\nPress return to move to absolute position {bksb.set_pos:.1f} mm:")
    bksb.command_code = eCmdCode.MOVE_POS
    time.sleep(3)

    #--- Perform a simple grip (from outside) movement:
    bksb.set_force = 25  # target force to (approx) 25N
    bksb.grp_dir = False # grip from outside
    input( f"\nActual postion is {bksb.actual_pos:.1f} mm.\nInsert a workpiece to grasp from outside. (Do not use your finger!)\nPress return to perform a grip from outside movement:")
    bksb.command_code = eCmdCode.MOVE_FORCE    # (for historic reasons the actual grip command for simple gripping is called MOVE_FORCE...)
    time.sleep(3)

    #--- Perform a release operation movement:
    input( f"\nFound workpiece at {bksb.actual_pos:.1f} mm.\nPress return to release the gripped workpiece:")
    # This will move the fingers `bksb.wp_release_delta` mm away from the workpiece
    bksb.command_code = eCmdCode.CMD_RELEASE_WORK_PIECE
    time.sleep(1)

    #--- Perform a simple grip (from inside) movement:
    bksb.set_force = 25 # target force to (approx) 25N
    bksb.grp_dir = True # grip from inside
    input( f"\nActual postion is {bksb.actual_pos:.1f} mm.\nInsert a workpiece to grasp from inside. Do not use your finger!\nPress return to perform a grip from inside movement:")

    bksb.command_code = eCmdCode.MOVE_FORCE    # (for historic reasons the actual grip command for simple gripping is called MOVE_FORCE...)
    time.sleep(3)

    #--- Perform a release operation movement:
    input( f"\nFound workpiece at {bksb.actual_pos:.1f} mm.\nPress return to release the gripped workpiece:")
    bksb.command_code = eCmdCode.CMD_RELEASE_WORK_PIECE
    time.sleep(1)


if __name__ == '__main__':
    from pyschunk.tools import attach_to_debugger
    attach_to_debugger.AttachToDebugger( main )
    #main()
