# -*- coding: latin-1 -*-
#######################################################################
# The python docstring for the module follows below.
#   (The doxygen input filter doxypy (http://code.foosel.org/doxypy)
#    allows you to use doxygen markup in the python docstrings for
#    files, classes and functions)
'''
  \file
  \section smpcom_smp_interface_schunkusb_py_general General file information

    \author   Osswald2
    \date     03.12.2009

  \brief
    Implementation of communication via SCHUNK USB

  \section smpcom_smp_interface_schunkusb_py_copyright Copyright

  - Copyright (c) 2009 SCHUNK GmbH & Co. KG

  <HR>
  \internal

    \subsection smpcom_smp_interface_schunkusb_py_details SVN related, detailed file specific information:
      $LastChangedBy$
      $LastChangedDate$
      \par SVN file revision:
        $Id$

  \subsection smpcom_smp_interface_schunkusb_py_changelog Changelog of this file:
      \include smp_interface_schunkusb.py.log
'''
#######################################################################


#######################################################################
## \anchor smpcom_smp_interface_schunkusb_py_python_vars
#  \name   Python specific variables
#
#  Some definitions that describe the module for python.
#
#  @{

__author__    = "Dirk Osswald: dirk.osswald@de.schunk.com"
__url__       = "http://www.schunk.com"
__version__   = "$Id$"
__copyright__ = "Copyright (c) 2009 SCHUNK GmbH & Co. KG"

## end of doxygen name group smpcom_smp_interface_schunkusb_py_python_vars
#  @}
######################################################################


######################################################################
# import needed modules:

# standard python modules
import sys
import time

# import the PyUSB module
import d2xx #unfortunately not available for python2.7!

# submodules from this package:
from pyschunk.smpcom import smp_message, smp_crc, smp_types, smptools

from pyschunk.tools.dbg import tDBG
#
######################################################################


######################################################################
# The actual classes

# Debug messages are now disabled by default
# To enable them on load define a flag in your __main__ module:
#   debug_flag_smp_interface_schunkusb = True
dbg = tDBG( False, "green", description="pyschunk.smpcom.smp_interface_schunkusb" )
try:
    dbg.SetFlag( sys.modules["__main__"].debug_flag_smp_interface_schunkusb )
except:
    pass

def GetUSB():
    #####
    # Get SCHUNK USB device:
    # TODO: get the device to use from command line
    # TODO: check if the device is a real SCHUNK USB device

    ## list devices by description, returns tuple of attached devices description strings
    #d = d2xx.listDevices(d2xx.OPEN_BY_DESCRIPTION)
    ##print( "d2xx.listDevices(d2xx.OPEN_BY_DESCRIPTION)" )
    ##pprint.pprint( d )

    ## list devices by serial, returns tuple of attached devices serial strings
    #d = d2xx.listDevices() # implicit d2xx.OPEN_BY_SERIAL_NUMBER
    #print( "d2xx.listDevices()" )
    #pprint.pprint( d )

    h = d2xx.open(0)
    #print( "d2xx.open(0)" )
    #pprint.pprint( h )

    ## read eeprom
    #print( "h.eeRead()" )
    #print( h.eeRead() )

    ## get queue status
    #print( "h.getQueueStatus()" )
    #print( h.getQueueStatus() )

    ## set RX/TX timeouts
    h.setTimeouts(1000,1000)
    #####
    dbg << "USB connection: manufacturer:%r description:%r\n" % (h.eeRead()['manufacturer'], h.eeRead()['description'])
    return h

class cSMPComSCHUNKUSB(object):
    '''
    Class to communicate via SCHUNK USB
    '''

    default_baudrate = 9600

    def __init__(self, options):
        '''CTor

        \param options - a structure describing the communication parameters,
                         like returned by options.cSMPComOptionParser.parse_args()
                         options.interface describes the port ("USB")
                         options.baudrate is the baudrate in bit/s (if 0 then self.default_baudrate is used)
                         options.debug > 0 enables debug messages
        '''
        dbg.SetFlag(options.debug_level > 0)

        #---------------------
        # check if options.interface is a valid schunkusb interface specification
        interface = None
        try:
            interface = int( options.interface )
        except ValueError:
            interface = None

        if interface is None:
            if (options.interface[0:3].lower() == "usb" ):
                interface = "USB" + options.interface[3:]

        if interface is None:
            raise ValueError( "options.interface=%r is not a valid USB interface specification!" % (options.interface) )

        self.port = interface
        if ( options.baudrate == 0 ):
            options.baudrate = self.default_baudrate
        self.options = options
        self.com = None
        #---------------------

        self.t_send = 0.0
        self.t_receive = 0.0
        self._timeout = None


    def _prop_SetTimeout(self, timeout ):
        self._timeout = timeout
        if ( self.com ):
            self.com.timeout = timeout


    def _prop_GetTimeout(self ):
        return self._timeout


    timeout = property( _prop_GetTimeout, _prop_SetTimeout, None, "Timeout in seconds for receiving. Timeout = 0 means: return immediately even if no data is available (an IOError is raised in that case)" )


    @classmethod
    def GetHelpString(cls):
        '''Return a help string suitable for describing the command line parameters needed for this interface

        \remark: This classmethod gets called by the smp_optionparser.cSMPComOptionParser constructor
        '''
        return '''- "USB"       : shorthand for the USB device'''


    def Open(self, module_ids=None ):  # @UnusedVariable
        '''
        Open connection to usb interface as configured by the options given to the constructor

        \param module_ids - list of module ids or None for all. Ignored for RS232 for now, only for compatibility with CAN
        '''
        dbg << "Opening usb connection to port %s, baudrate %d\n" % (self.port,self.options.baudrate)
        self.com = GetUSB()
        self.com.setBaudRate(self.options.baudrate);
        #self.com.flushInput()
        #self.com.flushOutput()


    def Close(self):
        '''
        Close connection to usb interface.
        '''
        if self.com:
            self.com.close()
        self.com = None


    def FlushInput(self):
        '''Flush input
        '''
        #self.com.flushInput()
        self.com.flush()
        if ( self.options.debug_level > 0 and self.options.debug_output_receive ):
            self.options.debug_output_receive.write( "%s input flushed\n" % self.port )


    def Send(self, msg ):
        assert self.com
        the_bytes = msg.GetByteString()
        the_bytes = the_bytes[:2] + chr( len(the_bytes)-2 ) + the_bytes[2:]
        msg.crc_calculated = 0
        for bs in the_bytes:
            msg.crc_calculated = smp_crc.CRC16( msg.crc_calculated, ord(bs) )
        the_bytes += smp_types.cUInt16( msg.crc_calculated ).GetByteString()
        self.com.write(the_bytes)
        self.t_send = time.time()

        if ( self.options.debug_level > 0 and self.options.debug_output_send ):
            s = smptools.GetTimestamp( self.t_send )
            s += " %s>: " % (self.port)
            for b in the_bytes:
                s += "0x%02x " % ord( b )
            self.options.debug_output_send.write( s + "\n" )

    def Receive(self, msg=None ):
        assert self.com
        self.invalid_msg = None
        if ( msg is None ):
            msg = smp_message.cSMPMessage()
        try:
            #very simple approach: no recovery from timeouts, crc errors
            id_d_len = self.com.read(3)
            self.t_receive = time.time()

            if ( self.options.debug_level > 0 and self.options.debug_output_receive ):
                s = smptools.GetTimestamp( self.t_receive )
                s += " %s<: " % (self.port)
                for b in id_d_len:
                    s += "0x%02x " % ord( b )
                self.options.debug_output_receive.write( s )

            d_len = ord( id_d_len[2] )

            data_crc = self.com.read( d_len+2 )
            if ( self.options.debug_level > 0 and self.options.debug_output_receive ):
                s = ""
                for b in data_crc:
                    s += "0x%02x " % ord( b )
                self.options.debug_output_receive.write( s + "\n" )

            crc_bytestring = data_crc[ d_len: ]
            if ( len( crc_bytestring ) == 2 ):
                msg.crc_read = smp_types.cUInt16().FromBytes( crc_bytestring ).value
            elif ( len( crc_bytestring ) == 1 ):
                msg.crc_read = smp_types.cUInt16( ord( crc_bytestring ) )
            else:
                msg.crc_read = 0

            msg.crc_calculated = 0
            msg.FromBytes( id_d_len[0] + id_d_len[1] + data_crc[:d_len] )

            for bs in id_d_len:
                msg.crc_calculated = smp_crc.CRC16( msg.crc_calculated, ord(bs) )
            for bs in data_crc[:-2]:
                msg.crc_calculated = smp_crc.CRC16( msg.crc_calculated, ord(bs) )
            if ( msg.crc_calculated != msg.crc_read ):
                # to give the caller a chance to see the received invalid msg store it in self.invalid_msg
                self.invalid_msg = msg
                raise IOError( "cSMPComSCHUNKUSB:Receive(): CRC error, read 0x%04x but calculated 0x%04x" % (msg.crc_read,msg.crc_calculated) )

            return msg

        except IndexError:
            self.options.debug_output_receive.write( " ?\n" )
            raise IOError( "Could not read enough data bytes" )
    #-----------------------------------------------------------------

# end of class cSMPComSCHUNKUSB
######################################################################

# the interface to register
interface = cSMPComSCHUNKUSB
