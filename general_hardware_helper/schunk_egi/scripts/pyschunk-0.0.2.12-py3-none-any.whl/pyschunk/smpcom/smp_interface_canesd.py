# -*- coding: latin-1 -*-
#######################################################################
# The python docstring for the module follows below.
#   (The doxygen input filter doxypy (http://code.foosel.org/doxypy)
#    allows you to use doxygen markup in the python docstrings for
#    files, classes and functions)
'''
  \file
  \section smpcom_smp_interface_canesd_py_general General file information

    \author   Osswald2
    \date     03.12.2009

  \brief
    Implementation of communication via CAN using ESD devices

  \section smpcom_smp_interface_canesd_py_copyright Copyright

  - Copyright (c) 2009 SCHUNK GmbH & Co. KG

  <HR>
  \internal

    \subsection smpcom_smp_interface_canesd_py_details SVN related, detailed file specific information:
      $LastChangedBy$
      $LastChangedDate$
      \par SVN file revision:
        $Id$

  \subsection smpcom_smp_interface_canesd_py_changelog Changelog of this file:
      \include smp_interface_canesd.py.log
'''
#######################################################################


#######################################################################
## \anchor smpcom_smp_interface_canesd_py_python_vars
#  \name   Python specific variables
#
#  Some definitions that describe the module for python.
#
#  @{

__author__    = "Dirk Osswald: dirk.osswald@de.schunk.com"
__url__       = "http://www.schunk.com"
__version__   = "$Id$"
__copyright__ = "Copyright (c) 2009 SCHUNK GmbH & Co. KG"

## end of doxygen name group smpcom_smp_interface_canesd_py_python_vars
#  @}
######################################################################


######################################################################
# import needed modules:

# standard python modules
import sys
import time

try:
    import ntcan
except ImportError:
    sys.stderr.write( "The python module ntcan is not available! Access to ESD CAN cards will not be available!\n" )
    sys.stderr.write( "  (ntcan is a python wrapper module provided by ESD to access its CAN cards from python)\n" )
    #raise  #reraise

# submodules from this package:
from pyschunk.smpcom import smp_message
from pyschunk.smpcom import smp_codes
from pyschunk.smpcom import smp_message_id
from pyschunk.smpcom import smptools

from pyschunk.tools.dbg import tDBG
#
######################################################################



######################################################################
# The actual classes

# Debug messages are now disabled by default
# To enable them on load define a flag in your __main__ module:
#   debug_flag_smp_interface_canesd = True
dbg = tDBG( False, "green", description="pyschunk.smpcom.smp_interface_canesd" )
try:
    dbg.SetFlag( sys.modules["__main__"].debug_flag_smp_interface_canesd )
except:
    pass

dbg << "Debug messages from " << __name__ << " are printed like this\n"

class cSMPComCANESD(object):
    '''
    Class to communicate via CAN using ESD devices
    '''

    default_net = 0                 # net
    default_baudrate = 500000       # baud rate
    _tx_queue_size=1                          # TxQueueSize [0, 10000]
    _rx_queue_size=2048                       # RxQueueSize [0, 10000]
    _tx_timeout_ms=1000                       # TxTimeOut in Millseconds
    _rx_timeout_ms=1000                       # RxTimeOut in Millseconds

    _baudrate_codes = dict( [(1000000,0x0),  # see ESD API documentation page 51
                             (800000, 0xE),
                             (666600, 0x1),
                             (500000, 0x2),
                             (333300, 0x3),
                             (250000, 0x4),
                             (166000, 0x5),
                             (125000, 0x6),
                             (100000, 0x7),
                             (83300, 0x10),
                             (66600, 0x8),
                             (50000, 0x9),
                             (33300, 0xA),
                             (20000, 0xB),
                             (12500, 0xC),
                             (10000, 0xD) ] )

    def __init__(self, options):
        '''CTor

        \param options - a structure describing the communication parameters,
                         like returned by options.cSMPComOptionParser.parse_args()
                         options.interface describes the port ("canesd", "canesdX", ...)
                         options.baudrate is the baudrate in bit/s (if 0 then self.default_baudrate is used)
                         options.debug > 0 enables debug messages

                         If option.interface == "canesd" then the default net 0 is used.
                         If you want to use other nets (e.g. net 1 ) then you can specifiy
                         it with option.interface = "canesd1" or the like.
        '''
        # make self.debug_level a copy of the options.debug_level, so that it can be manipulated independently
        self.debug_level = options.debug_level
        dbg.SetFlag(self.debug_level > 0)

        self.msgdict = {}
        self.oldest_timestamp = 0
        self.delete_incomplete_frag_time = 10 #after this time (in seconds) a incomplete fragment in the msgdict get deleted
        #---------------------
        # check if options.interface is a valid CAN ESD interface specification
        self.net = None
        if ( type( options.interface ) is str ):
            if (options.interface[0:6].lower() == "canesd" ):
                if ( len( options.interface ) > 6 ):
                    self.net = int(options.interface[6:])
                else:
                    self.net = self.default_net

        if self.net is None:
            raise ValueError( "options.interface=%r is not a valid ESD CAN interface specification!" % (options.interface) )

        if ( options.baudrate == 0 ):
            options.baudrate = self.default_baudrate
        self.options = options
        self.cif = None
        self._wcmsg = None
        self._rxmsg = None

        #---------------------

        self.t_send = 0.0
        self.t_receive = 0.0

        #self.ids_added = set()  #needed for ESD CAN-USB-mini, but not sufficient to make that work (bug 2305)


    def _prop_SetTimeout(self, timeout_s ):
        self._rx_timeout_ms = int(1000*timeout_s)
        if self.cif:
            self.cif.rx_timeout = self._rx_timeout_ms


    def _prop_GetTimeout(self ):
        return float(self._rx_timeout_ms)/1000.0


    timeout = property( _prop_GetTimeout, _prop_SetTimeout, None, "Timeout in seconds for receiving. Timeout = 0 means: return immediately even if no data is available (an IOError is raised in that case)" )


    @classmethod
    def GetHelpString(cls):
        '''Return a help string suitable for describing the command line parameters needed for this interface

        \remark: This classmethod gets called by the smp_optionparser.cSMPComOptionParser constructor
        '''
        return '''- canesd     : use the CAN ESD device with default net 0
        - canesdX    : where X is an integer, use the CAN ESD device with net X'''

    def Open(self, module_ids=None):
        '''
        Open connection to serial interface as configured by the options given to the constructor
        \param module_ids - the module ids to communicate with, if None (not given) then all modules are accepted
                            if given it must be a list of module_ids, even if only a single module_id is given.
        '''
        dbg << "Opening CAN connection to ESD device using net %d, baudrate %d\n" % (self.net,self.options.baudrate)

        # the order of parameters is somewhat mysterious.
        # From the examples in /cygdrive/c/Programme/ESD/CAN/SDK/bin32/CANscript/scripts/canopen.py
        #   it should be: NET, RxQS, RxTO, TxQS, TxTO
        # From the documentation for canOpen (CAN-API)
        #   the order should be:  net, flags, txqueuesize, rxqueuesize, txtimeout, rxtimeout,
        #
        # But the debugger reveals that when called with self.cif = ntcan.CIF( 0000, 1111,2222,3333,4444 )
        #   cif.rx_timeout = 2222   (as expected)
        #   cif.tx_timeout = 3333   (as NOT expected)
        #
        # further experiments (see src/experiments/tst-ntcan.py revealed that the following is correct:
        self.cif = ntcan.CIF( self.net,             # net number
                              self._rx_queue_size,  # receive queue size
                              self._rx_timeout_ms,  # receive timeout
                              self._tx_timeout_ms,  # transmit timeout
                              self._tx_queue_size ) # transmit queue size

        self.cif.baudrate = self._baudrate_codes[ self.options.baudrate ]

        #t0=time.time()
#        # set input filter to receive SMP messages from all modules
#        # - do not receive "group messages"
#        # - do not receive "To module" messages
        # ANOTE: This adding takes ca. 0.110s
        message_id = smp_message_id.cSMPMessageID()
        if module_ids is None:
            self.module_ids = list(range(256))
        else:
            self.module_ids = module_ids
        for module_id in self.module_ids:
            message_id.module_id = module_id
            message_id.is_module_id = True
            message_id.from_module = True

            for message_id.is_normal in (True,False):
                can_id = message_id.GetByte(0) << 8 | message_id.GetByte(1)
                #dbg << "adding CAN_ID %4d = 0x%03x\n" % (can_id, can_id)
                self.cif.canIdAdd( can_id )
                #self.ids_added.add( can_id ) #needed for ESD CAN-USB-mini, but not sufficient to make that work (bug 2305)

        # Following loop takes 1.2s!
        #for can_id in range( 1<<11 ):
        #    # ANOTE: for now receive all CAN IDs
        #    self.cif.canIdAdd( can_id ) #FIXME: IDs should be deleted in Close!

        # Following call takes 1.2s!
        #self.cif.canIdAdd( 0,(1<<11)-1 ) #FIXME: IDs should be deleted in Close!

        #t = self.cif.timestamp  # required for CAN-USB/2, see ntcan.CIF.canIdAdd() @UnusedVariable
        #t1=time.time()
        #print( "adding ids took %fs" % (t1-t0) )

#         self._wcmsg = ntcan.CMSG()
        self._wcmsg = ntcan.CMSG_T()
#         self._rxmsg = ntcan.CMSG()
        self._rxmsg = ntcan.CMSG_T()

        if ( self.cif.hardware <= 0x00ff ):
            # Usually self.cif.hardware is 16L for old CAN-USB-mini and 4096L for new CAN-USB/2.

            # We have an old hardware, i.e. ESD CAN-USB-mini, so
            # after the canIdAdd calls above we need to wait a little,
            # since else the first canWrite will fail with a timeout IOError
            # the time needed was determined experimentally to be up to 0.180 s
            # see smpcom.experiments.canwrite_initialdelay
            time.sleep(0.250) # wait a little longer to be on the safe side


    def Close(self):
        '''
        Close connection to serial interface.
        '''
        if self.cif:
            message_id = smp_message_id.cSMPMessageID()
            for module_id in self.module_ids:
                message_id.module_id = module_id
                message_id.is_module_id = True
                message_id.from_module = True

                for message_id.is_normal in (True,False):
                    can_id = message_id.GetByte(0) << 8 | message_id.GetByte(1)
                    #dbg << "deleting CAN_ID %4d = 0x%03x\n" % (can_id, can_id)
                    self.cif.canIdDelete( can_id )
                    #self.ids_added.discard( can_id ) #needed for ESD CAN-USB-mini, but not sufficient to make that work (bug 2305)

            #self.cif.canClose()
            del self.cif
        self.cif = None


    def FlushInput(self):
        '''Flush input
        '''
        if self.cif:
            try:
                # the new ntcan.py 2.0.0 provides this:
                self.cif.canPurge()
            except AttributeError:
                # the old ntcan.py provides this:
                self.cif.flush_rx_fifo()
            if ( self.debug_level > 0 and self.options.debug_output_receive ):
                self.options.debug_output_receive.write( "%s CAN%d : Input flushed\n" % (smptools.GetTimestamp(),self.net) )



    def Send(self, msg ):
        assert self.cif
        data = msg.GetByteList()[2:]

        can_id = (msg.id[0] << 8) | msg.id[1]
        d_len = len(data)
        assert d_len < 256

        # check if fragmentation is necessary
        if d_len > 7:
            # yes, so do fragmented sending
            frag_cmd = smp_codes.eCmdCode.FRAG_START
            for i in range( 0, len(data), 6 ):
                fragment = [ d_len, frag_cmd ] + data[i:min(len(data),i+6)]
                #print( "sending bytes %s" % repr( fragment ) )
                #FIXME: do fragmentation SMP style!
                self._Send(can_id, len(fragment), *fragment )
                d_len -= 6
                if ( d_len > 6 ):
                    frag_cmd = smp_codes.eCmdCode.FRAG_MIDDLE
                else:
                    frag_cmd = smp_codes.eCmdCode.FRAG_END
        else:
            # no so do unfragmented sending
            self._Send(can_id, d_len+1, d_len, *data )



    def _Send(self, can_id, length, *args ):
        '''Low level send of \a lenght bytes in *args via CAN ID \a can_id. No fragmentation is tried
        '''
        assert length <= 8
        assert len( args ) == length

        self._wcmsg.canWriteByte( self.cif, can_id, length, *args )
        self.t_send = time.time()

        if ( self.debug_level > 0 and self.options.debug_output_send ):
            s = smptools.GetTimestamp( self.t_send )
            s += " CAN%d>: " % (self.net)
            s += "can_id=0x%03x d_len=%d data=" % (can_id,args[0])
            for b in args[1:]:
                s += "0x%02x " % b
            self.options.debug_output_send.write( s+"\n" )


    def Receive(self, msg=None ):
        '''Over worked methode:
        Now its possible to receive mixed messages (fragmented and not fragmented ones) without loosing any data.

        If the interface receives a message after a fragment of a fragmented message the fragmented part didn't
        get lost but saved in self.msgdict. The remaining fragments can now be assigned when the Receive() methode
        gets called at a later point of time.

        \param msg - the expected message (cSMPMessage object)
        '''
        assert self.cif
        if ( msg is None ):
            msg = smp_message.cSMPMessage()
        else:
            msg = msg.Clone()

        complete = False

        while not complete:
            (can_id,b_len,d_len,cmd,data) = self._Receive()
            self.CheckTimestamp()

            if cmd == smp_codes.eCmdCode.FRAG_START:
                self.msgdict.setdefault("%r"%can_id, []).append(cMsgData( self._rxmsg.timestamp, can_id, b_len, d_len, data[0], data[1:] ))

            elif cmd == smp_codes.eCmdCode.FRAG_MIDDLE:
                matched_dlen = 0
                try:
                    for i in self.msgdict["%r"%can_id]:

                        if ( d_len == i.frag_next_d_len ):
                            self.TestForDoubleDlen(can_id, cmd)
                            matched_dlen       = i.frag_next_d_len
                            i.frag_next_d_len -= b_len - 2
                            i.data            += data
                            i.timestamp = self._rxmsg.timestamp
                            break

                    if ( matched_dlen == 0):
                        string =""
                        for i in self.msgdict["%r"%can_id]:
                            string = string + " 0x%02x;" %i.frag_next_d_len
                        raise IOError( "cSMPMixedMessage:ReceiveMixed(): received FRAG_MIDDLE frame with non matching d_len=0x%02x, expected: %s" % (d_len, string) )

                except KeyError:
                    for i in self.msgdict.keys():
                        string = string + " 0x%03x;" %i
                    raise IOError( "cSMPMixedMessage:ReceiveMixed(): received FRAG_MIDDLE frame but no FRAG_START before!" )

            elif cmd == smp_codes.eCmdCode.FRAG_END:
                try:
                    for i in  self.msgdict["%r"%can_id]:

                        if ( d_len == i.frag_next_d_len ):
                            self.TestForDoubleDlen(can_id, cmd)
                            i.frag_next_d_len -= b_len - 2
                            i.data            += data

                            msg.FromBytes( i.can_id>>8, i.can_id & 0xff, i.cmd, i.data )

                            self.msgdict["%r"%can_id].remove(i)
                            if ( len(self.msgdict["%r"%can_id]) == 0 ):
                                self.msgdict.pop("%r"%can_id, None)

                            self.RefreshOldestTimestamp()
                            return msg

                    #No matching d_len in self.msgdict["%r"%can_id]
                    string =""
                    for i in self.msgdict["%r"%can_id]:
                        string = string + " 0x%02x;" %i.frag_next_d_len
                    raise IOError( "cSMPMixedMessage:ReceiveMixed(): received FRAG_END frame with non matching d_len=0x%02x, expected %s" % (d_len, string) )

                except KeyError:
                    for i in self.msgdict.keys():
                        string = string + " 0x%03x;" %i
                    raise IOError( "cSMPMixedMessage:ReceiveMixed(): received FRAG_END frame but no FRAG_START before!" )

            else:
                self.RefreshOldestTimestamp()
                msg.FromBytes( can_id>>8, can_id & 0xff, cmd, data )
                return msg

    def _Receive(self):
        '''Low level receive function of a CAN frame

        \return a tuple (can_id,b_len,d_len,cmd,databytes)
        '''
        if ( self._rx_timeout_ms > 0 ):
            self._rxmsg.canRead( self.cif )
        else:
            # timout is 0 so we just want to peek if any data is available without waiting:
            self._rxmsg.canTake( self.cif )
            if ( self._rxmsg.len == ntcan.NTCAN_NO_DATA ):
                raise IOError( "cSMPComCANESD._Receive(): No data received!" )
        self.t_receive = time.time()

        if ( self.debug_level > 0 and self.options.debug_output_receive ):
            s = smptools.GetTimestamp( self.t_receive )
            s += " CAN%d<: " % (self.net)
            s += "can_id=0x%03x d_len=%d data=" % (self._rxmsg.id,self._rxmsg.data.c[0])
            for i in range(1,min(8,self._rxmsg.len & 0x0f)): # sometimes .len is 36=0x24 for a received CAN message with actual DLC=4?!?
                s += "0x%02x " % self._rxmsg.data.c[i]
            if ( self._rxmsg.len > 8 ):
                s += "  DLC=%d!!!" % (self._rxmsg.len)
            self.options.debug_output_receive.write( s+"\n" )

        #dbg = tDBG(True,"cyan", description="pyschunk.smpcom.smp_interface_canesd.cSMPComCANESD._Receive")
        #dbg << "cSMPComCANESD.Receive() received <<< can_id=0x%03x d_len=%d data=" % (self._rxmsg.id,self._rxmsg.data.c[0]),
        #for i in range(1,self._rxmsg.len):
        #    dbg << "0x%02x " % self._rxmsg.data.c[i]
        #dbg << "\n"

        if ( self._rxmsg.len < 2 ):
            raise IOError( "cSMPComCANESD._Receive(): received frame with len=%d < 2 => not an SMP frame!" % (self._rxmsg.len) )

        can_id = self._rxmsg.id
        b_len = self._rxmsg.len
        d_len = self._rxmsg.data.c[0]
        cmd = self._rxmsg.data.c[1]
        return (can_id,b_len,d_len,cmd,self._rxmsg.data.c[2:b_len])

    def CheckTimestamp(self):
        '''Checks if a fragmented message which is saved in the self.msgdict is older than "self.delete_incomplete_frag_time" seconds.
        If there is one it get deleted and the self.oldest_timestamp variable get set to the next
        oldest saved fragmented message timestamp.
        '''
        if (self.oldest_timestamp == 0):
            self.oldest_timestamp = self._rxmsg.timestamp
            #print( "oldest_timestamp set" )

        elif ((self._rxmsg.timestamp - self.oldest_timestamp) > self.delete_incomplete_frag_time * 1000000):#Message older than 10 000 000 = 10s ??
            raise IOError( "cSMPComCANESD.Receive(): saved fragment is older than %rs (%rs) and get deleted"% (self.delete_incomplete_frag_time, int((self._rxmsg.timestamp - self.oldest_timestamp)/1000000)))

            #Delete the old fragments
            for msg_list in self.msgdict.values():
                for i in range( len( msg_list ) ):
                    if (self.oldest_timestamp == msg_list[i].timestamp):
                            msg_list.pop(i)
            #refresh oldest timestamp
            self.RefreshOldestTimestamp()

    def RefreshOldestTimestamp(self ):
        '''self.oldest_timestamp get set to the "oldest" value
        '''
        if ( len(self.msgdict) != 0 ):
            for k in self.msgdict.values():
                for i in k:
                    if (self.oldest_timestamp > i.timestamp):
                        self.oldest_timestamp = i.timestamp
                        #print( "timestamp refreshed" )
        else:
            self.oldest_timestamp = 0

    def TestForDoubleDlen(self, can_id, cmd):
        '''Method which check a list of cMsgData objects for fragmented messages with the same
        frag_next_d_len Byte.
        If two get found it is impossible to choose the related one.
        '''

        for n in range(len(self.msgdict["%r"%can_id])):

            for k in range(1+n, len(self.msgdict["%r"%can_id])):

                if( self.msgdict["%r"%can_id][n].frag_next_d_len == self.msgdict["%r"%can_id][k].frag_next_d_len ):

                    if ( cmd == smp_codes.eCmdCode.FRAG_MIDDLE ):
                        raise IOError(  "TestForDoubleDlen: cSMPMixedMessage:ReceiveMixed(): received FRAG_MIDDLE frame which match with more than one of the received fragmented messages. \nThe fragment could be misplaced!")

                    elif ( cmd == smp_codes.eCmdCode.FRAG_END ):
                        raise IOError(  "TestForDoubleDlen: cSMPMixedMessage:ReceiveMixed(): received FRAG_END frame which match with more than one of the received fragmented messages. \nThe fragment could be misplaced!")
    #-----------------------------------------------------------------

# end of class cSMPComCANESD
######################################################################

class cMsgData():
    '''Class which own specific data of a received can message.
    '''
    def __init__(self, timestamp, can_id, b_len, d_len, cmd, data):
        self.can_id = can_id
        self.b_len = b_len
        self.d_len = d_len
        self.cmd = cmd
        self.data = data
        self.frag_next_d_len = d_len - (b_len - 2)
        self.timestamp =  timestamp
        self.t = time.clock()#according to the python documentation "this is the function to use for benchmarking Python or timing algorithms" instead of time.time()

# the interface to register
if ( "ntcan" in sys.modules ):
    interface = cSMPComCANESD
else:
    interface = None
