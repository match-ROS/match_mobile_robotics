# -*- coding: latin-1 -*-
#######################################################################
# The python docstring for the module follows below.
#   (The doxygen input filter doxypy (http://code.foosel.org/doxypy)
#    allows you to use doxygen markup in the python docstrings for
#    files, classes and functions)
'''
  \file
  \section smpcom_smp_interfaces_py_general General file information

    \author   Osswald2
    \date     11.12.2009

  \brief
    Implementation of the generic access to communication interfaces

  \section smpcom_smp_interfaces_py_copyright Copyright

  - Copyright (c) 2009 SCHUNK GmbH & Co. KG

  <HR>
  \internal

    \subsection smpcom_smp_interfaces_py_details SVN related, detailed file specific information:
      $LastChangedBy$
      $LastChangedDate$
      \par SVN file revision:
        $Id$

  \subsection smpcom_smp_interfaces_py_changelog Changelog of this file:
      \include smp_interfaces.py.log
'''
#######################################################################


#######################################################################
## \anchor smpcom_smp_interfaces_py_python_vars
#  \name   Python specific variables
#
#  Some definitions that describe the module for python.
#
#  @{

__author__    = "Dirk Osswald: dirk.osswald@de.schunk.com"
__url__       = "http://www.schunk.com"
__version__   = "$Id$"
__copyright__ = "Copyright (c) 2009 SCHUNK GmbH & Co. KG"

## end of doxygen name group smpcom_smp_interfaces_py_python_vars
#  @}
######################################################################


######################################################################
# import needed modules:

# standard python modules

# submodules from this package:
from pyschunk.smpcom import factory

#
######################################################################





######################################################################
# The actual classes

class cInterfaceFactory(factory.cFactory):
    def __init__(self, package="pyschunk.smpcom", pattern="smp_interface_*.py" ):
        ''' Create factory of communication interfaces and imports all modules that match \a pattern in \a dir
        '''
#        print( "1!!!" )
#        print( "name=", __name__ )
#        print( "dirname", os.path.dirname(__name__) )
#        print( "curdir=",os.curdir )
#        print( "getcwd=",os.getcwd() )

        factory.cFactory.__init__(self,"interface_class_factory")
        self.Import( package, pattern )
        assert( self.factory_modules != [] )

        # register the interfaces from the imported modules to the communication interfaces factory
        for m in self.factory_modules:
            if ( m.interface is not None ):
                self.Register( m.interface )


    def Create( self, options ):
        ''' Try to construct a communication interface according to \a options.
        This will try all registered implementations and return the first one
        that does not throw an exception
        '''
        for klass in self:
            try:
                return klass( options )
            except ValueError:
                pass
        raise ValueError( "The provided options do not specify a valid interface from the list of known interfaces: %r" % (map( lambda c : c.__name__, self.factory) ) )

# end of class
##############

## The singleton that holds the interface factory
interfaces = cInterfaceFactory()
