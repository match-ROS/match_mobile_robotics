'''
Created on 16.08.2012

@author: osswald2

Constants and functions for the device profile DS402 / iec61800-7-201
see file://D:/home/osswald2/SCHUNK/CANopen/doc/CiA/iec61800-7-201{ed1.0}en.pdf
'''

import pyschunk.tools.util
from . import esdutil
import time

from pyschunk.tools.dbg import tDBG
dbg = tDBG( False, "cyan", description="pyschunk.canopen.ds402.dbg" )
dbg2 = tDBG( False, "cyan", description="pyschunk.canopen.ds402.dbg2" ) # enable for debugging state


# bit masks for controlword
eControlwordMask = pyschunk.tools.util.enum()
eControlwordMask.Switch_On =                 (1<<0)
eControlwordMask.Enable_Voltage =            (1<<1)  # (was called Disable_Voltage in DS402)
eControlwordMask.Quick_Stop =                (1<<2)
eControlwordMask.Enable_Operation =          (1<<3)
eControlwordMask.New_Setpoint =              (1<<4)  # in Profile Position Mode
eControlwordMask.Operation_Mode_Specific0 =  (1<<4)
eControlwordMask.Enable_Interpolation =      (1<<4)  # in Interpolated Position Mode
eControlwordMask.Enable_Ramp =               (1<<4)  # in Velocity Mode
eControlwordMask.Homing_Operation_Start =    (1<<4)  # in Homing Mode
eControlwordMask.Change_Set_Immediately =    (1<<5)  # in Profile Position Mode
eControlwordMask.Operation_Mode_Specific1 =  (1<<5)
eControlwordMask.Unlock_Ramp =               (1<<5)  # in Velocity Mode
eControlwordMask.Absolute_Relative =         (1<<6)  # in Profile Position Mode
eControlwordMask.Operation_Mode_Specific2 =  (1<<6)
eControlwordMask.Reference_Ramp =            (1<<6)  # in Velocity Mode
eControlwordMask.Reset_Fault =               (1<<7)
eControlwordMask.Halt =                      (1<<8)
eControlwordMask.Change_On_Setpoint =        (1<<9)  # in Profile Position Mode
eControlwordMask.Operation_Mode_Specific3 =  (1<<9)
eControlwordMask.Reserved1 =                 (1<<10)
eControlwordMask.Manufacturer_Specific0 =    (1<<11)
eControlwordMask.Manufacturer_Specific1 =    (1<<12)
eControlwordMask.Manufacturer_Specific2 =    (1<<13)
eControlwordMask.Manufacturer_Specific3 =    (1<<14)
eControlwordMask.Manufacturer_Specific4 =    (1<<15)

# (mask,value,transitionlist) of the controlword for the different commands
# see DSP-402 section 8.4.1 page 41 file://D:/home/osswald2/SCHUNK/CANopen/doc/CiA/iec61800-7-201{ed1.0}en.pdf#page=43
eCommand = pyschunk.tools.util.enum()
eCommand.Shutdown                   = (0x0087,0x0006,[2,6,8])     # xxxx xxxx 0xxx x110b
eCommand.Switch_on                  = (0x008f,0x0007,[3])         # xxxx xxxx 0xxx 0111b
eCommand.Switch_on_enable_operation = (0x008f,0x000f,[3,4])       # xxxx xxxx 0xxx 1111b
eCommand.Disable_voltage            = (0x0082,0x0000,[7,9,10,12]) # xxxx xxxx 0xxx xx0xb
eCommand.Quick_stop                 = (0x0086,0x0002,[7,10,11])   # xxxx xxxx 0xxx x01xb
eCommand.Disable_operation          = (0x008f,0x0007,[5])         # xxxx xxxx 0xxx 0111b #!!! same as Switch_on !!!
eCommand.Enable_operation           = (0x008f,0x000f,[4,16])      # xxxx xxxx 0xxx 1111b #!!! same as Switch_on_enable_operation !!!
eCommand.Fault_reset                = (0x0080,0x0080,[15])        # xxxx xxxx 1xxx xxxxb

#a = eControlwordMask.Halt

# bit masks for statusword
eStatuswordMask = pyschunk.tools.util.enum()
eStatuswordMask.Ready_to_Switch_On =        (1<<0)
eStatuswordMask.Switched_On =               (1<<1)
eStatuswordMask.Operation_Enabled =         (1<<2)
eStatuswordMask.Fault =                     (1<<3)
eStatuswordMask.Voltage_Enabled =           (1<<4)
eStatuswordMask.Quick_Stop =                (1<<5)
eStatuswordMask.Switch_On_Disabled =        (1<<6)
eStatuswordMask.Warning =                   (1<<7)
eStatuswordMask.Manufacturer_Specific0 =    (1<<8)
eStatuswordMask.Moving =                    (1<<8)
eStatuswordMask.Remote =                    (1<<9)
eStatuswordMask.Target_Reached =            (1<<10)
eStatuswordMask.Internal_Limit_Active =     (1<<11)
eStatuswordMask.Operation_Mode_Specific0 =  (1<<12)
eStatuswordMask.Set_Point_Acknowledge =     (1<<12)  # in Profile Position Mode
eStatuswordMask.Homing_Attained =           (1<<12)  # in Homing Mode
eStatuswordMask.Operation_Mode_Specific1 =  (1<<13)
eStatuswordMask.Following_Error =           (1<<13)  # in Profile Position Mode
eStatuswordMask.Homing_Error =              (1<<13)  # in Homing Mode
eStatuswordMask.Manufacturer_Specific1 =    (1<<14)
eStatuswordMask.Move_Blocked =              (1<<14)
eStatuswordMask.Manufacturer_Specific2 =    (1<<15)
eStatuswordMask.Referenced =                (1<<15)

# (mask,value) of the statusword for the different states
eState = pyschunk.tools.util.enum()
eState.Not_Ready_To_Switch_On =  (0x004f,0x0000) # xxxx xxxx x0xx 0000b
eState.Switch_On_Disabled =      (0x004f,0x0040) # xxxx xxxx x1xx 0000b
eState.Ready_To_Switch_On =      (0x006f,0x0021) # xxxx xxxx x01x 0001b
eState.Switched_On =             (0x006f,0x0023) # xxxx xxxx x01x 0011b
eState.Operation_Enabled =       (0x006f,0x0027) # xxxx xxxx x01x 0111b
eState.Quick_Stop_Active =       (0x006f,0x0007) # xxxx xxxx x00x 0111b
eState.Fault_Reaction_Active =   (0x004f,0x000f) # xxxx xxxx x0xx 1111b
eState.Fault =                   (0x004f,0x0008) # xxxx xxxx x0xx 1000b

eModeOfOperation = pyschunk.tools.util.enum()
eModeOfOperation.Reserved_0 =                   0
eModeOfOperation.Profile_Position_Mode =        1
eModeOfOperation.Velocity_Mode =                2
eModeOfOperation.Profile_Velocity_Mode =        3
eModeOfOperation.Torque_Profile_Mode =          4
eModeOfOperation.Reserved_1 =                   5
eModeOfOperation.Homing_Mode =                  6
eModeOfOperation.Interpolated_Position_Mode =   7
eModeOfOperation.Cyclic_Sync_Position_Mode =    8
eModeOfOperation.Cyclic_Sync_Velocity_Mode =    9
eModeOfOperation.Cyclic_Sync_Torque_Mode =      10

def GetStatusword( pdo_consumer, node_no, tpdo_no, max_age_s=None ):
    '''Return CANopen CiA DS402 / IEC 61800-7-200 statusword from node node_no TPDO tpdo_No.
    Will work with proper PDO-Mapping only! statusword must be in bytes 0,1 of TPDO \a tpdo_no of node \a node_no
    If max_age_s is not None then an exeptionsi thrown if the age of the TPDO is older than max_age_s.
    '''
    #print( "old GetStatusword" ) #FIXed: remove me
    pdo = pdo_consumer.GetLastPDO(node_no, tpdo_no)
    age_s = time.time() - pdo.time
    #print( "age_s=%f" % age_s )
    if ( max_age_s and  age_s > max_age_s ):
        raise IOError( "TPDO %d from node %d is older (%.3fs) than allowed (%.3fs)" % (tpdo_no, node_no, age_s, max_age_s ) )
    return esdutil.c2wr( *pdo.data.c[0:2] )


def GetActualPosition( pdo_consumer, node_no, tpdo_no ):
    '''Will work with proper PDO-Mapping only! position must be in bytes 4-7 of TPDO \a tpdo_no of node \a node_no
    '''
    #print( "old GetActualPosition" ) #FIXed: remove me
    return esdutil.c2i32r( *pdo_consumer.GetLastPDO(node_no, tpdo_no).data.c[4:8] )


def DetermineState( sw ):
    for t in list(eState.values()):
        try:
            (mask,value) = t
            if ( (sw & mask) == value ):
                return (mask,value)
        except TypeError:
            pass # can happen for invalid states since eState.values() contains enum._last = -1 as last value, which yields "TypeError: 'int' object is not iterable" here
    raise EnvironmentError( "Unknown state 0x%04x!" % sw )


def DetermineCommand( cw ):
    for (mask,value,transitionlist) in list(eCommand.values()):
        if ( (cw & mask) == value ):
            return (mask,value,transitionlist)
    raise EnvironmentError( "Unknown command 0x%04x!" % cw )

def WaitForState( state, pdo_consumer, node_no, tpdo_no, timeout_s, raise_on_fault=True ):
    end = time.time() + timeout_s #+ 5 # FIXed: remove +5
    fault_mask,fault_value = eState.Fault
    old_sw = None
    while time.time() < end:
        sw = GetStatusword( pdo_consumer, node_no, tpdo_no )
        dbg2 << "sw=0x%04x\n" % sw
        mask,value = state
        if ( (sw & mask) == value ):
            return
        if ( raise_on_fault and ((sw & fault_mask) == fault_value) ):
            raise EnvironmentError( "Fault signaled from node %d" % node_no )
        if ( sw != old_sw ):
            dbg2 << "Node %d changed state to %r\n" % (node_no, eState.GetName(DetermineState(sw)))
            old_sw = sw
    raise EnvironmentError( "Timeout while waiting for state %r of node %d, still in state %r" % (eState.GetName(state),node_no,eState.GetName(DetermineState(sw))) )

def OperationEnable( options, rpdo, node_no, tpdo_no, pdo_consumer ):
    '''Make selected node enter operation enabled state

    \param rpdos - list of rpdos
    \param pdo_consumer - PDO consumer to receive responses
    '''

    #---
    # clear received TPDOs:
    pdo_consumer.pdo_available[(node_no,tpdo_no)].clear()
    #---

    #---
    # Receive TPDO:
    time.sleep( 0.5 )
    pdo_consumer.pdo_available[(node_no,tpdo_no)].wait( 5*options.period_s )
    if ( not pdo_consumer.pdo_available[(node_no,tpdo_no)].isSet() ):
        # timeout occured
        raise IOError( "Could not receive TPDO %d from node %d. Please check PDO mapping." % (tpdo_no, node_no) )
    pdo_consumer.pdo_available[(node_no,tpdo_no)].clear()
    # tpdo available
    #---

    EnterOperationEnable( options, rpdo, node_no, tpdo_no, pdo_consumer )

def EnterOperationEnable( options, rpdo, node_no, tpdo_no, pdo_consumer ):
    # halt reset
    rpdo.ClrControlwordBit( eControlwordMask.Halt )

    sw = GetStatusword( pdo_consumer, node_no, tpdo_no )
    current_state = DetermineState( sw )
    if ( current_state == eState.Operation_Enabled ):
        # already in state Operation_Enabled
        dbg2 << "Node %d already in Operation Enabled\n" % node_no
        return
    else:
        dbg2 << "Node %d statusword=0x%04x = %s\n" % (node_no, sw, eState.GetName( current_state ))
    #import sys
    #sys.exit(0)

    # t15 fault reset, if required
    if ( sw & eStatuswordMask.Fault ):
        rpdo.SetControlwordBit( eControlwordMask.Reset_Fault )
        dbg2 << "Node %d fault reset\n" % node_no
        WaitForState( eState.Switch_On_Disabled, pdo_consumer, node_no, tpdo_no, 3*options.period_s, raise_on_fault=False )

    # t2 shutdown
    dbg2 << "Node %d shutting down\n" % node_no
    rpdo.ClrControlwordBit( eControlwordMask.Switch_On )
    rpdo.SetControlwordBit( eControlwordMask.Enable_Voltage )
    rpdo.SetControlwordBit( eControlwordMask.Quick_Stop )
    rpdo.ClrControlwordBit( eControlwordMask.Reset_Fault )
    WaitForState( eState.Ready_To_Switch_On, pdo_consumer, node_no, tpdo_no, 3*options.period_s )
    dbg2 << "Node %d shutdown\n" % node_no


    # t3 switch on
    dbg2 << "Node %d switching on\n" % node_no
    rpdo.SetControlwordBit( eControlwordMask.Switch_On )
    rpdo.SetControlwordBit( eControlwordMask.Enable_Voltage )
    rpdo.SetControlwordBit( eControlwordMask.Quick_Stop )
    rpdo.ClrControlwordBit( eControlwordMask.Enable_Operation )
    rpdo.ClrControlwordBit( eControlwordMask.Reset_Fault )
    WaitForState( eState.Switched_On, pdo_consumer, node_no, tpdo_no, 3*options.period_s )
    dbg2 << "Node %d switch on\n" % node_no

    # t4 Enable
    dbg2 << "Node %d enabling\n" % node_no
    rpdo.SetControlwordBit( eControlwordMask.Switch_On )
    rpdo.SetControlwordBit( eControlwordMask.Enable_Voltage )
    rpdo.SetControlwordBit( eControlwordMask.Quick_Stop )
    rpdo.SetControlwordBit( eControlwordMask.Enable_Operation )
    rpdo.ClrControlwordBit( eControlwordMask.Reset_Fault )
    WaitForState( eState.Operation_Enabled, pdo_consumer, node_no, tpdo_no, 10.0 )#3*options.period_s )
    dbg2 << "Node %d Operation Enabled\n" % node_no
#----------------------------------------------------------------------

def OperationDisable( options, rpdo, node_no, tpdo_no, pdo_consumer ):
    '''Make selected node enter ready to switch on state

    \param rpdos - list of rpdos
    \param pdo_consumer - PDO consumer to receive responses
    '''

    # t8 shutdown
    rpdo.ClrControlwordBit( eControlwordMask.Switch_On )
    rpdo.SetControlwordBit( eControlwordMask.Enable_Voltage )
    rpdo.SetControlwordBit( eControlwordMask.Quick_Stop )
    rpdo.ClrControlwordBit( eControlwordMask.Reset_Fault )
    WaitForState( eState.Ready_To_Switch_On, pdo_consumer, node_no, tpdo_no, 3*options.period_s, raise_on_fault=False  )
    dbg << "Node %d shutdown\n" % node_no

    dbg << "Node %d Operation Disabled\n" % node_no
#----------------------------------------------------------------------

def TriggerUpload( sdo, node_no, t ):
    """trigger upload log
    """
    # 2004/2 logging_trigger_time
    sdo.writeFloat ( node_no, 0x2004, 0x02, t )  # node,index,subindex,data)
    print( "Node %2d: log data upload triggered at t=%f" % (node_no,t) )


