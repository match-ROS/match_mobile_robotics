# -*- coding: latin-1 -*-
#######################################################################
# The python docstring for the module follows below.
#   (The doxygen input filter doxypy (http://code.foosel.org/doxypy)
#    allows you to use doxygen markup in the python docstrings for
#    files, classes and functions)
'''
  \file
  \section smpcom_smp_optionparser_py_general General file information

    \author   Osswald2
    \date     03.12.2009

  \brief
    Implementation of command line option parser

  \section smpcom_smp_optionparser_py_copyright Copyright

  - Copyright (c) 2009 SCHUNK GmbH & Co. KG

  <HR>
  \internal

    \subsection smpcom_smp_optionparser_py_details SVN related, detailed file specific information:
      $LastChangedBy$
      $LastChangedDate$
      \par SVN file revision:
        $Id$

  \subsection smpcom_smp_optionparser_py_changelog Changelog of this file:
      \include smp_optionparser.py.log
'''
#######################################################################


#######################################################################
## \anchor smpcom_smp_optionparser_py_python_vars
#  \name   Python specific variables
#
#  Some definitions that describe the module for python.
#
#  @{

__author__    = "Dirk Osswald: dirk.osswald@de.schunk.com"
__url__       = "http://www.schunk.com"
__version__   = "$Id$"
__copyright__ = "Copyright (c) 2009 SCHUNK GmbH & Co. KG"

## end of doxygen name group smpcom_smp_optionparser_py_python_vars
#  @}
######################################################################


######################################################################
# import needed modules:

# standard python modules
import sys
import os
import optparse

from pyschunk.tools.dbg import tDBG

# submodules from this package:
from pyschunk.smpcom import smp_interfaces

#
######################################################################


dbg = tDBG( True, "blue", description="pyschunk.smpcom.smp_optionparser" )


######################################################################
# The actual classes

# This is somewhat hackish, but we have to modify the list of
# allowed attributes to optparse.OptionParser.add_option().
# When add_option( ... keep_off_settingsfile=true ... ) is used, then
# that option is not recorded to the settings file
if ( "keep_off_settingsfile" not in optparse.Option.ATTRS ):
    optparse.Option.ATTRS.append("keep_off_settingsfile")

class cSMPComOptionParser(optparse.OptionParser):
    '''Customized OptionParser
    '''
    #-----------------------------------------------------------------
    def CBDebugLog( self, option, opt_str, value, parser, *args, **kwarg ):  # @UnusedVariable
        '''Callback for the -l | --debuglog | --debuglog_send | --debuglog_receive option
        '''
        if ( value == "stderr" ):
            debug_output = sys.stderr
        elif ( value == "stdout" ):
            debug_output = sys.stdout
        else:
            mode = "w"
            if ( value[0] == "+" ):
                mode = "a"
                value = value[1:]
            try:
                debug_output = open( name=value, mode=mode, buffering=1 )
            except IOError as e:
                raise optparse.OptionValueError( "Could not open debug logfile '%s': %s" % (value, str(e)) )

        setattr( parser.values, option.dest, debug_output )

    def KeepOffSettingsfile(self, option_name ):
        '''  \return True if \a option_name should be kept out of the settingsfile
        '''
        for o in self._get_all_options():##option_list:
            if (o.dest != option_name):
                continue       # other option
            if o.dest is None:
                return True    # right option, but without destination, so keep off settingsfile
            try:
                if (o.keep_off_settingsfile):
                    return True # right option found and true, so keep off settingsfile
            except KeyError:
                pass
            return False # found but false, so keep in settingsfile
        return False # not found or false, so keep in settingsfile


    def GetSettings(self):
        ''' \return a dictionary of values from the settingsfile
        '''
        settings_values = dict()
        if ( os.path.exists( self.settingsfile ) and os.path.isfile( self.settingsfile ) ):
            dbg << "cSMPComOptionParser.GetSettings(): Reading settings from file %r\n" % self.settingsfile
            f = open( self.settingsfile, "r" )
            lines = f.readlines()
            f.close()
            for option in self._get_all_options():
                #(k,v) in values.__dict__.iteritems():
                if ( self.KeepOffSettingsfile( option.dest ) ):
                    continue
                for l in lines:
                    k_v = l.rstrip("\r\n").split("=",1)
                    k = k_v[0]
                    v = k_v[1]
                    if ( k != option.dest ):
                        continue

                    if ( (option.type is not None and type(option.type) is bool) or (option.default is not None and type(option.default) is bool) ):
                        settings_values[k] = eval(v)
                    else:
                        opt_str = option.get_opt_string()
                        settings_values[k] = option.convert_value(opt_str, v)

        return settings_values

    def SetSettings(self):
        ''' Save current settings to the settingsfile
        '''
        dbg << "cSMPComOptionParser.SetSettings(): Writing settings to file %r\n" % self.settingsfile
        f = open( self.settingsfile, "w" )
        for (k,v) in self.values.__dict__.iteritems():
            if ( self.KeepOffSettingsfile( k ) ):
                continue
            f.write( str(k) + "=" + str(v) + "\n" )
        f.close()

    def parse_args(self, args=None, values=None):
        '''overloaded version of the optparse.OptionParser.parse_args() method
        parse the args and perform some actions if requested (like reading version info from SDH)
        '''

        #-----
        # try to read options from settingsfile in values
        if values is None:
            values = self.get_default_values()

        settings_values = self.GetSettings()

        # now overwrite the already existing (default) values with the values read from the settingsfile:
        values._update_careful( settings_values )
        #-----

        # call method of parent class to do the actual parsing
        (options,args) = optparse.OptionParser.parse_args( self, args, values )

        #-----
        # if requested store current options to settingsfile:
        if ( options.savesettings ):
            self.SetSettings()
        #-----

        #-----
        # if requested store current options to settingsfile:
        if ( options.do_show_version ):
            print ("Version: %r" % self.revision)
            sys.exit(0)
        #-----

        #-----
        # If a password contains chars like "`" then python3win or bash or cmd
        # cannot handle these properly, therefore the user can replace them
        # with "\\\x60". The code below evaluates that back to a normal string.
        if ( r"\x" in options.passwords ):
            options.passwords = eval( '"' + options.passwords + '"' )
        #-----


        # return parsing results
        return (options,args)


    #def add_option(self,):

    #-----------------------------------------------------------------
    def __init__(self, usage = "", revision = "", settingsfile = None, default_debug_level=0, default_interface="COM1" ):
        '''
        Create a cSMPComOptionParser instance

        \param self     - reference to the object itself
        \param usage    - A string describing the purpose of the calling script
        \param revision - A string describing the revision of the calling script
        \param settingsfile - name of a file to read options from in home and current directory, if None (default) then the name is constructed from "argv[0]"
        '''
        def GetInterfacesHelpString():
            ''' Local helper function to read help string from interfaces
            '''
            result = ""
            for i in smp_interfaces.interfaces:
                try:
                    result += i.GetHelpString() + "\n"
                except AttributeError:
                    # some interfaces (e.g. dummy interfaces for testing) might not have i.GetHelpString()
                    pass

            return result

        optparse.OptionParser.__init__( self, usage )
        self.revision = revision

        #####
        # init self.settingsfile from settingsfile
        if settingsfile is None:
            settingsfile = "." + os.path.basename(sys.argv[0]).rsplit(".",1)[0] + ".set"
            #print( "!!! using default settingsfilename", settingsfile )

        if os.path.isabs(settingsfile):
            self.settingsfile = settingsfile
        else:
            self.settingsfile = os.path.join(".", settingsfile)
        #####

        # add common options:
        self.add_option( "-d", "--debug",
                         dest="debug_level", default=default_debug_level, type=int, metavar="LEVEL",
                         help="Print debug messages of level LEVEL or lower while processing the python script. Level 0: No messages,\r 1: Script-level messages, 2: cSDH-level messages, 3: cSDHSerial-level messages\r Default is %r" % default_debug_level )
        self.add_option( "-l", "--debuglog", keep_off_settingsfile=True,
                         dest="debug_output", default=sys.stderr, type=str, metavar="LOGFILE",
                         action="callback", callback=self.CBDebugLog,
                         help="Redirect the printed debug messages to LOGFILE instead of standard error (default). If LOGFILE starts with '+' then the output will be appended to the file (without the leading '+'), else the file will be rewritten." )
        self.add_option( "--debuglogsend", keep_off_settingsfile=True,
                         dest="debug_output_send", default=sys.stderr, type=str, metavar="LOGFILE",
                         action="callback", callback=self.CBDebugLog,
                         help="Redirect the debug output for the outgoing communication to LOGFILE instead of standard error (default). If LOGFILE starts with '+' then the output will be appended to the file (without the leading '+'), else the file will be rewritten." )
        self.add_option( "--debuglogrecveive", keep_off_settingsfile=True,
                         dest="debug_output_receive", default=sys.stderr, type=str, metavar="LOGFILE",
                         action="callback", callback=self.CBDebugLog,
                         help="Redirect the debug output for the incoming communication to LOGFILE instead of standard error (default). If LOGFILE starts with '+' then the output will be appended to the file (without the leading '+'), else the file will be rewritten." )
        self.add_option( "-v", "--version", keep_off_settingsfile=True,
                         dest="do_show_version", default=False, action="store_true",
                         help="Print the version (revision/release names) of the program, then exit.")
        self.add_option( "--savesettings", keep_off_settingsfile=True,
                         dest="savesettings", default=False, action="store_true",
                         help="after parsing the command line options their values are stored in the settings file '%s' for the script and are thus reused automatically on the next invocation." % self.settingsfile )

        self.add_option( "--interface", type=str,
                         dest="interface", default=default_interface, metavar="INTERFACE",
                         help='''Use INTERFACE as communication interface. Valid interfaces are:\r\n
                         %s
                         \r\nDefault is %r
                         ''' % (GetInterfacesHelpString(), default_interface) )

#        self.add_option( "--net",
#                         dest="net", default=0, type=int, metavar="NET",
#                         help="use the ESD CAN net number NET. Only used if INTERFACE is esdcan" )
        self.add_option( "--baudrate", "--baud", "-b",
                         dest="baudrate", default=0, type=int, metavar="BAUDRATE",
                         help="use the BAUDRATE for communication. Default is 115200 Bit/s for RS232 and 500 kBit/s for CAN." )
        self.add_option( "--password",
                         dest="passwords", default="Schunk,22", type=str, metavar="PASSWORDS",
                         help="""For some operations elevated rights are required.
                         PASSWORDS is a comma separated list of possible passwords to use.
                         Default is '%default'.""" )

        #---------------------

    #-----------------------------------------------------------------

# end of class SMPComOptions
######################################################################
