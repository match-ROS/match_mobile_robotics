'''
Created on 14.10.2013

some usefull unicode symbols

@author: Osswald2
'''


triangle_up         = u"\u25B2" #black triangle up
triangle_left       = u"\u25C0" #black triangle left
triangle_right      = u"\u25B6" #black triangle right
triangle_down       = u"\u25BC" #black triangle down
triangle_down_right = u"\u25E2" #    BLACK LOWER RIGHT TRIANGLE
triangle_down_left  = u"\u25E3" #     BLACK LOWER LEFT TRIANGLE
triangle_up_left    = u"\u25E4" #     BLACK UPPER LEFT TRIANGLE
triangle_up_right   = u"\u25E5" #     BLACK UPPER RIGHT TRIANGLE
cross_diagonal      = u"\u2573" #BOX DRAWINGS LIGHT DIAGONAL CROSS
check_mark          = u"\u2714"