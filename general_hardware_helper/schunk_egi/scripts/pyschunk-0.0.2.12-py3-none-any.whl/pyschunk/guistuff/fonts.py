# -*- coding: latin-1 -*-
'''
Created on 07.08.2013

@author: Osswald2
'''

big=("Calibri", "14")
small=("Calibri", "12")
smaller=("Calibri", "10")
header=("Calibri", "10", "bold")
value=("Calibri", "12")
value_big=("Calibri", "14", "bold")


tutorial_title=value_big
tutorial_text =value
