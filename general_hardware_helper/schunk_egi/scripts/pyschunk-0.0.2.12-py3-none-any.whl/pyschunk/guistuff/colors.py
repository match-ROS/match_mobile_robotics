# -*- coding: latin-1 -*-
'''
Created on 07.08.2013

@author: Osswald2
'''

schunk_dark_blue = "#0B2C55" #003D6A"
schunk_light_blue = "#009EE3" #009DE0"
schunk_light_blue_disabled = "#5b7b89"
schunk_verylight_blue ="#CEDFEF"
schunk_error = "#FF6161"
schunk_warning = "#FFB063"
black = "#000000"
white = "#ffffff"
grey50 = "#808080"
red = "#ff0000"
green = "#00ff00"
blue = "#0000ff"
yellow = "#ffff00"
magenta = '#ff00ff' 
cyan = '#00ffff' 
orange= '#f95104'

schunk_background=schunk_verylight_blue
group_header_column_background = schunk_light_blue
data0_column_background = "#D1F3FF"
data1_column_background = white

tutorial_background = "#f5df00" #"#CCFFCC"
tutorial_button_ab = "#9f5b00"
tutorial_button_bg = "#b87d2e"
disabled_background = "#f0f0f0"
