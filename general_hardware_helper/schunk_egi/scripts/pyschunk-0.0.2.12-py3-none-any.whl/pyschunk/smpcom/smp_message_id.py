# -*- coding: latin-1 -*-
'''
class for representing SMP message IDs
'''

class cSMPMessageID(object):
    def __init__(self, *args, **kwargs): # byte_or_module_id=None, byte_or_is_module_id=None, from_module=None, is_normal=None):
        '''CTor: create a SMP message ID
        
        - if non keyword args are given then exactly 2 must be given and no kwargs are allowed. 
          They then represent the flags and module_id bytes of the message ID.
        - if keyword args are given then the following are allowed:
          - flags        - flags byte
          - module_id    - module id byte
          - is_module_id - flag bit, true if module_id is a module id, else a group id
          - from_module  - flag bit, true if message is from module, else from master
          - is_normal    - flag bit, true if message is normal, else diagnosis
        '''
        if ( len(args) == 2  and len(kwargs)> 0 ):
            raise TypeError( "If 2 non keyword args are given then no keyword args are allowed!" )
        if ( len(args) not in (0,2) ):
            raise TypeError( "Only exactly 0 or 2 non keyword args allowed!" )
            
        if ( len(args) == 0 and len(kwargs) == 0 ):
            self.Check( None )
        elif ( len(args) == 2 ):
            self.Check( args )
        else:
            # handle kwargs
            self.Check( [0,0] )
            for (k,v) in kwargs.iteritems():
                if ( k == "flags" ):
                    self.flags = v
                elif ( k == "module_id" ):
                    self.module_id = v
                elif ( k == "is_module_id" ):
                    self.is_module_id = v 
                elif ( k == "from_module" ):
                    self.from_module = v 
                elif ( k == "is_normal" ):
                    self.is_normal = v
                else:
                    raise AttributeError( "Unknown keyword argument %r" % (k) )
                     

    def Check(self, value):
        if ( value is None ):
            self.value = None
            return
        assert (type(value) in (list,tuple))
        assert (len(value) == 2)
        assert (value[1] >= 0)
        assert (value[1] <= 255)
        assert (value[0] & 0x07 == value[0])
        self.value = list(value)
       
       
    def Clear(self):
        '''clear the value so that the object does not contain data any more
        '''
        self.Check(None)

        
    def HasData(self):
        '''\return True if self holds actual data bytes
        '''
        return not (self.value is None)
        
        
    def Clone(self) :
        ''' Clone self and return copy in new object'''
        return cSMPMessageID( self.value[0], self.value[1] )


    def FromBytes( self, byte0, byte1 ):
        ''' Set value from bytes \a byte0 and \a byte1
        
        \return self
        '''
        self.Check( [ byte0, byte1 ] )
        return self

    def GetByte( self, i ):
        ''' return self.value[i]
        '''
        if ( not self.HasData() ):
            raise ValueError ( "No data to get bytes from!" )
        return self.value[i]

    def GetByteList( self ):
        ''' return self.value as list of bytes
        '''
        return [ self.GetByte(0), self.GetByte(1) ]

    def GetByteString( self ):
        ''' return self.value as string of bytes
        '''
        return "%c%c" % (chr(self.GetByte(0)), chr(self.GetByte(1)))

    # get or set d_len property:
    def _get_d_len( self ):
        if ( not self.HasData() ):
            return 0
        return 2

    def _set_d_len( self, v ):
        raise AttributeError( "setting of d_len not allowed" )
        
    def _del_d_len( self ):
        pass
        
    d_len = property( _get_d_len, _set_d_len, _del_d_len, "d_len, number of bytes in self" )


    def GetFilledLength(self, peek_byte_list=None ):
        '''Return the length of the object in bytes if it were filled with data
        '''
        return 2


    # get or set flags property:
    def _get_flags( self ):
        if ( not self.HasData() ):
            raise ValueError ( "No data to get flags from!" )
        return self.value[0]

    def _set_flags( self, flags ):
        if ( not self.HasData() ):
            self.value = [0,0]
        self.Check( [ flags, self.value[0] ] )
        
    def _del_flags( self ):
        pass
        
    flags = property( _get_flags, _set_flags, _del_flags, "flags" )
    
    
    # get or set module_id property:
    def _get_module_id( self ):
        if ( not self.HasData() ):
            raise ValueError ( "No data to get module id from!" )
        return self.value[1]

    def _set_module_id( self, m_id ):
        if ( not self.HasData() ):
            self.value = [0,0]
        self.Check( [ self.value[0], m_id ] )
        
    def _del_module_id( self ):
        pass
        
    module_id = property( _get_module_id, _set_module_id, _del_module_id, "module ID" )
    
    
    # get or set is_module_id property:
    def _get_is_module_id( self ):
        if ( not self.HasData() ):
            raise ValueError ( "No data to get is module id from!" )
        return bool(self.value[0] & 0x01)

    def _set_is_module_id( self, is_m_id ):
        if ( not self.HasData() ):
            self.value = [0,0]
        if is_m_id  :
            self.value[0] |=  0x01
        else:
            self.value[0] &= 0xfe
        
    def _del_is_module_id( self ):
        pass
        
    is_module_id = property( _get_is_module_id, _set_is_module_id, _del_is_module_id, "is module ID" )
    
    
    # get or set from_module property:
    def _get_from_module( self ):
        if ( not self.HasData() ):
            raise ValueError ( "No data to get module id from!" )
        return bool(self.value[0] & 0x02)

    def _set_from_module( self, from_module ):
        if ( not self.HasData() ):
            self.value = [0,0]
        if from_module  :
            self.value[0] |=  0x02
        else:
            self.value[0] &= 0xfd
        
    def _del_from_module( self ):
        pass
        
    from_module = property( _get_from_module, _set_from_module, _del_from_module, "from module" )

    
 
    # get or set is_normal property:
    def _get_is_normal( self ):
        if ( not self.HasData() ):
            raise ValueError ( "No data to get module id from!" )
        return bool(self.value[0] & 0x04)

    def _set_is_normal( self, is_normal ):
        if ( not self.HasData() ):
            self.value = [0,0]
        if is_normal  :
            self.value[0] |=  0x04
        else:
            self.value[0] &= 0xfb
        
    def _del_is_normal( self ):
        pass
        
    is_normal = property( _get_is_normal, _set_is_normal, _del_is_normal, "is normal" )

    
    def __str__(self):
        ''' \return a string describing self
        '''
        if ( not self.HasData() ):
            return "cSMPMessageID: no data!"
        return "cSMPMessageID: value=0x%02x,0x%02x is_module_id=%d from_module=%d is_normal=%d" % (self.value[0], self.value[1], int(self.is_module_id), int(self.from_module), int(self.is_normal) )

    
    def __eq__( self, other ):
        ''' \return whether other is equal to self
        '''
        if ( not self.HasData() ):
            return other.value is None
        if ( other.value is None ):
            return False 
            
        if self.value[0] != other.GetByte(0):
            return False

        if self.value[1] != other.GetByte(1):
            return False

        return True


    def __ne__( self, other ):
        return not self == other


    def MatchedBy( self, other ):
        '''Test if other matches self. 
        \bug TODO: For now this is the same as __eq__ for cSMPMessageID object!
        
        \return (matches,mismatch_msg) tuple where 
        - \a matches is a boolean that indicates if other matches self
        - \a mismatch_msg if matches is False then this is a message string that further explains the mismatch
        '''
        if ( self.__eq__( other ) ):
            return (True,"")
        return (False,"cSMPMessageIDs do not match %r != %r" % (self, other))
