# -*- coding: latin-1 -*-
#######################################################################
#
## \file
#  \section pyschunk_release_py_general General file information
#
#    \author   Dirk Osswald
#    \date     2014-09-02
#
#  \brief
#    Definition and documentation of the project name and the release
#    name ("version") of the package
#
#  \section pyschunk_release_py_copyright Copyright
#
#  Copyright (c) 2014 SCHUNK GmbH & Co. KG
#
#  <HR>
#  \internal
#
#    \subsection pyschunk_release_py_details SVN related, detailed file specific information:
#      $LastChangedBy$
#      $LastChangedDate$
#      \par SVN file revision:
#        $Id$
#
#  \subsection pyschunk_release_py_changelog Changelog of this file:
#      \include release.py.log
#
#######################################################################

#######################################################################
## \anchor pyschunk_release_py_python_vars
#  \name   Python specific variables
#
#  Some definitions that describe the module for python.
#
#  @{

__doc__       = """Definition and documentation of the project name and the release name ("version") for pyschunk"""  # @ReservedAssignment
__author__    = "Dirk Osswald: dirk.osswald@de.schunk.com"
__url__       = "http://www.schunk.com"
__version__   = "$Id$"
__copyright__ = "Copyright (c) 2014 SCHUNK GmbH & Co. KG"

#  end of doxygen name group pyschunk_release_py_python_vars
#  @}
######################################################################

######################################################################
# Define some variables

## \brief Name of the software "SCHUNK Python Modules" project.
#
#  \anchor project_name_pyschunk
#  The name of the project
#
#    \internal
#    \remark
#    - This name is extracted by the makefile and then used by doxygen:
#      - As name of the project within the generated documentation.
#      - As base name of the generated install directory and pdf files.
#    - The name should \b NOT contain spaces!
#
PROJECT_NAME = "pyschunk"

## \brief Release name of the whole software project (a.k.a. as the \e "version" of the project).
#
#    \anchor project_release_pyschunk
#    The release name of the project.
#
#    A suffix of "-dev" indicates a work in progress, i.e. a not yet finished release.
#    A suffix of "-a", "-b", ... indicates a bugfix release.
#
#    From newest to oldest the releases have the following names and features:
#
#    - \b 0.0.2.12 2021-08-06
#      - first release after splitting pyschunk into pyschunk and pyschunk_build_tools
#      - minor cleanup
#
#    - \b 0.0.2.11 2021-06-17
#      - fixed generate_parameter_list due to MF-24663 - Build-Prozess: die Datei "BKS_parameters.html" ist nicht vollst�ndig
#      - improved generate_parameter_list to include conditionals and marks like IGNORE_ON_FACTORY_RESET
#
#    - \b 0.0.2.10 2021-04-01
#      - made nexus_upload.py work on Linux (build-server)
#      - made mylogger work on Linux
#      - added -i/--id command line parameter to measure_can_configuration_period.py
#      - improved hsm2dot to be more verbose on error output to simplify fixing errors
#      - improved hsm2dot to ignore completely commented lines from further parsing
#      - improved plot.py
#        - made it work on cygwin again (gnuplot exe is now called gnuplot-x11.exe)
#        - spinboxes for left/right top/bottom axis selection are now colored to easy distinguish them
#        - gnuplot plot command now uses '' instead of full filename for all but the fist plot to save space
#        - avoided pseudo empty ylabel / y2label (was "\n" before when no units were given
#      - improved hsm2dot,
#        - implemented recursive leaf search as required now for motion engine state machine
#        - improved readability of generated graphs by reducing / avoiding lengthy labels. Placing extra info in tooltips instead
#      - improved increment_build_number to automatically retry in case of connection errors
#      - corrected esdcanopen write to cope with bytes type used in Python3. Needed for COT_ControllerTuning.py
#
#    - \b 0.0.2.9 2020-08-18
#      - added working upload_nexus.py for reuse/inspiration by Pascal B�rger
#
#    - \b 0.0.2.8 2020-06-09
#      - added bprintf for simple printf style output from batch scripts
#
#    - \b 0.0.2.7 2020-06-08
#      - improved / corrected reading of canopen SDO responses for VISIBLE_STRING data
#        For short strings (<= 4 chars) the SDO response is transfered as an expedited data, which is returned as an integer and not as a string.
#        So for VISIBLE_STRING data of unknown length this must be checked and possibly corrected. Added new SDO.read_visible_string() member and used that were appropriate
#      - increment_build_number now generates the build_info_file with default values if not available.
#
#    - \b 0.0.2.6 2020-04-29
#      - generate_parameter_list now uses a generic version control information file as input
#
#    - \b 0.0.2.5 2020-04-22
#      - added increment_build_number.py and build_numbers.py, the client and server part of the new SCHUNK build numbers webservice
#        increment_build_number.py now handles BUILD_HOST and BUILD_USER as well, like the old increment.exe
#        increment_build_number.py now shortens BUILD_HOST and BUILD_USER to the appropriate lenght (11 chars + \0)
#      - AttachToDebugger() now exits with the same exit code from the script on SystemExit
#        to make calling code work even when debugging
#
#    - \b 0.0.2.4 2020-03-09
#      - further updated plot.py to work with python3.7.
#      - Enabled Drag & Drop for plot.py using TkinterDnD
#      - Corrected generate_hms_enum_description to always generate the include files in the given order (avoid using set())
#
#    - \b 0.0.2.3 2020-02-11
#      - continuing development based on python3.7 on trunk, merged all changes from python3.7 branch
#      - updated hsm2dot to cope with new Option in HSM state templates, see bug https://schunk.polarion.com/polarion/#/project/ModulareFirmware/workitem?id=MF-17418
#
#    - \b 0.0.1.15: 2019-12-12
#      - corrected requirements in setup.py for python
#      - final (?) release for python2.7
#
#    - \b 0.0.2.2: 2019-12-12
#      - made scripts/microterm.py work with python3 and windows 10
#      - made generation of pyschunk / bks build tool stand alone exes work with python 3 by using pyinstaller instead of py2exe
#
#    - \b 0.0.2.1: 2019-12-02
#      - made scripts/generate_* stuff for bks build tools work with python 3.7
#      - attach_to_debugger now uses localhost as default for debug host
#
#    - \b 0.0.2.0: 2019-11-13
#      - ported code to Python3.7
#      - Changed shebang line to make it work with python3. Now "python3win" must be somewhere in the path.
#      - changed name parameter in GetPersistantDict() calls. Added a "3" so that old settings files from previous python 2 based
#        installation do not interfere with new python 3 based installations. (Python 3 GetPersistentDict yields an exception when
#        called on an old existing settings file)
#      - corrected all print statements to print function calls, even in comments
#      - converted use of / to // where applicable
#      - added output of python version and compiler and platform in pyschunk.canopen.esdutil.cCANOptionParser -v | --version
#      - excluded pydevd package for py2exe generated stuff since that does not work
#
#    - \b 0.0.1.14: 2019-09-26
#      - improved generate_parameter_list to cope with new parameters.cpp (multiline support, comments get ignored)
#        parameters are now numbered sequentially in output list
#      - improved generate_hms_enum_description
#        - added possibility to provide alternative short strings for long enum descriptions. Needed for Ethernet/IP which limits enum names to 16 chars
#        - added keep_unused command line parameter to get old behaviour of including even enum values marked "unused"
#
#    - \b 0.0.1.13: 2019-05-23
#      - added generate_parameter_list to generate a html list of parameters like J. Fauls list of parametes
#      - added --define and --preinclude option to generate_hms_enum_description to be able to supply pre include files and defines to castxml.
#
#    - \b 0.0.1.12: 2019-04-24
#      - improved generate_hms_enum_description.py to not include superfluous trailing semicolons to avoid issue remarks
#        The doxygen author line is now ignored for comparison as well to avoid unnecessary updates when just the generate_hms_enum_description version or date changed
#      - added esd_can_statistics C extension module to provide access to ESD CAN statistics
#      - fixed bug in generate_hms_enum_description: when frozen to an exe and exe is run as a file in the PATH then
#        sys.argv[0] is not an absolute path and thus cannot be used directly for older-than checking.
#      - corrected hsm2dot to work without --output_state_enum_python, as expected
#      - improved pyschunk.tools.util.enum.GetName() to accecpt a default_name parameter to simplifiy handling of missing descriptions
#      - improved generate_hms_enum_description.py to generate const variables for direct use from flash
#      - addded generate_parameter_list.py to generate a html list of all parameters
#      - moved OPC-UA.client.peek.py to pyschunk.tools.peek.py for easy reuse in BKSTools.egi.py
#
#    - \b 0.0.1.11: 2018-12-20
#      - added option --output_state_enum_python to hsm2dot for easy access to HSM state numbers/names from BKSTools
#      - improved generate_hms_enum_descriptions to output full specialization of get_enum_description templates
#
#    - \b 0.0.1.10: 2018-12-05
#      - improved hsm2dot to only update (and print warnings) if changes in input
#      - improved hsm2dot to rank nodes based on the numerid id
#      - improved pyschunk.smpcom.smp_message.cSMPMessage.__str__ to be able to cope with messages containing cDTString elements with value ANY
#      - improved hsm2dot to be able to output relative links to the code and generate the output directory if missing and made it more robust when doxygen tags file is not available
#      - moved MultilineFormatter for argparse from BKSTools to pyschunk
#
#    - \b 0.0.1.9: 2018-10-02
#      - updated some pyschunk.smpcom.smp_codes.eErrorCode.* according to most recent MotionControl-CANopenSmart-cplusplus/MCL/common/ReturnCodes_int.h
#      - added generate_hms_enum_description script
#      - all standalone exes (now 2) are now generated within a single build directory
#        and are zipped to a single ZIP archive.
#      - added pyschunk.tools.mylogger.runMain to simplify logging using new logging feature
#      - added generate_source_statistics.py. Very alpha, very crude, superficial output
#      - changed usage of debug_level in smp_interface_canesd to get desired output in DDF3_Kommunikation tester while still be able to disable unwanted low level CAN output
#      - improved to str conversion of cSMPMessage objects to print error code in human readable form for responses with length 2 which are always error messages
#      - improved tDBG output to accept unicode. Needed e.g. for � chars in method help texts of DDF3_Kommunikationstest
#      - added pyschunk/test dir for quick tests
#        - added pyschunk/test/test_dbg to check behaviour of changed tDBG
#
#    - \b 0.0.1.8: 2018-09-10
#      - added more powerfull logging using std logging module via new pyschunk.tools.mylogger
#        Now logging can be configured after exes are generated and logging can be redirected to files or the like
#        see bug 2436
#      - added parameter max_age_s to pyschunk.canopen.ds402.GetStatusword() to be able to check for timeout in
#        statuswords received via TPDO. Usefulle to detect modules gone to error e.g. due to node-guarding or heartbeat errors
#
#    - \b 0.0.1.7: 2018-07-11
#      - improved hsm2dot to indicate more errors and to cope with statemachines defined in separate header and code file
#
#    - \b 0.0.1.6: 2018-05-04
#      - plot.py now respects 'axes xNyM' directives contained in the gpd input file
#
#    - \b 0.0.1.5: 2018-04-06
#      - changes for bug 2305 (ESD CAN-usb-mini funktioniert nicht) prepared but commented out since incomplete, see there http://sbtserver/schunkzilla/show_bug.cgi?id=2305
#      - fixed bug 2322: Task: CANopenTools Umschalten auf CANopen bei LWA5 wieder erm�glichen http://sbtserver/schunkzilla/show_bug.cgi?id=2322
#
#    - \b 0.0.1.4: 2018-02-22
#      - added hsm2dot script, a converter from "Heinzmann-Style" C++ statemachines to graphviz dot
#
#    - \b 0.0.1.3: 2018-01-26
#      - corrected return value(s) of canopen.esdcanopen.NODEGUARDrequest to include the toggle bit
#      - corrected sending of toggle bit in canopen.esdcanopen.HeartbeatProducer (must be 0 for heartbeat)
#      - changed setenv to use addpath/addexportpath from func.sh to be able to call setenv multiple times
#      - pyschunk.guistuff.widgets.cDataGroup now makes the (shown/hidden) state available as hide_data member.
#      - added must_have_object parameter to pyschunk.esdcanopen.sdo.SDO.ScanForNodes to be able to scan for
#        nodes which have a scpecific object only. Used e.g. now COT_GetCurrent.
#      - improved string conversion of pyschunk.smpcom.smp_message.cSMPMessage objects to include the command decoded
#      - corrected pyschunk.smpcom.smp_message.cSMPMessage.MatchedBy()
#        - make matching for received messages against expected messages with multibyte placeholders actually work
#        - added tests to asure that
#      - improved plot.py watching now reacts on changed gpd files as well
#      - added support for new --EGI option from COT_GetDebugMessages to pyschunk.canopen.esdutil.cCANOptionParser
#      - improved pyschunk.canopen.schunkcanopen.tCANopenStream.close() to cope with missing / restarting / replugging of ESD adapter for COT_GetDebugMessages
#      - added pyschunk.tools.util.GetExitState() to let sub threads read the state of the pyschunk.tools.util.ConfirmExit exit handler.
#        Need to make proper, confimable CTRL-C handling work in naive windows console and generated exes
#
#    - \b 0.0.1.2: 2016-11-24
#      - bugfix bug 1901: Bug: Negative Positionen werden im Log mit "L" Suffix ausgegeben
#        - corrected pyschunk.canopen.c2i32() and pyschunk.canopen.c2i32r() to return int instead of
#          long for negative numbers. This matters only when the result is printed via "%r", but
#          that is used e.g. in --logpos in COT_InterpolatedPositionMode
#
#    - \b 0.0.1.1: 2016-08-31
#      - minor cleanup to Makefile and setup.py, to synchronize layout with CANopenTools.setup.py
#      - added WhereAmI() method to tDBG to easily print filename, line-number, function-name of calling code
#      - added conditional dependency to pypiwin32 for windows in setup.py.
#        This is not the real pywin32, but sufficient for our purposes.
#        (pywin32 is not available via pip, but pypiwin32 is)
#      - made dependency on pyreadline conditional for windows as well.
#      - improved plot.py to make --watch|-w option work on windows when
#        called via the exe wrapper generated by the pip installer when
#        installing from wheel
#      - improved tDBG output to actually see the output in some situations
#        when running on a cygwin console (rxvt)
#      - While merging Christian Scheuermanns SMPTest and TrajectoryVerification projects:
#        - Improved pyschunk.smpcom.smp_message to be able to handle cDTString objects with value ANY (e.g. error_details.file)
#        - refactored pyschunk.smpcom.ScanBus for better readability
#        - Improved pyschunk.smpcom.smp_types.cUInt8 to automatically decode objects named "error" using smp_codes.eErrorCode
#
#    - \b 0.0.1.0: 2016-08-11
#      - refactored used code from pytools to pyschunk.tools
#        (to be able to make a publicly available python package for pip a
#         unique name is requred, and pytools is already in use)
#      - improved guistuff.widgets.FindFileInPaths() to search for files using pkg_resources,
#        so that e.g. image files in egg or wheel packages can be found.
#        Does not work for zips like generated by py2exe, but the std search ways still works.
#      - renamed my miniterm to microterm to avoid conflict with pyserial.miniterm
#      - made microterm script work when called as a exe generated by setuptools
#      - made plot.py work without filename as command line parameter to make it useable as
#        an exe generated by setuptools. Made plot.py remember last directory
#      - made microterm.py work on Linux (RaspberryPi) and (mostly on Cygwin/Windows)
#      - made plot.py work on Linux, Windows, Cygwin
#      - improved generation of distributions by switching from distutils to setuptools
#        - cleaned up setup.py script
#        - cleaned up Makefile to simplify usage
#        - added generation of several binary and source distribution formats
#      - Added tools.util.SetExitHandler() that even catches "user closes console window" events
#
#    - \b 0.0.0.10: 2016-05-19
#      - Corrected cSMPComCANESD.Receive() to handle fragmented responses that are intermixed with non fragmented ones
#      - Changed used ntcan CMSG type to CMSG_T to include the timestamp for more precise recording
#      - Added cSMPRamp in smp_trajectory_verification.py for the new ramp verifaction. Should be refactored to SMPTest
#
#    - \b 0.0.0.9: 2016-04-18
#      - Added generation of source distribution for SDHx_TestingTool on Raspi to Makefile
#
#    - \b 0.0.0.8: 2016-03-03
#      - Added ActivateBitTiming() to LSS class in esdcanopen
#      - improved appearance and placement of tutorial.cTutorial tool tips by limiting the boundaries to the boundaries of the App.
#      - added new error codes used in newest LWA5 firmware
#      - added DisconnectNode parameter to schunkcanopen.DisconnectNode()
#      - added eHWTestCode.TEST_CAN_COUNTER, eHWTestCode.TEST_READ_TI_MEMORY
#      - added canIdDelete to SDO.__del__ to free ressources in driver
#      - added module_ids parameter to cSMPComCANESD.open() to be able to limit
#        received SMP messages to those from selected modules only
#        Added simpilar parameter to other communication interfaces for consistency
#      - Added smptools.GetTimestamp() for consistent generation of timestamps
#      - Added __str__() method to all cSMPType types to simplifiy their printing
#      - made tests in pyschunk/smpcom/test run again
#
#    - \b 0.0.0.7: 2015-04-30
#      - Added pyschunk.smpcom.cSMPModule.GetPosSystemOffset() to simplify display of sinus vector in various CANopenTools
#      - Added cb_show_data callback parameter to Ctor of pyschunk.guistuff.widgets.cDataGroup to be able to perform some action before showing a data group.
#        Used now to update the error history once when the data group is opened.
#
#    - \b 0.0.0.6: 2015-04-16
#      - Added workaround for weird problem with interactive query for node numbers does not recognize patterns like "3-8" in DOS consoles
#      - Added support for callback for Mouse Wheel events, e.g. for scrolling frames
#
#    - \b 0.0.0.5: 2015-04-13
#      - made scanning for CANopen nodes much faster
#      - incorporated improved interactive debug message enabling/disabling
#
#    - \b 0.0.0.4: 2015-02-23
#
#    - \b 0.0.0.3: 2014-10-22
#      - removed relative imports since not working in FPS+ project
#
#    - \b 0.0.0.2: 2014-09-16
#      - moved package SMPTest.smpcom to pyschunk.smpcom for easy redistribution
#      - moved package CANopenTools.canopen to pyschunk.canopen for easy redistribution
#      - minor changes to get code (nearly) error/warning free in eclipse
#
#    - \b 0.0.0.1: 2014-09-02
#      - Initial "release" of the code
#        - This code is used for quite a while now but not as a real package
#        - added setup.py and release.py to be able to create windows installers to simplify calling of python scripts from windows without cygwin
#
PROJECT_RELEASE = "0.0.2.12"

## \brief Date of the release of the software project.
#
#    \anchor project_date_pyschunk
#    The date of the release of the project.
#
PROJECT_DATE = "2021-08-06"
